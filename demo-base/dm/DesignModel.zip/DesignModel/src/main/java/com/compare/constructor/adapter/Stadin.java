package com.compare.constructor.adapter;

//替身演员
public class Stadin implements IActor {

	@Override
	public void play(String context) {
		// TODO Auto-generated method stub
		System.out.println("替身演戏"+context);
	}

}
