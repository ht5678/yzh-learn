package com.design.visitor;

public class ConcreteVisitor implements Visitor{

	@Override
	public void visit(ConcreteElement1 e1) {
		// TODO Auto-generated method stub
		e1.operation();
	}

	@Override
	public void visit(ConcreteElement2 e2) {
		// TODO Auto-generated method stub
		e2.operation();
	}

}
