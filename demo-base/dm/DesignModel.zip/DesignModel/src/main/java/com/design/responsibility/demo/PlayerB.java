package com.design.responsibility.demo;

public class PlayerB extends Player{
	
	public PlayerB(Player successor){
		this.setSuccessor(successor);
	}
	
	//实现handle方法
	@Override
	public void handle(int i) {
		// TODO Auto-generated method stub
		if(i == 2){
			System.out.println("PlayerB 喝酒");
		}else{
			System.out.println("PlayerB 把花向下传");
			next(i);
		}
	}

}
