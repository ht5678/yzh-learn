package com.compare.constructor.adapter;

//场景应用类
public class Client {

	public static void main(String[] args) {
		//明星自己演戏
		IStar star = new Star();
		star.action("表演10分钟");
		//再找替身演员替演
		star = new Adapter();
		star.action("表演5分钟");
	}
}
