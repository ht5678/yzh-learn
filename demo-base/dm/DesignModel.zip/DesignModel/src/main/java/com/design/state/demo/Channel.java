package com.design.state.demo;

public interface Channel {
	//播放频道中的节目
	public void display();
}
