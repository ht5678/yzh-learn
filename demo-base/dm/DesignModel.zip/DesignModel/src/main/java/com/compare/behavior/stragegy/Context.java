package com.compare.behavior.stragegy;

//环境角色
public class Context {
	//指向抽象算法
	private Algorithm al;
	
	public Context(Algorithm al){
		this.al = al;
	}
	//执行压缩算法
	public boolean compress(String source , String to){
		return al.compress(source, to);
	}
	//执行解压缩算法
	public boolean uncompress(String source ,String to){
		return al.uncompress(source, to);
	}
	
}
