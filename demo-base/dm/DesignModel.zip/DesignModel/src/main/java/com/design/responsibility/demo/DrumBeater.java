package com.design.responsibility.demo;

public class DrumBeater {

	public static void main(String[] args) {
		//创建一个连
		Player player = new PlayerA(new PlayerB(new PlayerC(null)));
		//击打三下停止
		player.handle(3);
		
		System.out.println("---------------------");
		player.handle(8);
		System.out.println("---------------------");
		player.handle(2);
	}
}
