package com.design.interpreter;

import java.util.HashMap;

public class Context {
	private HashMap map = new HashMap<>();
	
	

}
