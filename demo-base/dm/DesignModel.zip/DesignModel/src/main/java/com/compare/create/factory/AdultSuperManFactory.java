package com.compare.create.factory;

public class AdultSuperManFactory implements SuperManFactory{

	//创建一个成年超人
	@Override
	public ISuperMan createSuperMan() {
		// TODO Auto-generated method stub
		return new AdultSuperMan();
	}

}
