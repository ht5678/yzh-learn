package com.design.abstractfactory;

public interface ProductB {
	//产品B的公共方法
	public void method1();
	
	public void method2();
}
