package com.design.factorymethod.demo;

/**
 * 工厂方法模式的实例
 * @author byht
 *
 */
public interface FruitGardener {

	public Fruit factory();
	
}
