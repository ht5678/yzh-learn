package com.compare.behavior.command;

//zip解压缩命令
public class ZipUncompressCmd extends AbstractCmd{

	@Override
	public boolean execute(String source, String to) {
		return super.zip.uncompress(source, to);
	}

}
