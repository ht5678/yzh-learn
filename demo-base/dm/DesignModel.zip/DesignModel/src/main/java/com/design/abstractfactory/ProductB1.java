package com.design.abstractfactory;

public class ProductB1 implements ProductB{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("等级为1的产品B的实现方法");
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("业务逻辑处理代码");
	}

	
}
