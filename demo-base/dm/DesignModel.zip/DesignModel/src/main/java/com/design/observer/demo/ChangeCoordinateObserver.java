package com.design.observer.demo;

public class ChangeCoordinateObserver implements ClickableObserver {

	@Override
	public void clicked(Clickable clickable) {
		// TODO Auto-generated method stub
		Button button = (Button) clickable;
		button.x=100;
		button.y=90;
	}

}
