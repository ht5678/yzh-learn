package com.design.command;

public class Client {

	public static void main(String[] args) {
		//调用者
		Invoker invoker = new Invoker();
		//接受者
		Receiver receiver = new Receiver();
		//定义一个发送个接受者的命令
		Command command = new ConcreteCommand(receiver);
		//执行
		invoker.setCommand(command);
		invoker.action();
	}
	
}
