package com.design.bridge.demo;

public class Test {

	public static void main(String[] args) {
		Color green = new Green();
		AbstractShape shape = new Square(green);
		shape.draw();
	}
	
}
