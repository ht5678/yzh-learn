package com.compare.constructor.decorator;

/**
 * 明星接口
 * @author byht
 *
 */
public interface IStar {

	//明星演戏
	public void action(String context);
}
