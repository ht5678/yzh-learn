package com.design.bridge.demo;

public class Red implements Color{

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "红色";
	}

}
