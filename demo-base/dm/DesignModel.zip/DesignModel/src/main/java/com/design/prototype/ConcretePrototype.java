package com.design.prototype;

public class ConcretePrototype implements Prototype{

	public Prototype clone(){
		// TODO Auto-generated method stub
		try {
			return (Prototype)super.clone();
		} catch (CloneNotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	
}
