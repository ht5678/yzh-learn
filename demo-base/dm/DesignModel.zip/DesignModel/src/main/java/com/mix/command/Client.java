package com.mix.command;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * 三个指令
 * 
 * ls
 * 
 * ls -a 
 * 
 * ls -l
 * @author byht
 *
 */
public class Client {

	public static void main(String[] args) throws IOException {
		Invoker invoker = new Invoker();
		while(true){
			//unix下的默认提示符号
			System.out.println("#");
			//捕捉输出
			String input = new BufferedReader(new InputStreamReader(System.in)).readLine();
			//输入quit或者exit退出
			if(input.equals("quit") || input.equals("exit")){
				return;
			}
			System.out.println(invoker.exec(input));
		}
		
	}
}
