package com.compare.create.factory;

public interface ISuperMan {
	//超人的特殊能力
	public void specicalTalent();
}
