package com.mix.specification;

/**
 * like规则书
 * @author byht
 *
 */
public class UserByNameLike extends CompositeSpecification{
	//like规格书
	private static String LIKE="%";
	//基准的like字符串
	private String likeStr ;
	
	public UserByNameLike(String name){
		this.likeStr = name;
	}
	
	@Override
	public boolean isSatisfiedBy(User user) {
		// TODO Auto-generated method stub
		boolean result = false;
		String name = user.getName();
		//去掉%的字符串
		String str = likeStr.replace("%", "");
		
		if(likeStr.startsWith(LIKE) && likeStr.endsWith(LIKE)){
			//类似于%张%
			result = name.contains(str);
		}else if(likeStr.startsWith(LIKE)){
			//类似于%张
			result = name.endsWith(str);
		}else if(likeStr.endsWith(LIKE)){
			//类似于张%
			result = name.startsWith(str);
		}
		return result;
	}

}
