package com.mix.specification;

public class AndSpecification extends CompositeSpecification {
	//传递两个规格书进行and操作
	private IUserSpecification left;
	private IUserSpecification right;
	
	public AndSpecification(IUserSpecification left,IUserSpecification right){
		this.left = left;
		this.right = right;
	}
	
	@Override
	public boolean isSatisfiedBy(User user) {
		// TODO Auto-generated method stub
		return left.isSatisfiedBy(user) && right.isSatisfiedBy(user);
	}

}
