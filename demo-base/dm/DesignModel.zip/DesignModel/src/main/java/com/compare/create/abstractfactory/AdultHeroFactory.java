package com.compare.create.abstractfactory;

public class AdultHeroFactory implements HeroFactory{

	@Override
	public ISuperMan createSuperMan() {
		// TODO Auto-generated method stub
		return new AdultSuperMan();
	}

	@Override
	public ISpiderMan createSpiderMan() {
		// TODO Auto-generated method stub
		return new AdultSpiderMan();
	}

}
