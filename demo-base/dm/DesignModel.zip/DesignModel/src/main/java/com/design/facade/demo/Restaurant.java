package com.design.facade.demo;

public class Restaurant {
	
	public void reserve(int num){
		System.out.println("订了一桌"+num+"个人的酒席");
	}

}
