package com.compare.create.abstractfactory;

public interface HeroFactory {

	//生成超人
	ISuperMan createSuperMan();
	//生产蜘蛛侠
	ISpiderMan createSpiderMan();
}
