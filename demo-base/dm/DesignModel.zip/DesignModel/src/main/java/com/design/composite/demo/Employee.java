package com.design.composite.demo;

public class Employee implements Company{
	private String name;//姓名
	private String position;//职位
	private int salary;//薪水
	

	public Employee(String name, String position, int salary) {
		this.name = name;
		this.position = position;
		this.salary = salary;
	}


	@Override
	public String getInfo() {
		// TODO Auto-generated method stub
		return "ConcreteCompany [name=" + name + ", position=" + position
				+ ", salary=" + salary + "]";
	}

}
