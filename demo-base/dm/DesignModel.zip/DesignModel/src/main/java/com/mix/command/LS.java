package com.mix.command;

/**
 * ls类智能处理不带参数的ls命令，因此getOperateParam()方法返回一个长度为零
 * 的字符串，说明该类作为链上的一个节点，只处理没有参数的ls命令.
 * echo()方法用于执行ls命令
 * @author byht
 *
 */
public class LS extends AbstractLS{

	//最简单的ls命令
	@Override
	protected String getOperateParam() {
		// TODO Auto-generated method stub
		return super.DEFAULT_PARAM;
	}

	//参数为空
	@Override
	protected String echo(CommandVO vo) {
		// TODO Auto-generated method stub
		return FileManager.ls(vo.getCommandName());
	}

}
