package com.compare.create.factory;

public class AdultSuperMan implements ISuperMan{

	//实现特殊能力
	@Override
	public void specicalTalent() {
		// TODO Auto-generated method stub
		System.out.println("成年超人力大无穷，可以飞行");
	}

}
