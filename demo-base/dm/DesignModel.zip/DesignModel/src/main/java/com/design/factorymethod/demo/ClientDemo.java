package com.design.factorymethod.demo;

public class ClientDemo {
	
	public static void main(String[] args) {
		//苹果园丁工厂
		FruitGardener fruitGardener = new AppleGardener();
		Fruit apple = fruitGardener.factory();
		apple.plant();
		apple.grow();
		apple.harvest();
		
		//葡萄园丁工厂
		fruitGardener = new GrapeGardener();
		//通过工厂生产葡萄
		Fruit grape = fruitGardener.factory();
		grape.plant();
		grape.grow();
		grape.harvest();
	}

}
