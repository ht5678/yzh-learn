package com.design.abstractfactory;

public class ConcreteFactory1 implements AbstractFactory {

	//创建等级为1的产品
	@Override
	public ProductA factoryA() {
		// TODO Auto-generated method stub
		return new ProductA1();
	}
	
	//创建等级为1的产品
	@Override
	public ProductB factoryB() {
		// TODO Auto-generated method stub
		return new ProductB1();
	}

}
