package com.design.cglib;

/**
 * 供客户端调用
 * @author byht
 *
 */
public class Client {

	
	public static void main(String[] args) {
		Client client = new Client();
//		client.anyonecanManager();
		
//		client.haveNoAuthManager();
//		client.haveAuthManager();
		
		client.selectivityAuthManager();
	}
	
	
	/**
	 * ---2.
	 * 模拟：没有权限的 会员，可以执行查询操作
	 */
	public void selectivityAuthManager(){
		
		System.out.println("the loginer's name is not maurice,so have no permits do manager except do query operator");  
		InfoManager manager = InfoManagerFactory.getInstance(new AuthProxy("wangwu"));
		doCRUD(manager);
		separatorLine();
		
	}
	
	/**
	 * 1.
	 * 模拟：登录会员有权限
	 */
	public void haveAuthManager(){
	     System.out.println("the loginer's name is maurice,so have permits do manager");  
	     InfoManager authManager = InfoManagerFactory.getInstance(new AuthProxy("zhangsan"));
	     doCRUD(authManager);
	     separatorLine();
	}
	
	/**
	 * 1.
	 * 模拟：登录会员没有权限
	 */
	public void haveNoAuthManager(){
		 System.out.println("the loginer's name is not maurice,so have no permits do manager");  
		 InfoManager noAuthManager = InfoManagerFactory.getInstance(new AuthProxy("wangwu"));
		 doCRUD(noAuthManager);
		 separatorLine();
	}
	
	/**
	 * 原始
	 * 模拟：没有任何权限要求，任何人都可以操作
	 */
//	public void anyonecanManager(){
//		System.out.println("any one can do manager");
//		InfoManager manager = InfoManagerFactory.getInstance();
//		doCRUD(manager);
//		separatorLine();
//	}
	
	
	/*----------------------------------华丽丽的分割线---------------------------------------*/
	/**
	 * 对info进行 增 / 删 / 改 / 查 
	 * @param manager
	 */
	private void doCRUD(InfoManager manager){
		manager.query();
		manager.add();
		manager.delete();
		manager.update();
	}
	
	/** 
     * 加一个分隔行，用于区分 
     */  
    private void separatorLine() {  
        System.out.println("################################");  
    }  
	
}
