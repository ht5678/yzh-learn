package com.design.decorator.demo;

public class ClientDemo {
	
	public static void main(String[] args) {
		Car car = new Benz();
		//对奔驰车进行粉饰
		CarDecorator decorator = new ConcreteCarDecorator(car);
		decorator.show();
	}
}
