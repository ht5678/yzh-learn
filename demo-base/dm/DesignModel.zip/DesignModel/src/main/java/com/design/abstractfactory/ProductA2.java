package com.design.abstractfactory;

public class ProductA2 implements ProductA{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("等级为2的产品A的实现方法");
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("业务逻辑方法");
	}
}
