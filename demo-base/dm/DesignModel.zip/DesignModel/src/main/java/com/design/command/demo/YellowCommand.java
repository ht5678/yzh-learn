package com.design.command.demo;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;

//具体命令角色，让面板变为黄色的命令
public class YellowCommand extends JButton implements MyCommand{

	private JPanel p;
	
	//构造函数
	public YellowCommand(String name , JPanel p){
		//构造一个按钮控件
		super(name);
		this.p = p;
	}
	
	
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		//改变面板的背景颜色
		p.setBackground(Color.yellow);
	}

}
