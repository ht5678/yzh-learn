package com.mix.factory;

public class FreeDeduction implements IDeduction {

	@Override
	public boolean exec(Card card, Trade trade) {
		// TODO Auto-generated method stub
		//获取交易金额
		double m = trade.getAmount();
		//获取IC卡中的自由金额
		double f = card.getFreeMoney();
		//如果交易金额比自由金额大，交易失败
		if(m>f){
			return false;
		}else{
			//从自由金额中扣除
			card.setFreeMoney(f-m);
			return true;
		}
	}

}
