package com.compare.create.factory;

public class ChildSuperManFactory implements SuperManFactory {

	//创建一个小超人
	@Override
	public ISuperMan createSuperMan() {
		// TODO Auto-generated method stub
		return new ChildSuperMan();
	}

}
