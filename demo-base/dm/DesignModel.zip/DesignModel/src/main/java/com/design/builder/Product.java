package com.design.builder;

public class Product {

	//产品类的业务处理方法
	
}
