package com.design.observer.demo;

import java.util.ArrayList;
import java.util.List;


public class Button implements Clickable {
	//存储注册过的事件观察者
	List<ClickableObserver> observers = new ArrayList<>();
	//按钮信息
	String color;
	int x , y ;

	@Override
	public void click() {
		// TODO Auto-generated method stub
		System.out.println("按钮被点击");
		//执行所有观察者的事件处理方法
		for(ClickableObserver observer : observers){
			observer.clicked(this);
		}
	}

	@Override
	public void addClickableObserver(ClickableObserver observer) {
		// TODO Auto-generated method stub
		observers.add(observer);
	}

	@Override
	public void removeClickableObserver(ClickableObserver observer) {
		// TODO Auto-generated method stub
		observers.remove(observer);
	}

	@Override
	public String toString() {
		return "Button [observers=" + observers + ", color=" + color + ", x="
				+ x + ", y=" + y + "]";
	}
	

}
