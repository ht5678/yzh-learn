package com.compare.behavior.command;

//gzip压缩命令
public class GzipCompressCmd extends AbstractCmd{

	@Override
	public boolean execute(String source, String to) {
		// TODO Auto-generated method stub
		return super.gzip.compress(source, to);
	}

}
