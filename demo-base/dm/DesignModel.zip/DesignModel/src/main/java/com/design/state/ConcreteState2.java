package com.design.state;

public class ConcreteState2 extends State {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		System.out.println("行为2的逻辑处理");
	}

}
