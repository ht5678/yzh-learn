package com.mix.factory;

//交易类
public class Trade {
	//交易编码
	private String tradeNo = "";
	//交易金额
	private double amount = 0;
	public String getTradeNo() {
		return tradeNo;
	}
	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
}
