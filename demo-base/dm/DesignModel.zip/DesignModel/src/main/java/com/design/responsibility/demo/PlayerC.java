package com.design.responsibility.demo;

public class PlayerC extends Player{
	
	public PlayerC(Player successor){
		this.setSuccessor(successor);
	}
	
	//实现handle方法
	@Override
	public void handle(int i) {
		// TODO Auto-generated method stub
		if(i == 3){
			System.out.println("PlayerC 喝酒");
		}else{
			System.out.println("PlayerC 把花向下传");
			next(i);
		}
	}
}
