package com.compare.create.factory;

public class Client {

	public static void main(String[] args) {
		System.out.println("=========创建一个成年超人");
		SuperManFactory factory = new AdultSuperManFactory();
		ISuperMan adult = factory.createSuperMan();
		adult.specicalTalent();
		System.out.println("========创建一个未成年超人");
		factory = new ChildSuperManFactory();
		ISuperMan child = factory.createSuperMan();
		child.specicalTalent();
	}
}
