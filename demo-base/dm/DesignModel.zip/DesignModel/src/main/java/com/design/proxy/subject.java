package com.design.proxy;

public interface subject {

	//定义一个请求方法
	public void request();
}
