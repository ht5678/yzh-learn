package com.design.templatemethod.demo;

/**
 * 活期账户
 * @author 岳志华
 *
 */
public class DemandAccount extends Account{

	@Override
	protected String getAccountType() {
		// TODO Auto-generated method stub
		return "活期";
	}

	@Override
	protected double getInterestRate() {
		// TODO Auto-generated method stub
		return 0.005D;
	}

	
	
}
