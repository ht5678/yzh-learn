package com.compare.create.factory;

public class ChildSuperMan implements ISuperMan{

	//实现特殊能力
	@Override
	public void specicalTalent() {
		// TODO Auto-generated method stub
		System.out.println("小超人可以快速移动");
	}

}
