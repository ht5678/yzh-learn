package com.compare.behavior.stragegy;

//zip压缩算法
public class Zip implements Algorithm{

	@Override
	public boolean compress(String source, String to) {
		System.out.println(source+"--->"+to+"--zip压缩成功");
		return true;
	}

	@Override
	public boolean uncompress(String source, String to) {
		System.out.println(source+"--->"+to+"--zip解压缩成功");
		return true;
	}

	
}
