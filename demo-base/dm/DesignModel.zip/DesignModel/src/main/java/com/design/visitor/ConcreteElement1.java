package com.design.visitor;

public class ConcreteElement1 extends Element {

	@Override
	public void accept(Visitor vi) {
		// TODO Auto-generated method stub
		vi.visit(this);
	}
	
	//业务逻辑方法
	public void operation(){
		System.out.println("访问元素1");
	}

}
