package com.mix.factory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * 模拟交易类
 * @author 岳志华
 * 
 * 
 * 测试数据：
 * 编号：000111
 * 交易金额：1000
 * -----
 * 编号：000222
 * 交易金额：380
 * -----
 * 编号：ABC111
 * 交易金额：280
 *
 */
public class Client {

	public static void main(String[] args) {
		//初始化一张IC卡
		Card card = new Card("100010", 300, 500);
		System.out.println("=================IC卡初始信息=================");
		card.showCard();
		//接收用户选择，出事为"N"
		String choice = "N";
		//只要用户选择的不是y或者Y,就一直循环，否则退出系统
		while(!choice.equalsIgnoreCase("y")){
			//创建一个交易对象
			Trade trade = new Trade();
			System.out.println("请输入交易编号:");
			trade.setTradeNo(getInput());
			System.out.println("请输入交易金额:");
			trade.setAmount(Double.parseDouble(getInput()));
			//进行交易，执行扣款操作
			DeductionFacade.deduct(card, trade);
			//显示交易后IC卡中的信息
			card.showCard();
			System.out.println("是否退出系统?(Y/N):");
			choice = getInput();
		}
	}
	
	//从键盘出获取输入数据
	public static String getInput(){
		String str = "";
		try {
			str = (new BufferedReader(new InputStreamReader(System.in))).readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str;
	}
	
	
}
