package com.compare.behavior.stragegy;

public class Gzip implements Algorithm{

	@Override
	public boolean compress(String source, String to) {
		System.out.println(source+"--->"+to+"--gzip压缩成功");
		return true;
	}

	@Override
	public boolean uncompress(String source, String to) {
		System.out.println(source+"--->"+to+"--gzip解压缩成功");
		return true;
	}

}
