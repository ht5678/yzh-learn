package com.design.state.demo;

public class CCTV2 implements Channel {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("CCTV2 经济半小时");
	}

}
