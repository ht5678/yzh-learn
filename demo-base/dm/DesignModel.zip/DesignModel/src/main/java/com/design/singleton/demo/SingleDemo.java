package com.design.singleton.demo;

public class SingleDemo {
	
	//测试单例模式
	public static void main(String[] args) {
		SingleDemo sd = new SingleDemo();
		NumThread threadA = sd.new NumThread("线程A");
		NumThread threadB = sd.new NumThread("线程B");
		
		threadA.start();
		threadB.start();
	}
	
	//线程类
	class NumThread extends Thread{
		private String threadName;
		
		public NumThread (String name){
			threadName = name;
		}
		//重写线程的run方法
		public void run(){
			GlobalNum gnObj = GlobalNum.getInstance();
			//循环访问
			for(int i = 0 ;i <5 ;i++){
				System.out.println(threadName+"第"+gnObj.getNum()+"次访问");
				try {
					this.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
}
