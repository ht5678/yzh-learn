package com.compare.create.factory;

public interface SuperManFactory {
	//生产超人
	public ISuperMan createSuperMan();
}
