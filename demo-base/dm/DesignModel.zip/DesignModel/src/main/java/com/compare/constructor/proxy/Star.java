package com.compare.constructor.proxy;

public class Star implements IStar {

	private String name;
	
	public Star(String name){
		this.name = name;
	}
	
	@Override
	public void action() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"在演戏中");
	}

	@Override
	public void advert() {
		// TODO Auto-generated method stub
		System.out.println(this.name+"在做广告代言");
	}

}
