package com.mix.command;

/**
 * 处理带有"-a"参数的ls命令
 * @author byht
 *
 */
public class LS_A extends AbstractLS {

	@Override
	protected String getOperateParam() {
		// TODO Auto-generated method stub
		return A_PARAM;
	}

	@Override
	protected String echo(CommandVO vo) {
		// TODO Auto-generated method stub
		return FileManager.ls_a(vo.getCommandName());
	}

}
