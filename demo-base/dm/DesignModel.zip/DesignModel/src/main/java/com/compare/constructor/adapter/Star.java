package com.compare.constructor.adapter;

//明星
public class Star implements IStar {

	@Override
	public void action(String context) {
		// TODO Auto-generated method stub
		System.out.println("明星亲自演戏"+context);
	}

}
