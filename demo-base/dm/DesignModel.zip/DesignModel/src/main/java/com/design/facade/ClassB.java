package com.design.facade;

public class ClassB{
	public void methodB(){
		System.out.println("method---b---");
	}
}
