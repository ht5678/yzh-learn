package com.compare.constructor.proxy;

public class Client {

	public static void main(String[] args) {
		//定义一个明星
		IStar star = new Star("范冰冰");
		//定义一个经纪人
		Proxy pro = new Proxy(star);
		//代理演戏
		pro.action();
		//代理广告
		pro.advert();
	}
}
