package com.design.memento.demo;

public class Backup {

	String content ;//备份的内容
	int version;//版本号
	
	public Backup(String content){
		this.content = content;
	}
	
}
