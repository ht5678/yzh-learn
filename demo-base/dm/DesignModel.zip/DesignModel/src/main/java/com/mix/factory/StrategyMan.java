package com.mix.factory;
/**
 * 策略枚举
 * @author 岳志华
 *
 */
public enum StrategyMan {

	SteadyDeduction("com.mix.factory.SteadyDeduction"),
	FreeDeduction("com.mix.factory.FreeDeduction");
	
	private String value;
	
	private StrategyMan(String value){
		this.value = value;
	}
	
	public String getValue(){
		return this.value;
	}
}
