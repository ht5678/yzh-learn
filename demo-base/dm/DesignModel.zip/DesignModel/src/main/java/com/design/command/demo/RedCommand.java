package com.design.command.demo;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;

//具体命令角色,让面板编程红色的命令
public class RedCommand extends JButton implements MyCommand{
	
	private JPanel p ;
	
	public RedCommand(String name , JPanel p){
		super(name);
		this.p = p;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		p.setBackground(Color.RED);
	}

}
