package com.design.visitor;

public abstract class Element {

	//接受操作
	public abstract void accept(Visitor vi);
	
}
