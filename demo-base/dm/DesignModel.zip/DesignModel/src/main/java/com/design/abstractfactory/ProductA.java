package com.design.abstractfactory;

public interface ProductA {

	//产品A的公共方法
	public void method1();
	
	public void method2();
	
}
