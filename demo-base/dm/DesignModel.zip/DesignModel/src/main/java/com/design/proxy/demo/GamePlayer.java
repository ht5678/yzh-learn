package com.design.proxy.demo;

public class GamePlayer implements IGamePlayer{

	private String name="";
	
	public GamePlayer(String name){
		this.name = name;
	}
	
	@Override
	public void killBoss() {
		// TODO Auto-generated method stub
		System.out.println(name+"在打怪");
	}

	@Override
	public void upGrad() {
		// TODO Auto-generated method stub
		System.out.println(name+"升级了");
	}

}
