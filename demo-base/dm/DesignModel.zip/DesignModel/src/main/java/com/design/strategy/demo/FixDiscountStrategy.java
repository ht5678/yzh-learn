package com.design.strategy.demo;

public class FixDiscountStrategy extends DiscountStrategy{

	public FixDiscountStrategy(double price, int number) {
		super(price, number);
	}
	
	//实现策略方法，固定折扣额
	@Override
	public double calculateDiscount() {
		// TODO Auto-generated method stub
		return getNumber()*1;
	}

}
