package com.compare.create.abstractfactory;

public class AdultSuperMan implements ISuperMan{

	@Override
	public void specicalTalent() {
		// TODO Auto-generated method stub
		System.out.println("成年超人力大无穷，能够飞行");
	}

}
