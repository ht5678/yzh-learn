package com.design.decorator.demo;

public interface Car {

	//车的装配
	public void show();
	
}
