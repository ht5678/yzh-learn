package com.design.cglib;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

/**
 * 1.
 * 	只有一个叫“maurice”的用户登录，才允许对信息进行create，update，delete，query的操作。 
 *	怎么办？难道在每个方法前，都加上一个权限判断吗？这样重复逻辑太多了，于是乎想到了Proxy（代理模式），
 *	但是原先的InfoManager也没有实现接口，不能采用jdk的proxy。那么cglib在这边就要隆重登场。 
 *	一旦使用cgblig，只需要添加一个MethodInterceptor的类以及修改factory代码就可以实现这个需求。
 * 
 * @author byht
 *
 */
public class AuthProxy implements MethodInterceptor{
	
	private String name;
	
	public AuthProxy(String name){
		this.name = name;
	}

	/**
	 * 权限验证：如果会员名为zhangsan，则有权限操作，否则提示没有权限
	 * 
	 */
	public Object intercept(Object obj, Method method, Object[] objs,
			MethodProxy proxy) throws Throwable {
		if(!"zhangsan".equals(name)){
			System.out.println("Auth Proxy:you have no permits to do manager! ");
			return null;
		}
		System.out.println("测试：输出方法名"+method.getName());
		return proxy.invokeSuper(obj, objs);
	}

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
