package com.mix.observer;

/**
 * 产品类
 * @author 岳志华
 *
 */
public class Product implements Cloneable{
	//产品名称
	private String name ;
	//属性是否可以变更
	private boolean canChange = false;
	//产生一个新的产品
	public Product(ProductManager manager , String name){
		//允许建立产品
		if(manager.isCreateProduct()){
			canChange = true;
			this.name = name;
		}
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		if(canChange){
			this.name = name;
		}
	}

	//重写克隆方法
	@Override
	protected Product clone(){
		// TODO Auto-generated method stub
		Product p = null;
		try{
			p = (Product) super.clone();
		}catch(CloneNotSupportedException e){
			System.out.println(e.getMessage());
		}
		return p;
	}
	
	
	
}
