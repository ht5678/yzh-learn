package com.design.command;

public interface Command {
	//执行命令的方法
	public void execute();
}
