package com.design.interpreter;

public class Client {

	public static void main(String[] args) {
		Context ctx = new Context();
		for(;;){
			//进行语法判断，病产生递归调用
		}
	}
}
