package com.design.prototype;

/**
 * 原型模式
 * ***注意继承了cloneable的接口
 * ***java中的Object 提供的clone()方法采用的是“浅”克隆，即指是赋值关联对象的引用，
 * ***而不复制关联对象的数据。如果需要“深”克隆，则需要在覆盖clone()方法时手动控制克隆的深度
 * @author yuezhihua
 *
 */
public interface Prototype extends Cloneable{
	//克隆方法
	Prototype clone();
}
