package com.design.facade;

public class ClassC {

	public void methodC(){
		System.out.println("method---c---");
	}
	
}
