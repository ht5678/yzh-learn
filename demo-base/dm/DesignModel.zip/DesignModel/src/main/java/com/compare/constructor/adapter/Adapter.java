package com.compare.constructor.adapter;

//适配器角色
public class Adapter extends Stadin implements IStar {

	//明星演戏
	@Override
	public void action(String context) {
		// TODO Auto-generated method stub
		//让替身演员演戏
		super.play(context);
	}

}
