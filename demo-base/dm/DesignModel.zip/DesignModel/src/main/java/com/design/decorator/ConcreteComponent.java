package com.design.decorator;

public class ConcreteComponent implements Component{

	@Override
	public void operation() {
		// TODO Auto-generated method stub
		System.out.println("业务代码");
	}

}
