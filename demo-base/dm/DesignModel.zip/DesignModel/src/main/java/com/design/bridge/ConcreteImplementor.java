package com.design.bridge;

public class ConcreteImplementor implements Implementor{

	//方法的实现化实现
	@Override
	public void operationImp() {
		// TODO Auto-generated method stub
		System.out.println("业务处理代码");
	}

}
