package com.design.mediator.demo;

public class Man extends Person {

	public Man(String name, int age, Sex sex, int requestAge,
			MarriageAgency agency) {
		super(name, age, sex, requestAge, agency);
	}

}
