package com.design.cglib;

import net.sf.cglib.proxy.Callback;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.NoOp;

/**
 * 工厂类
 * @author byht
 *
 */
public class InfoManagerFactory {

	private static InfoManager manager = new InfoManager();
	
	/**
	 * 创建InfoManager
	 * 
	 * @return
	 */
	//原始----
//	public static InfoManager getInstance(){
//		return manager;
//	}
	
	/*------------------------------我是割手---------------------------------------*/
	//---1.
//	public static InfoManager getInstance(AuthProxy proxy){
//		Enhancer enhancer = new Enhancer();
//		enhancer.setSuperclass(InfoManager.class);
//		enhancer.setCallback(proxy);
//		
//		return (InfoManager)enhancer.create();
//	}
	
	//---2.
	public static InfoManager getInstance(AuthProxy proxy){
		Enhancer enhancer = new Enhancer();
		enhancer.setSuperclass(InfoManager.class);
		//setCallbacks中的拦截器(interceptor)的顺序，一定要和CallbackFilter里面指定的顺序一致！！切忌。
		enhancer.setCallbacks(new Callback[]{proxy , NoOp.INSTANCE});
		enhancer.setCallbackFilter(new AuthProxyFilter());
		return (InfoManager)enhancer.create();
	}
	
}
