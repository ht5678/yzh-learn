package com.compare.constructor.proxy;

import java.util.Random;

//代言人
public class Proxy implements IStar{
	
	private IStar istar;
	
	public Proxy(IStar istar){
		this.istar = istar;
	}

	//代理明星演戏
	@Override
	public void action() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		if(rand.nextBoolean()){
			System.out.println("经纪人同意安排明星演戏");
			this.istar.action();
		}else{
			System.out.println("明星档期已满，不能安排演戏");
		}
	}

	//代理明星广告代言
	@Override
	public void advert() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		if(rand.nextBoolean()){
			System.out.println("经纪人同意安排明星广告代言");
			this.istar.action();
		}else{
			System.out.println("明星档期已满，不能安排广告代言");
		}
	}

	
	
}
