package com.compare.constructor.adapter;

//演员接口
public interface IActor {
	//演员演戏
	public void play(String context);
}
