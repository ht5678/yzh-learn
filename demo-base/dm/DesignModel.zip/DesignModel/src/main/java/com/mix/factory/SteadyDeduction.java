package com.mix.factory;

/**
 * 固定消费扣款策略
 * @author 岳志华
 *
 */
public class SteadyDeduction implements IDeduction {

	@Override
	public boolean exec(Card card, Trade trade) {
		// TODO Auto-generated method stub
		//获取交易金额
		double m = trade.getAmount();
		//获取IC卡中的固定金额
		double s = card.getSteadyMoney();
		//获取IC卡中的自由金额
		double f = card.getFreeMoney();
		//如果交易额大于固定金额和自由金额的和（即卡里的总金额），则交易失败
		if(m>s+f){
			return false;
		}else{
			//如果固定金额比交易金额大
			if(s>m){
				//从固定金额中进行扣除
				card.setSteadyMoney(s-m);
				return true;
			}else{
				//从固定金额中扣除，剩余的从自由金额中扣除
				card.setSteadyMoney(0);
				card.setFreeMoney(f+s-m);
				return true;
			}
		}
	}

}
