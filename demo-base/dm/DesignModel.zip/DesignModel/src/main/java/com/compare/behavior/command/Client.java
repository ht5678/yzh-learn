package com.compare.behavior.command;

public class Client {

	
	public static void main(String[] args) {
		//定义一个命令，压缩一个文件
		AbstractCmd cmd = new ZipCompressCmd();
		//定义一个调用者
		Invoker invoker = new Invoker(cmd);
		//执行压缩
		invoker.execute("c://gx", "d://gx.zip");
		//解压缩
		cmd = new  ZipUncompressCmd();
		invoker = new Invoker(cmd);
		invoker.execute("d://gx.zip", "e://gx");
	}
}
