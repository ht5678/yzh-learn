package com.design.adapter.demo;

public class ClientDemo {

	public static void main(String[] args) {
		HunDun h = new FoodAdapter();
		h.makeHunDun();
	}
	
}
