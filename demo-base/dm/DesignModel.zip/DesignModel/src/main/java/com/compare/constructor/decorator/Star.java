package com.compare.constructor.decorator;

/**
 * 明星
 * @author byht
 *
 */
public class Star implements IStar {

	@Override
	public void action(String context) {
		// TODO Auto-generated method stub
		System.out.println("明星亲自演戏"+context);
	}

}
