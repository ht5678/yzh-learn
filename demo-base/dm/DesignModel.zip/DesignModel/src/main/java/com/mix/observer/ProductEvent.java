package com.mix.observer;

import java.util.Observable;

/**
 * 产品事件
 * @author 岳志华
 *
 */
public class ProductEvent extends Observable{

	private Product source;
	
	private ProductEventType type;
	
	public ProductEvent(Product product){
		this(product, ProductEventType.NEW_PRODUCT);
	}
	
	public ProductEvent(Product product , ProductEventType type){
		this.source = product;
		this.type = type;
		//事件触发
		notifyEventDispatch();
	}
	
	//获取事件源
	public Product getSource(){
		return source;
	}
	//获得事件的类型
	public ProductEventType getEventType(){
		return this.type;
	}
	//触发事件处理
	private void notifyEventDispatch(){
		super.addObserver(EventDispatch.getEventDispatch());
		super.setChanged();
		super.notifyObservers(source);
	}
	
	
}
