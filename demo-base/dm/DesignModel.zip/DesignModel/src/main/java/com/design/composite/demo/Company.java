package com.design.composite.demo;

//抽象接口
public interface Company {
	//获取信息
	public String getInfo();
}
