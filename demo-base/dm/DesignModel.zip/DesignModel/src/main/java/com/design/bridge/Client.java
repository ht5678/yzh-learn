package com.design.bridge;

public class Client {
	
	public static void main(String[] args) {
		Implementor imp = new ConcreteImplementor();
		
		Abstraction abstraction = new RefinedAbstraction(imp);
		
		abstraction.operation();
		
	}

}
