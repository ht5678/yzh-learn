package com.design.facade;

public class ClassA {

	public void methodA(){
		System.out.println("method---a-");
	}
	
}

