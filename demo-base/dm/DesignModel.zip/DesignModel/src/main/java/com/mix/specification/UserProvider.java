package com.mix.specification;

import java.util.ArrayList;

/**
 * 用户操作类
 * @author byht
 *
 */
public class UserProvider implements IUserProvider{
	//用户列表
	private ArrayList<User> userList;
	
	public UserProvider(ArrayList<User> list){
		this.userList = list;
	}
	
	//根据条件查找用户
	@Override
	public ArrayList<User> findUser(IUserSpecification userSpec) {
		// TODO Auto-generated method stub
		ArrayList<User> result = new ArrayList<>();
		for(User u : userList){
			//符合指定规格的用户
			if(userSpec.isSatisfiedBy(u)){
				result.add(u);
			}
		}
		return result;
	}
	
	
	

}
