package com.design.facade.demo;

public class Hotel {

	public void reserve(int days){
		System.out.println("订了"+days+"天的房间");
	}
	
}
