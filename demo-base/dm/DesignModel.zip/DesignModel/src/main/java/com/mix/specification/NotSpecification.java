package com.mix.specification;

/**
 * 非规格书
 * @author byht
 *
 */
public class NotSpecification extends CompositeSpecification {

	//传递规格书进行not操作
	private IUserSpecification spec;
	
	public NotSpecification(IUserSpecification spec){
		this.spec = spec;
	}
	
	@Override
	public boolean isSatisfiedBy(User user) {
		// TODO Auto-generated method stub
		return !spec.isSatisfiedBy(user);
	}

}
