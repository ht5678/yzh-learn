package com.design.command;

public class Receiver {
	//行动方法
	public void action(){
		System.out.println("执行动作");
	}
}
