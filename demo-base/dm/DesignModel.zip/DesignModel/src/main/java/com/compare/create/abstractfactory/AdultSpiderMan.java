package com.compare.create.abstractfactory;

public class AdultSpiderMan implements ISpiderMan{

	@Override
	public void launchSilk() {
		// TODO Auto-generated method stub
		System.out.println("成年蜘蛛侠发射出100米长的蛛丝");
	}

}
