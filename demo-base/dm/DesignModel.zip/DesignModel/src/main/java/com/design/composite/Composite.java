package com.design.composite;

import java.util.ArrayList;

public class Composite implements Component{
	//构件容器
	private ArrayList<Component> components = new ArrayList<>();
	//添加构件
	public void add(Component component){
		this.components.add(component);
	}
	//移除构件
	public void remove(Component component){
		this.components.remove(component);
	}
	//获取子构件
	public ArrayList<Component> getChild(){
		return this.components;
	}

	@Override
	public void operation() {
		// TODO Auto-generated method stub
		System.out.println("业务逻辑代码");
	}

}
