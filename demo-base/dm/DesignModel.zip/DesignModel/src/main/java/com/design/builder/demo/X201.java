package com.design.builder.demo;

public class X201 extends Computer{

	public X201(){
		this.setType("ThinkPad x201i");
	}

	@Override
	public String toString() {
		return "X201 [getType()=" + getType() + ", getCpu()=" + getCpu()
				+ ", getRam()=" + getRam() + ", getHardDisk()=" + getHardDisk()
				+ ", getMonitor()=" + getMonitor() + ", getOs()=" + getOs()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
}
