package com.design.state.demo;

public class CCTV1 implements Channel {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("CCTV1 新闻联播");
	}

}
