package com.compare.create.abstractfactory;

public class ChildHeroFactory implements HeroFactory{

	@Override
	public ISuperMan createSuperMan() {
		// TODO Auto-generated method stub
		return new ChildSuperMan();
	}

	@Override
	public ISpiderMan createSpiderMan() {
		// TODO Auto-generated method stub
		return new ChildSpiderMan();
	}

}
