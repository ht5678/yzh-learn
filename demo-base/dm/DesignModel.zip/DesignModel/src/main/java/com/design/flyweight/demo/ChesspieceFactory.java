package com.design.flyweight.demo;

public class ChesspieceFactory {
	static final Chesspiece WHITE = new ChesspieceFlyweight("白");
	static final Chesspiece BLACK = new ChesspieceFlyweight("黑");
	
	public static Chesspiece getChesspiece(String color){
		if("白".equals(color)){
			return WHITE;
		}else if("黑".equals(color)){
			return BLACK;
		}
		return null;
	}
}
