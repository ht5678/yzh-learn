package com.design.responsibility;

public class Client {

	public static void main(String[] args) {
		Handler handler = new ConcreteHandler();
		Handler h2 = new ConcreteHandler();
		handler.setSuccessor(h2);
		handler.handleRequest();
	}
}
