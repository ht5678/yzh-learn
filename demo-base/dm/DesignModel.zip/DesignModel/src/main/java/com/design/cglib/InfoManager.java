package com.design.cglib;

/**
 * 封装对信息的操作
 * @author byht
 *
 */
public class InfoManager {

	//模拟查询
	public void query(){
		System.out.println("query");
	}
	
	//模拟添加
	public void add(){
		System.out.println("add");
	}
	
	//模拟删除
	public void delete(){
		System.out.println("delete");
	}
	
	//模拟更新
	public void update(){
		System.out.println("update");
	}
	
}
