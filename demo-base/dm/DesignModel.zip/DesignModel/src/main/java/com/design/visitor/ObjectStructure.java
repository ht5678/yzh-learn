package com.design.visitor;

import java.util.Random;
import java.util.Vector;

//结构对象角色
public class ObjectStructure {

	private Vector<Element> elements ;
	
	public ObjectStructure(){
		elements = new Vector<>();
	}
	
	//执行访问操作
	public void action(Visitor vi){
		for(Element e : elements){
			e.accept(vi);
		}
	}
	//添加新元素
	public void add(Element element){
		elements.add(element);
	}
	//元素生成器，这里通过一个工厂方法进行模拟
	public void createElements(){
		Random ran = new Random();
		for(int i = 0 ; i < 10 ;i++){
			if(ran.nextInt(100)>50){
				//添加元素1
				this.add(new ConcreteElement1());
			}else{
				//添加元素2
				this.add(new ConcreteElement2());
			}
		}
	}
}
