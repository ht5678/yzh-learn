package com.design.templatemethod;

public class ConcreteClass extends AbstractClass{

	//实现基本业务方法
	@Override
	protected void operation() {
		// TODO Auto-generated method stub
		System.out.println("业务逻辑");
	}

}
