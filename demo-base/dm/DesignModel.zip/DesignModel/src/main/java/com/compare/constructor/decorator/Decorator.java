package com.compare.constructor.decorator;

/**
 * 抽象装饰类
 * @author byht
 *
 */
public abstract class Decorator implements IStar {

	private IStar star;
	
	public Decorator(IStar star){
		this.star = star;
	}
	
	@Override
	public void action(String context) {
		// TODO Auto-generated method stub
		this.star.action(context);
	}

}
