package com.design.builder.demo;

public class X201Builder implements ComputerBuilder{

	private X201 computer = new X201();
	
	@Override
	public void buildCpu() {
		// TODO Auto-generated method stub
		computer.setCpu("i3-350");
	}

	@Override
	public void buildRam() {
		// TODO Auto-generated method stub
		computer.setRam("2GB 1333MHz");
	}

	@Override
	public void buildHardDisk() {
		// TODO Auto-generated method stub
		computer.setHardDisk("250G 5400转");
	}

	@Override
	public void buildGraphicCard() {
		// TODO Auto-generated method stub
		//无显卡
	}

	@Override
	public void buildMonitor() {
		// TODO Auto-generated method stub
		computer.setMonitor("12英寸 1280*800");
	}

	@Override
	public void bildOs() {
		// TODO Auto-generated method stub
		computer.setOs("windows 7 Home版");
	}

	@Override
	public Computer getResult() {
		// TODO Auto-generated method stub
		return computer;
	}

}
