package com.design.observer.demo;

public class ChangeColorObserver implements ClickableObserver{

	@Override
	public void clicked(Clickable clickable) {
		// TODO Auto-generated method stub
		Button button = (Button) clickable;
		button.color = "红色";
	}

}
