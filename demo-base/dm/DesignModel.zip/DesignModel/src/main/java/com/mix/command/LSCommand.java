package com.mix.command;

public class LSCommand extends Command{

	@Override
	public String execute(CommandVO vo) {
		// TODO Auto-generated method stub
		//返回链表的首节点
		return super.buildChain(AbstractLS.class).get(0).handleMessage(vo);
	}

}
