package com.design.factorymethod;

/**
 * 工厂模式
 * @author 岳志华
 *
 */
public interface Creator {

	/**
	 * 工厂方法
	 * 创建一个产品对象，其输入的参数类型可以自行设置
	 * @param <T>
	 * @param c
	 * @return
	 */
	public <T extends Product> T factory(Class<T> c);
	
}
