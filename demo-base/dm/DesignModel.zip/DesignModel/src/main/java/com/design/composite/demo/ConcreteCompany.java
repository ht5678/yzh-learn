package com.design.composite.demo;

import java.util.ArrayList;
import java.util.List;


public class ConcreteCompany implements Company{
	private List<Company> companies = new ArrayList<>();
	private String name;//姓名
	private String position;//职位
	private int salary;//薪水
	

	public ConcreteCompany(String name, String position, int salary) {
		this.name = name;
		this.position = position;
		this.salary = salary;
	}

	public void add(Company company){
		this.companies.add(company);
	}
	
	public void remove(Company company){
		this.companies.remove(company);
	}
	
	public List<Company> getChild(){
		return this.companies;
	}

	@Override
	public String getInfo() {
		// TODO Auto-generated method stub
		return "ConcreteCompany [name=" + name + ", position=" + position
				+ ", salary=" + salary + "]";
	}

}
