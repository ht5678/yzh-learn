package com.design.templatemethod;

public class Client {

	public static void main(String[] args) {
		AbstractClass ac = new ConcreteClass();
		//调用模板方法
		ac.templateMethod();
	}
	
}
