package com.compare.constructor.decorator;

/**
 * 具体装饰类
 * @author byht
 *
 */
public class ConcreteDecorator extends Decorator{

	//构造函数
	public ConcreteDecorator(IStar star){
		super(star);
	}
	
	public void action(String context){
		System.out.println("进行化妆、造型，让人看上去像明星");
		super.action(context);
	}

}
