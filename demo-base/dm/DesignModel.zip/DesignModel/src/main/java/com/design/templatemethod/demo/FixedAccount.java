package com.design.templatemethod.demo;

/**
 * 定期账户
 * @author 岳志华
 *
 */
public class FixedAccount extends Account{

	@Override
	protected String getAccountType() {
		// TODO Auto-generated method stub
		return "一年定期";
	}

	@Override
	protected double getInterestRate() {
		// TODO Auto-generated method stub
		return 0.0325D;
	}

}
