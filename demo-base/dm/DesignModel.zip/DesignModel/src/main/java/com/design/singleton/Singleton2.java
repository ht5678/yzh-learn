package com.design.singleton;

/**
 * 单例模式----懒汉式
 * @author 岳志华
 *
 */
public class Singleton2 {

	private static Singleton2 instance = null;
	
	//构造方法私有
	private Singleton2(){
		
	}
	//方法同步
	synchronized public static Singleton2 getInstance(){
		if(instance == null){
			instance = new Singleton2();
		}
		return instance;
	}
}
