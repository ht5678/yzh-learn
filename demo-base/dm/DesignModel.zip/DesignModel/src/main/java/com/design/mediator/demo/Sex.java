package com.design.mediator.demo;

public enum Sex {

	MALE,FEMALE
}
