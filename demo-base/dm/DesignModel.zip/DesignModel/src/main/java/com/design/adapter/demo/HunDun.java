package com.design.adapter.demo;

public interface HunDun {

	public void makeHunDun();
	
}
