package com.design.iterator.demo;

import java.util.ArrayList;
import java.util.Stack;
import java.util.Vector;
import java.util.Iterator;

public class IteratorDemo {

	public static void main(String[] args) {
		//定义一个向量集合
		Vector<String> vector = new Vector<>();
		vector.add("向量1");
		vector.add("向量2");
		vector.add("向量3");
		vector.add("向量4");
		//定义一个序列
		ArrayList<String> list = new ArrayList<>();
		list.add("序列1");
		list.add("序列2");
		list.add("序列3");
		//定义栈
		Stack<String> stack = new Stack<>();
		stack.push("A");
		stack.push("B");
		stack.push("C");
		stack.push("D");
		stack.push("E");
		//遍历各种集合
		Iterator iter = vector.iterator();
		System.out.println("遍历向量中的元素");
		show(iter);
		System.out.println("遍历序列中的元素");
		show(list.iterator());
		System.out.println("遍历栈中的元素");
		show(stack.iterator());
		
	}
	
	
	public static void show(java.util.Iterator iter){
		while(iter.hasNext()){
			System.out.println(iter.next()+"  ");
		}
	}
	
	
}
