package com.compare.create.abstractfactory;

public interface ISuperMan {

	//超人的特殊能力
	public void specicalTalent();
	
}
