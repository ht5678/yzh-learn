package com.design.iterator;

public class Client {

	public static void main(String[] args) {
		//定义聚集对象
		Aggregate agg = new ConcreteAggregate();
		agg.add("张三");
		agg.add("李四");
		agg.add("王五");
		//遍历
		Iterator iter = agg.creatIterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
	}
}
