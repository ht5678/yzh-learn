package com.mix.command;

/**
 * 负责与操作系统交互，要将unix命令迁移到windows中运行，
 * 此时需要调用windows的底层函数，因调用windows的底层函数实现比较的复杂
 * 所以采用示例性代码代替
 * @author byht
 *
 */
public class FileManager {

	//ls命令
	public static String ls(String name){
		return "file1\nfile2\nfile3\nfile4";
	}
	//ls -l命令
	public static String ls_l(String name){
		String str = "drw-rw-rw root system 1024 2009-8-20 10:23 file1\n";
		str = str + "drw-rw-rw root system 1024 2009-8-20 10:23 file2\n";
		str = str +"drw-rw-rw root system 1024 2009-8-20 10:23 file3\n";
		return str;
	}
	
	public static String ls_a(String name){
		String str = ".\n..\n\file1\nfile2\nfile3";
		return str;
	}
	
}
