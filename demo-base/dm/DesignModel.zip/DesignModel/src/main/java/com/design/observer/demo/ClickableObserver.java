package com.design.observer.demo;

public interface ClickableObserver {

	//发生单击事件时的操作
	void clicked(Clickable clickable);
}
