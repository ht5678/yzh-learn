package com.design.interpreter;

public abstract class AbstractExpression {
	//每个表达式必须有一个解析任务
	public abstract Object interpreter(Context ctx);
}
