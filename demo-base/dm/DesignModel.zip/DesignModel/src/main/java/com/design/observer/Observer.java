package com.design.observer;

public interface Observer {
	//更新方法
	public void update();

}
