package com.mix.observer;

public class Client {

	public static void main(String[] args) {
		//获得事件分发类
		EventDispatch dispatch = EventDispatch.getEventDispatch();
		//接受乞丐对事件的处理
		dispatch.registerCustomer(new Beggar());
		//接受平民队事件的处理
		dispatch.registerCustomer(new Commoner());
		//接受贵族对事件的处理
		dispatch.registerCustomer(new Nobleman());
		//建立一个产品生产工厂
		ProductManager factory = new ProductManager();
		//制造一个产品
		Product product = factory.createProduct("IBM笔记本");
		//修改产品
		factory.editProduct(product, "DELL笔记本电脑");
		//克隆一个产品
		factory.clone(product);
		//销毁一个产品
		factory.abandoProduct(product);
		
	}
}
