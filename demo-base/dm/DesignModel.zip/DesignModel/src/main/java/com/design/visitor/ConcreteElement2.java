package com.design.visitor;

public class ConcreteElement2 extends Element{

	@Override
	public void accept(Visitor vi) {
		// TODO Auto-generated method stub
		vi.visit(this);
	}
	
	public void operation(){
		System.out.println("访问元素2");
	}

}
