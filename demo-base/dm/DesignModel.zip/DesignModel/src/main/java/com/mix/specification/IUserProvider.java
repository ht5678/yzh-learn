package com.mix.specification;

import java.util.ArrayList;

/**
 * 用户操作接口
 * @author byht
 *
 */
public interface IUserProvider {

	//根据条件查找用户
	public ArrayList<User> findUser(IUserSpecification userSpec);
	
}
