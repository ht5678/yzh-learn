package com.design.visitor.demo;

public interface ComputerVisitor {

	void visitCPU(CPU cpu);//访问cpu
	void visitHarddisk(Harddisk harddisk);//访问硬盘
}
