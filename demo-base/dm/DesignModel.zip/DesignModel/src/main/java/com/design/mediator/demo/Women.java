package com.design.mediator.demo;

public class Women extends Person{

	public Women(String name, int age, Sex sex, int requestAge,
			MarriageAgency agency) {
		super(name, age, sex, requestAge, agency);
	}
	

}
