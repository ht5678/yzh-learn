package com.mix.observer;

/**
 * 平民
 * @author byht
 *
 */
public class Commoner extends EventCustomer{
	
	public Commoner(){
		super(ProductEventType.NEW_PRODUCT);
	}

	@Override
	public void exec(ProductEvent event) {
		// TODO Auto-generated method stub
		Product p = event.getSource();
		//事件类型
		ProductEventType type = event.getEventType();
		System.out.println("平民处理事件："+p.getName()+"创建，事件类型="+type);		
	}

}
