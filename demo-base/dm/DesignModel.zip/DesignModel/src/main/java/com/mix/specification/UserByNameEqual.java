package com.mix.specification;

/**
 * 姓名相同的规格书
 * @author byht
 *
 */
public class UserByNameEqual extends CompositeSpecification{
	//基准姓名
	private String name;
	
	public UserByNameEqual(String name){
		this.name = name;
	}

	@Override
	public boolean isSatisfiedBy(User user) {
		// TODO Auto-generated method stub
		return user.getName().equals(name);
	}
	
	
}
