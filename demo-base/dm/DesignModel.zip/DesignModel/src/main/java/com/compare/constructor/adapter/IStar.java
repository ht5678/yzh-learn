package com.compare.constructor.adapter;

//明星接口
public interface IStar {
	//明星演戏
	public void action(String context);
}
