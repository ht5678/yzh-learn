package com.design.mediator;

public class ConcreteColleague1 extends Colleague {

	public ConcreteColleague1(Mediator mediator) {
		super(mediator);
	}

	@Override
	public void action() {
		// TODO Auto-generated method stub
		System.out.println("这是同事1的行动方法");
	}

}
