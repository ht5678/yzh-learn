package com.design.state.demo;

public class CCTV3 implements Channel {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("CCTV3 非常6+1");
	}

}
