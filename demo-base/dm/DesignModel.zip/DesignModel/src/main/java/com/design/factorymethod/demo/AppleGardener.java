package com.design.factorymethod.demo;

public class AppleGardener implements FruitGardener{

	@Override
	public Fruit factory() {
		// TODO Auto-generated method stub
		return new Apple();
	}

}
