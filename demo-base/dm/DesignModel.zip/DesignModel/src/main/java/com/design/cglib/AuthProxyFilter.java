package com.design.cglib;

import java.lang.reflect.Method;

import net.sf.cglib.proxy.CallbackFilter;


/**
 * 
 * ---2.
 * 由于query功能用户maurice才能使用，招来其他用户的强烈的抱怨，所以权限再次变更，只有create，update，delete，
 * 才需要权限保护,query任何人都可以使用。 怎么办？采用AuthProxy，使得InfoManager中的所有方法都被代理，加上了权限的判断。
 * 当然，最容易想到的办法，就是在AuthProxy的intercept的方法中再做下判断，如果代理的method是query，不需要权限验证。
 * 这么做，可以，但是一旦逻辑比较复杂的时候，intercept这个方法要做的事情会很多，逻辑会异常的复杂。 
 *幸好，cglib还提供了CallbackFilter。使用CallbackFilter，可以明确表明，被代理的类（InfoManager）中不同的方法，
 *被哪个拦截器（interceptor)拦截。 
 * @author byht
 *
 */
public class AuthProxyFilter implements CallbackFilter{

	private static final int AUTH_NEED = 0 ;
	private static final int AUTH_NOT_NEED = 1;
	
	 /** 
     * <pre> 
     * 选择使用的proxy 
     * 如果调用query函数，则使用第二个proxy 
     * 否则，使用第一个proxy 
     * </pre> 
     */  
	public int accept(Method method) {
		if("query".equals(method.getName())){
			return AUTH_NOT_NEED;
		}
		return AUTH_NEED;
	}

}
