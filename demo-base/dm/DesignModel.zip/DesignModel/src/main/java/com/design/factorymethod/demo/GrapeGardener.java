package com.design.factorymethod.demo;

public class GrapeGardener implements FruitGardener{

	@Override
	public Fruit factory() {
		// TODO Auto-generated method stub
		return new Grape();
	}

}
