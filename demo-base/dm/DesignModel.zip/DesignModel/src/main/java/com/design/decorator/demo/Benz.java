package com.design.decorator.demo;

public class Benz implements Car{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("奔驰车的默认颜色是黑色");
	}

}
