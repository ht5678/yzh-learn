package com.design.bridge.demo;

public class Green implements Color{

	@Override
	public String getColor() {
		// TODO Auto-generated method stub
		return "绿色";
	}

}
