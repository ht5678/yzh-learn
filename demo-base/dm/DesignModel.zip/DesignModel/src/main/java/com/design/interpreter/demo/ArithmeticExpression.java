package com.design.interpreter.demo;

public interface ArithmeticExpression {

	int interpret(Variables variables);
}
