package com.design.builder.demo;

public interface ComputerBuilder {

	void buildCpu();//建造cpu
	void buildRam();//建造内存
	void buildHardDisk();//建造硬盘
	void buildGraphicCard();//建造显卡
	void buildMonitor();//建造显示器
	void bildOs();//建造操作系统
	
	Computer getResult();//得到建造好的计算机
	
}
