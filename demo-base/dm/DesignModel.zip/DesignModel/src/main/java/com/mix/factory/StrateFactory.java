package com.mix.factory;

/**
 * 策略工厂
 * @author 岳志华
 *
 */
public class StrateFactory {

	public static IDeduction getDeduction(StrategyMan strategy){
		IDeduction deduction = null;
		try{
			deduction = (IDeduction) Class.forName(strategy.getValue()).newInstance();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		return deduction;
	}
}
