package com.compare.behavior.command;

//gzip接收者
public class GzipReceiver implements IReceiver{

	@Override
	public boolean compress(String source, String to) {
		System.out.println(source+"--->"+to+"--gzip压缩成功");
		return true;
	}

	@Override
	public boolean uncompress(String source, String to) {
		System.out.println(source+"--->"+to+"--gzip解压缩成功");
		return true;
	}

}
