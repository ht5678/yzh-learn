package com.design.decorator;

public abstract class Decorator implements Component{
	
	private Component component = null;
	
	public Decorator(Component component){
		this.component = component;
	}

	@Override
	public void operation() {
		// TODO Auto-generated method stub
		component.operation();
	}

}
