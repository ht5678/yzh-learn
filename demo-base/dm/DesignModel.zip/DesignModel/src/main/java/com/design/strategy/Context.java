package com.design.strategy;

//环境角色
public class Context {

	private Strategy strategy = null;
	
	//构造函数
	public Context(Strategy strategy){
		this.strategy = strategy;
	}
	
	//调用策略方法
	public  void contextInterface(){
		this.strategy.strategyInterface();
	}
	
}
