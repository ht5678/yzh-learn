package com.design.strategy;

//抽象策略类
public abstract class Strategy {

	//策略方法
	public abstract void strategyInterface();
}
