package com.compare.create.abstractfactory;

public interface ISpiderMan {

	//发出蛛丝
	public void launchSilk();
}
