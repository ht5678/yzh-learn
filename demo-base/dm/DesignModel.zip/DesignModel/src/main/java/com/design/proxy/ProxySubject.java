package com.design.proxy;

public class ProxySubject implements subject{

	private subject sub;
	
	public ProxySubject(subject sub){
		this.sub = sub;
	}
	
	@Override
	public void request() {
		// TODO Auto-generated method stub
		this.beforeRequest();
		sub.request();
		this.afterRequest();
	}
	
	//请求前的操作
	public void beforeRequest(){
		System.out.println("预处理");
	}
	
	
	public void afterRequest(){
		System.out.println("善后处理");
	}
	
}
