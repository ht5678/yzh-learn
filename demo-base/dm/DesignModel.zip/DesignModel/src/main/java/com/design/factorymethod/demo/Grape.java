package com.design.factorymethod.demo;

public class Grape implements Fruit{

	private boolean seedless;
	
	public boolean isSeedless() {
		return seedless;
	}

	public void setSeedless(boolean seedless) {
		this.seedless = seedless;
	}

	@Override
	public void grow() {
		// TODO Auto-generated method stub
		System.out.println("葡萄正在生长。。。");
	}

	@Override
	public void harvest() {
		// TODO Auto-generated method stub
		System.out.println("收获葡萄");
	}

	@Override
	public void plant() {
		// TODO Auto-generated method stub
		System.out.println("栽种葡萄");
	}

	
	
}
