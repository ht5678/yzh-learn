package com.design.adapter.demo;

public class FoodAdapter extends ShuiJiao implements HunDun{

	@Override
	public void makeHunDun() {
		// TODO Auto-generated method stub
		super.makeShuiJiao();
		System.out.println("馄饨和睡觉一样是以面包馅的食品");
	}

	
}
