package com.design.builder.demo;

public class ComputerDirector {

	ComputerBuilder builder;
	
	//构造T410型计算机
	public T410 constructT410(){
		builder = new T401Builder();
		builder.buildCpu();
		builder.bildOs();
		builder.buildGraphicCard();
		builder.buildHardDisk();
		builder.buildMonitor();
		builder.buildRam();
		return (T410)builder.getResult();
	}
	
	//构造X201型计算机
	public X201 constructX201(){
		builder = new X201Builder();
		builder.buildCpu();
		builder.bildOs();
		builder.buildHardDisk();
		builder.buildMonitor();
		builder.buildRam();
		return (X201)builder.getResult();
	}
	
}
