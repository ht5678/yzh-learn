package com.mix.command;

public class LS_L extends AbstractLS {

	@Override
	protected String getOperateParam() {
		// TODO Auto-generated method stub
		return super.L_PARAM;
	}

	@Override
	protected String echo(CommandVO vo) {
		// TODO Auto-generated method stub
		return FileManager.ls_l(vo.getCommandName());
	}

}
