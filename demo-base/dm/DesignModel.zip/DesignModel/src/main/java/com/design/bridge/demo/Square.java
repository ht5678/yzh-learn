package com.design.bridge.demo;

public class Square extends AbstractShape{

	public Square(Color color){
		super(color);
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("使用"+color.getColor()+"画正方形");
	}
	
}
