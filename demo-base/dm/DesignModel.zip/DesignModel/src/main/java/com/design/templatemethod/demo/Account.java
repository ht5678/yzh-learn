package com.design.templatemethod.demo;

/**
 * 抽象模板，抽象用户类
 * @author 岳志华
 *
 */
public abstract class Account {
	//账号
	private String accountNumber;
	
	//构造函数
	public Account(){
		accountNumber = null;
	}
	
	public Account(String number){
		accountNumber = number;
	}
	//基本方法，确定账户类型，留给子类实现
	protected abstract String getAccountType();
	//基本方法，确定利息，留给子类实现
	protected abstract double getInterestRate();
	//基本方法，根据账户类型和账号确定账户金额
	public double calculateAmout(String accountType , String accountNumber){
		//访问数据库
		return 4567.34D;
	}
	//模板方法，计算账户利息
	public double calculateInterest(){
		String type = getAccountType();
		double rate = getInterestRate();
		double amount = calculateAmout(type, accountNumber);
		return rate*amount;
	}
}
