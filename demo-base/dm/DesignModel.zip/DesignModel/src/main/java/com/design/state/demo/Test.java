package com.design.state.demo;

public class Test {

	public static void main(String[] args) {
		TV tv = new TV();
		//换台
		tv.disCCTV1();
		tv.disCCTV2();
		tv.disCCTV3();
	}
}
