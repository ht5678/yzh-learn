package com.compare.create.abstractfactory;


public class ChildSpiderMan implements ISpiderMan{

	@Override
	public void launchSilk() {
		// TODO Auto-generated method stub
		System.out.println("幼年蜘蛛侠发射出5米场的蛛丝");
	}

}
