package com.mix.specification;

/**
 *	用户类
 * @author byht
 *
 */
public class User {
	//姓名
	private String name;
	//年龄
	private int age;
	
	public User(String name , int age){
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	//显示信息
	public void show(){
		System.out.println("用户名："+this.name+"\t年龄:"+this.age);
	}
}
