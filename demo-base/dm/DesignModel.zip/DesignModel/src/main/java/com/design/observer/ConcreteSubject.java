package com.design.observer;

import java.util.Enumeration;
import java.util.Vector;

public class ConcreteSubject implements Subject {
	private Vector<Observer> obsVector = new Vector<>();

	@Override
	public void attach(Observer obs) {
		// TODO Auto-generated method stub
		obsVector.add(obs);
	}

	@Override
	public void detach(Observer obs) {
		// TODO Auto-generated method stub
		obsVector.remove(obs);
	}

	@Override
	public void notifyObserver() {
		// TODO Auto-generated method stub
		for(Observer o : obsVector){
			o.update();
		}
	}
	
	//返回观察者集合的Enumeration对象
	public Enumeration<Observer> observers(){
		return obsVector.elements();
	}
	
	//业务方法，改变状态
	public void change(){
		this.notifyObserver();
	}

}
