package com.design.iterator;

public interface Aggregate {

	public void add(Object obj);
	
	public Iterator creatIterator();
	
}
