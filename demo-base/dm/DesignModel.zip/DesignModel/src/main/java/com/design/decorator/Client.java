package com.design.decorator;

/**
 * 测试类
 * @author yuezhihua
 *
 */
public class Client {

	public static void main(String[] args) {
		Component component = new ConcreteComponent();
		//进行粉饰
		Decorator decorator = new ConcreteDecorator(component);
		decorator.operation();
	}
	
}
