package com.compare.behavior.command;

//
public class GzipUncompressCmd extends AbstractCmd{

	@Override
	public boolean execute(String source, String to) {
		// TODO Auto-generated method stub
		return super.gzip.uncompress(source, to);
	}

	
}
