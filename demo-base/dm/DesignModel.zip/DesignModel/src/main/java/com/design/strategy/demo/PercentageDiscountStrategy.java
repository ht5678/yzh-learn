package com.design.strategy.demo;

public class PercentageDiscountStrategy extends DiscountStrategy{

	public PercentageDiscountStrategy(double price, int number) {
		super(price, number);
	}

	//实现策略方法，15%的折扣额
	@Override
	public double calculateDiscount() {
		// TODO Auto-generated method stub
		return getNumber()*getPrice()*0.15;
	}

}
