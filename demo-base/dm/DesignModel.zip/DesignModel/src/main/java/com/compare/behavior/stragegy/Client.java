package com.compare.behavior.stragegy;

public class Client {

	
	public static void main(String[] args) {
		//定义环境角色
		Context context = null;
		//对文件进行zip压缩算法
		System.out.println("--------------------执行zip算法-------------");
		context = new Context(new Zip());
		//执行压缩算法
		context.compress("c:\\gx", "d:\\gx.zip");
		context.uncompress("d:\\gx.zip", "e:\\gx");
		//对文件进行gzip压缩算法
		System.out.println("--------------------执行gzip算法-------------");
		context = new Context(new Gzip());
		context.compress("/teacher", "/home/teacher.gz");
		context.uncompress("/home/teacher.gz", "/teacher");
	}
}
