package com.design.proxy;


public class RealSubject implements subject {

	@Override
	public void request() {
		// TODO Auto-generated method stub
		System.out.println("业务逻辑处理");
	}

}
