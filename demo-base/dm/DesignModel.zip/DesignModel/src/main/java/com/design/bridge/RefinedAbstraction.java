package com.design.bridge;

public class RefinedAbstraction extends Abstraction{

	public RefinedAbstraction(Implementor imp) {
		super(imp);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void operation() {
		System.out.println("RefinedAbstraction业务代码");
	}
	
	

}
