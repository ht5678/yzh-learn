package com.design.interpreter.demo;

public class Plus implements ArithmeticExpression {

	ArithmeticExpression left;
	ArithmeticExpression right;
	
	public Plus(ArithmeticExpression left,ArithmeticExpression right){
		this.left = left;
		this.right = right;
	}
	
	@Override
	public int interpret(Variables variables) {
		// TODO Auto-generated method stub
		return left.interpret(variables)+right.interpret(variables);
	}

}
