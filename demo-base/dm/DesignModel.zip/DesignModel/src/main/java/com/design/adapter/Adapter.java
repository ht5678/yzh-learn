package com.design.adapter;

public class Adapter extends Adaptee implements Target{

	@Override
	public void request() {
		// TODO Auto-generated method stub
		super.specificRequest();
	}

}
