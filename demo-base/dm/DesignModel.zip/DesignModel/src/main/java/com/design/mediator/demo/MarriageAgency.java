package com.design.mediator.demo;

public interface MarriageAgency {

	void pair(Person person);//为person配对
	void register(Person person);//注册会员
	
}
