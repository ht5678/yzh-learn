package com.design.observer;

public class ConcreteObserver implements Observer {

	@Override
	public void update() {
		// TODO Auto-generated method stub
		System.out.println("收到通知，并且进行更新");
	}

}
