package com.design.visitor;

//具体元素2
public interface Visitor {
	//可以访问那些对象s
	public void visit(ConcreteElement1 e1);
	public void visit(ConcreteElement2 e2);
}
