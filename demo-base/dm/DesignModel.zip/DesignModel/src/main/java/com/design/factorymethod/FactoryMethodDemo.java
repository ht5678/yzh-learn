package com.design.factorymethod;

public class FactoryMethodDemo {

	public static void main(String[] args) {
		Creator creator = new ConcreteCreator();
		Product product = creator.factory(Product.class);
		/**
		 * 继续业务处理
		 */
	}
	
}
