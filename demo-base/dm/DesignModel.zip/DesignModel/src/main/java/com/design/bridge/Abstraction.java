package com.design.bridge;

public abstract class Abstraction {

	private Implementor imp;
	
	public Abstraction(Implementor imp){
		this.imp = imp;
	}
	
	public void operation(){
		this.imp.operationImp();
	}
}
