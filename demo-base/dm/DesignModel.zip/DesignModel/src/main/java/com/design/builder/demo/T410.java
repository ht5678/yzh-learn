package com.design.builder.demo;

public class T410 extends Computer{

	private String graphicCard;
	
	public T410(){
		this.setType("ThinkPad T410i");
	}

	public String getGraphicCard() {
		return graphicCard;
	}

	public void setGraphicCard(String graphicCard) {
		this.graphicCard = graphicCard;
	}

	@Override
	public String toString() {
		return "T410 [graphicCard=" + graphicCard + ", getGraphicCard()="
				+ getGraphicCard() + ", getType()=" + getType() + ", getCpu()="
				+ getCpu() + ", getRam()=" + getRam() + ", getHardDisk()="
				+ getHardDisk() + ", getMonitor()=" + getMonitor()
				+ ", getOs()=" + getOs() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	
	
}
