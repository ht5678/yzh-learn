package com.design.prototype;

public class Client {

	public void operation(Prototype example){
		//得到example的副本
		Prototype p = example.clone();
	}
	
}
