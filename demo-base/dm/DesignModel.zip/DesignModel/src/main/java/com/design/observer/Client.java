package com.design.observer;

public class Client {

	public static void main(String[] args) {
		//创建一个主体对象
		ConcreteSubject subject = new ConcreteSubject();
		//创建一个观察者
		Observer obs = new ConcreteObserver();
		//登记观察者
		subject.attach(obs);
		//改变状态
		subject.change();
	}
}
