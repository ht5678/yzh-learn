package com.test.observable;

import java.util.Observable;

/**
 * jdk实现的观察者模式
 * 
 * ***接口 java.util.Observer 用来指定观察者，观察者必须实现 void update(Observable o, Object arg) 方法。
 * 
 * ***java.util.Observable 用来指定观察物（被观察者、可被观察的），并且提供了一系列的方法。
 * 读者可以很轻易的使用这个接口和实现类来实现观察者模式。
 * 
 * 其中 Observable o 可被看作事件源。 Object arg 可被看作消息。
 * 
 * java.util.Observer 只有一个简单的方法 void update(Observable o, Object arg)
 *	其中，参数 Observable o 用于指定触发 update 方法的对象， Object arg 用于指定触发 update 方法时候的附加参数。
 *
 * @author byht
 *
 */
public class Publisher extends Observable {
    
    private String magazineName;
    

    public String getMagazineName() {
        return magazineName;
    }
    
    public void publish(String magazineName) {
        this.magazineName = magazineName;
        setChanged();
        notifyObservers(this);
    }
    
}