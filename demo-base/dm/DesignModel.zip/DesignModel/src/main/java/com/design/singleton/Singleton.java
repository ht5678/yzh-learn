package com.design.singleton;

/**
 * 单例模式的定义-----饿汉式
 * @author 岳志华
 *
 */
public class Singleton {

	private static Singleton instance = new Singleton();
	
	//构造方法私有，保证外界无法实例化
	private Singleton(){
		
	}
	
	public static Singleton getInstance(){
		return instance;
	}
}
