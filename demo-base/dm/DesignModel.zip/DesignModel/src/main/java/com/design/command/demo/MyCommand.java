package com.design.command.demo;

//抽象命令角色
public interface MyCommand {

	public void execute();
}
