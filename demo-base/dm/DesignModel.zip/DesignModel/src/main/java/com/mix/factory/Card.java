package com.mix.factory;

//IC卡类
public class Card {
	//IC卡号
	private String cardNo;
	//卡内的固定金额
	private double steadyMoney = 0;
	//自由交易金额
	private double freeMoney = 0;
	//构造函数
	public Card(String cardNo, double steadyMoney, double freeMoney) {
		super();
		this.cardNo = cardNo;
		this.steadyMoney = steadyMoney;
		this.freeMoney = freeMoney;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public double getSteadyMoney() {
		return steadyMoney;
	}
	public void setSteadyMoney(double steadyMoney) {
		this.steadyMoney = steadyMoney;
	}
	public double getFreeMoney() {
		return freeMoney;
	}
	public void setFreeMoney(double freeMoney) {
		this.freeMoney = freeMoney;
	}
	
	//输出IC卡中的信息
	public void showCard(){
		System.out.println("IC卡号:"+this.cardNo);
		System.out.println("固定金额:"+this.steadyMoney);
		System.out.println("自由金额:"+this.freeMoney);
	}
}
