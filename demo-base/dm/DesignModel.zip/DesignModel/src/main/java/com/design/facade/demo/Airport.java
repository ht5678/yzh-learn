package com.design.facade.demo;

public class Airport {

	public void bookTicket(String from , String to){
		System.out.println("订购了从"+from +"到"+to+"的机票");
	}
	
}
