package com.design.facade.demo;

/**
 * 司机
 * @author byht
 *
 */
public class Chauffeur {

	public void drive(String to){
		System.out.println("司机开车去"+to);
	}
}
