package com.design.command.demo;

import javax.swing.JButton;

public class ExitCommand extends JButton implements MyCommand{

	public ExitCommand(String name){
		super(name);
	}
	
	//构造函数
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		System.exit(0);
	}

}
