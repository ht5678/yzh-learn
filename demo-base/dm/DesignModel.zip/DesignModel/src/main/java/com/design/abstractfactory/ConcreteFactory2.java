package com.design.abstractfactory;

public class ConcreteFactory2 implements AbstractFactory{

	//创建等级为2的产品
	@Override
	public ProductA factoryA() {
		// TODO Auto-generated method stub
		return new ProductA2();
	}

	//创建等级为2的产品	
	@Override
	public ProductB factoryB() {
		// TODO Auto-generated method stub
		return new ProductB2();
	}

}
