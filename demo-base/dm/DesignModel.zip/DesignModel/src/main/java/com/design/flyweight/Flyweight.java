package com.design.flyweight;

public interface Flyweight {

	//业务方法
	public abstract void operation(String extrinsicState);//外部状态
	
}
