package com.design.visitor.demo;

public abstract class Hardware {

	String type;
	
	public Hardware(String type){
		this.type = type;
	}
	
	public String getType(){
		return type;
	}
	//运转
	public abstract void run();
	//接受计算机访问者
	public abstract void accept(ComputerVisitor computerVisitor);
}
