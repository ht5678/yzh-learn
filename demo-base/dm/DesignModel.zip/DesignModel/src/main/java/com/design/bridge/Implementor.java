package com.design.bridge;

public interface Implementor {
	//方法的实现化实现
	public void operationImp();
	
}
