package com.design.abstractfactory;

public class ProductA1 implements ProductA{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		System.out.println("等级为1的产品A的实现方法");
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		System.out.println("业务逻辑方法");
	}

}
