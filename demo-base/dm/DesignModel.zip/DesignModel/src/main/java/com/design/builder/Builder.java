package com.design.builder;

/**
 * 建造者模式
 * @author 岳志华
 *
 */
public abstract class Builder {

	//设置产品的不同部分，以获得不同的产品
	public abstract void setPart1();
	public abstract void setPart2();
	public abstract void setPart3();
	//其他组件,,,
	
	//建造产品
	public abstract Product builderProduct();
	
	
}
