package com.design.adapter.demo;

public class ShuiJiao {

	public void makeShuiJiao(){
		System.out.println("调制菜馅");
		System.out.println("擀面皮");
		System.out.println("包饺子");
	}
	
}
