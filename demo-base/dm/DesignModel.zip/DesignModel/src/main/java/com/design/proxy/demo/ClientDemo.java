package com.design.proxy.demo;

public class ClientDemo {

	public static void main(String[] args) {
		IGamePlayer player = new GamePlayer("zhangsan");
		GamePlayerProxy proxy = new GamePlayerProxy(player);
		proxy.killBoss();
		proxy.upGrad();
	}
	
}
