package com.design.composite;

public class Leaf implements Component{

	@Override
	public void operation() {
		// TODO Auto-generated method stub
		System.out.println("叶子节点业务代码");
	}

}
