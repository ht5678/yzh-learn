package com.design.visitor.demo;

public class TypeVisitor implements ComputerVisitor {

	@Override
	public void visitCPU(CPU cpu) {
		// TODO Auto-generated method stub
		System.out.println("CPU型号"+cpu.type);
	}

	@Override
	public void visitHarddisk(Harddisk harddisk) {
		// TODO Auto-generated method stub
		System.out.println("硬盘型号"+harddisk.type);
	}

}
