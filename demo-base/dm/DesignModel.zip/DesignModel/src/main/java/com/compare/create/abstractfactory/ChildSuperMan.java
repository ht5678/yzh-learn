package com.compare.create.abstractfactory;


public class ChildSuperMan implements ISuperMan{

	@Override
	public void specicalTalent() {
		// TODO Auto-generated method stub
		System.out.println("未成年超人快速移动");
	}

}
