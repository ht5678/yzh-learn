package com.design.factorymethod;

public interface Product {

	//产品的公共方法
	public void method1();
	
	public void method2();
	
}
