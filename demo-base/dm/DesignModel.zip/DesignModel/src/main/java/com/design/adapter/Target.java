package com.design.adapter;

public interface Target {

	public void request();
	
}
