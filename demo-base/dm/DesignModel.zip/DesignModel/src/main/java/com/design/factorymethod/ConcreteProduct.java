package com.design.factorymethod;

public class ConcreteProduct implements Product{

	@Override
	public void method1() {
		// TODO Auto-generated method stub
		//业务逻辑处理代码
	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub
		//业务逻辑处理代码
	}

}
