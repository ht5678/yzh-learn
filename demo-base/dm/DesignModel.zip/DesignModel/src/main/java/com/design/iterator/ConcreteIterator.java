package com.design.iterator;

public class ConcreteIterator implements Iterator {
	private ConcreteAggregate agg;
	private int index = 0;
	private int size=0;
	
	 public ConcreteIterator(ConcreteAggregate agg){
		 this.agg = agg;
		 size = agg.size();
		 index = 0;
	 }

	 //返回下一个元素
	@Override
	public Object next() {
		// TODO Auto-generated method stub
		if(index<size){
			return agg.getElement(index++);
		}else{
			return null;
		}
	}
	
	//是否有下一个元素
	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return index<size;
	}

}
