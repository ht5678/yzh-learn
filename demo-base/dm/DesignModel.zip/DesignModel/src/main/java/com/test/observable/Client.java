package com.test.observable;


/**
 * 测试方法
 * @author byht
 *
 */
public class Client {
	
    public static void main(String[] args) {
        Publisher publisher = new Publisher();
        publisher.publish("Kent.Kuan的技术空间");
    }
    
}
