package com.design.strategy;

public class ConcreteStrategy extends Strategy{

	//实现策略方法
	@Override
	public void strategyInterface() {
		// TODO Auto-generated method stub
		System.out.println("具体算法");
	}

}
