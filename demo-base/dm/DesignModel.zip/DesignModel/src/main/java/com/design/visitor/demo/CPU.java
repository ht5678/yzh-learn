package com.design.visitor.demo;

public class CPU extends Hardware {

	public CPU(String type) {
		super(type);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("型号为"+type+"的cpu正在运转");
	}

	@Override
	public void accept(ComputerVisitor computerVisitor) {
		// TODO Auto-generated method stub
		computerVisitor.visitCPU(this);
	}

}
