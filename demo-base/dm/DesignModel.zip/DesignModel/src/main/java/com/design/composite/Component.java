package com.design.composite;

//定义抽象构件接口
public interface Component {

	public void operation();
	
}
