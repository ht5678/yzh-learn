package com.design.proxy.demo;

public interface IGamePlayer {

	public void killBoss();//杀怪
	
	public void upGrad();//升级
	
}
