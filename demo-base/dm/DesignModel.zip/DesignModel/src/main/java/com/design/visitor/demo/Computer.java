package com.design.visitor.demo;

public class Computer {

	private Hardware cpu;
	
	private Hardware harddisk;
	
	public Computer(){
		this.cpu = new CPU("Intel Core i7-620");
		this.harddisk = new Harddisk("Seagate 500G 7200转");
	}
	
	public void accept(ComputerVisitor computerVisitor){
		cpu.accept(computerVisitor);
		harddisk.accept(computerVisitor);
	}
}
