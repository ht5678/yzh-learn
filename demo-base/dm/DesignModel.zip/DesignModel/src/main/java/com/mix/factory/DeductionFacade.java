package com.mix.factory;

/**
 * 扣款模块封装
 * @author 岳志华
 *
 */
public class DeductionFacade {

	//获得对应消费策略
	private static StrategyMan getDeductionType(Trade trade){
		if(trade.getTradeNo().substring(0, 3).equals("000")){
			return StrategyMan.SteadyDeduction;
		}else{
			return StrategyMan.FreeDeduction;
		}
	}
	
	//对外公布扣款的操作
	public static void deduct(Card card , Trade trade){
		//获得消费策略
		StrategyMan sm = getDeductionType(trade);
		//根据消费策略获取消费策略对象
		IDeduction deduction = StrateFactory.getDeduction(sm);
		//进行扣款处理
		if(deduction.exec(card, trade)){
			System.out.println("=================交易凭证===============");
			System.out.println(trade.getTradeNo()+"交易成功");
			System.out.println("交易金额为：￥"+trade.getAmount());
			System.out.println("========================================");
		}else{
			System.out.println("=================交易失败===============");
		}
	}
}
