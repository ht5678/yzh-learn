package com.design.adapter;

public class Adaptee {

	//原有业务处理
	public void specificRequest(){
		System.out.println("原有业务处理");
	}
}
