package com.design.responsibility;

public class ConcreteHandler extends Handler{

	//处理请求
	@Override
	public void handleRequest() {
		// TODO Auto-generated method stub
		if(getSuccessor()!=null){
			System.out.println("请求传递给"+getSuccessor());
			getSuccessor().handleRequest();
		}else{
			System.out.println("请求处理");
		}
	}

}
