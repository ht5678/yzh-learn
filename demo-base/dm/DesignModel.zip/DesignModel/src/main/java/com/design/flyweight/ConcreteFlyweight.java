package com.design.flyweight;

public class ConcreteFlyweight implements Flyweight {
	
	private String intrinsicState;//内部状态
	
	ConcreteFlyweight(String intrinstricState){
		this.intrinsicState = intrinstricState;
	}

	@Override
	public void operation(String extrinsicState) {
		// TODO Auto-generated method stub
		System.out.println("内部状态:"+intrinsicState+",外部状态："+extrinsicState);
	}

}
