package com.design.proxy.demo;

import java.util.Date;

public class GamePlayerProxy implements IGamePlayer{

	private IGamePlayer player = null;
	
	public GamePlayerProxy(IGamePlayer player){
		this.player = player;
	}
	
	private void log(){
		System.out.println("打怪时间"+new Date().toString());
	}
	
	@Override
	public void killBoss() {
		// TODO Auto-generated method stub
		this.log();
		player.killBoss();
	}

	@Override
	public void upGrad() {
		// TODO Auto-generated method stub
		player.upGrad();
	}

}
