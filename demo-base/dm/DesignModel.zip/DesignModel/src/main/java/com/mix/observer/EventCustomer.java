package com.mix.observer;

import java.util.Vector;

/**
 * 抽象事件处理类
 * @author 岳志华
 *
 */
public abstract class EventCustomer {

	private Vector<ProductEventType> vector = new Vector<>();
	
	public EventCustomer(ProductEventType type){
		vector.add(type);
	}
	
	public void addEventType(ProductEventType type){
		vector.add(type);
	}
	
	public Vector<ProductEventType> getCustomType(){
		return vector;
	}
	
	public abstract void exec(ProductEvent event);
}
