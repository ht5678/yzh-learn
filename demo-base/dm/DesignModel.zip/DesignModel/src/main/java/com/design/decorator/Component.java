package com.design.decorator;

public interface Component {
	
	public void operation();

}
