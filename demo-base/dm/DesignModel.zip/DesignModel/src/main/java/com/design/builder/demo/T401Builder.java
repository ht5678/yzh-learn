package com.design.builder.demo;

public class T401Builder implements ComputerBuilder{

	private T410 computer = new T410();
	
	@Override
	public void buildCpu() {
		// TODO Auto-generated method stub
		computer.setCpu("i5-450");
	}

	@Override
	public void buildRam() {
		// TODO Auto-generated method stub
		computer.setRam("4GB 1333MHz");
	}

	@Override
	public void buildHardDisk() {
		// TODO Auto-generated method stub
		computer.setHardDisk("500G 7200转");
	}

	@Override
	public void buildGraphicCard() {
		// TODO Auto-generated method stub
		computer.setGraphicCard("Nvidia NVS 3100M");
	}

	@Override
	public void buildMonitor() {
		// TODO Auto-generated method stub
		computer.setMonitor("14英寸 1280*800");
	}

	@Override
	public void bildOs() {
		// TODO Auto-generated method stub
		computer.setOs("windows 7 旗舰版");
	}

	@Override
	public Computer getResult() {
		// TODO Auto-generated method stub
		return computer;
	}

}
