package com.design.visitor.demo;


public class RunVisitor implements ComputerVisitor{

	@Override
	public void visitCPU(CPU cpu) {
		// TODO Auto-generated method stub
		cpu.run();
	}

	@Override
	public void visitHarddisk(Harddisk harddisk) {
		// TODO Auto-generated method stub
		harddisk.run();
	}


}
