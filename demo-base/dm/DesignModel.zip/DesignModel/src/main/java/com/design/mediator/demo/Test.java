package com.design.mediator.demo;

public class Test {
	
	public static void main(String[] args) {
		MarriageAgency agency = new MarriageAgencyImpl();
		
		Person m1 = new Man("john", 20, Sex.MALE, 18, agency);
		Person m2 = new Man("mike", 27, Sex.MALE, 25, agency);
		Person w1 = new Women("Marry", 25, Sex.FEMALE, 27, agency);
		Person w2 = new Women("Jane", 20, Sex.FEMALE, 22, agency);
		
		m1.findPartner();
		m2.findPartner();
	}

}
