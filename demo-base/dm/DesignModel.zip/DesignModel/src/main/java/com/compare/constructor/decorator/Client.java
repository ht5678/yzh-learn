package com.compare.constructor.decorator;

//场景应用类
public class Client {
	
	public static void main(String[] args) {
		//明星自己演戏
		IStar star = new Star();
		star.action("表演10分钟");
		//再找替身演员替演
		IStar standin = new Standin();
		//对替身演员进行修饰
		standin = new ConcreteDecorator(standin);
		standin.action("表演5分钟");
	}
}
