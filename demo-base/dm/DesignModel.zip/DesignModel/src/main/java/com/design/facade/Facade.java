package com.design.facade;

public class Facade {

	//被委托的对象
	private ClassA a = new ClassA();
	private ClassB b = new ClassB();
	private ClassC c = new ClassC();
	
	public void methodA(){
		System.out.println("扩展method a");
		a.methodA();
	}
	
	public void methodB(){
		System.out.println("扩展method b");
		b.methodB();
	}
	
	public void methodC(){
		System.out.println("扩展method c");
		c.methodC();
	}
}
