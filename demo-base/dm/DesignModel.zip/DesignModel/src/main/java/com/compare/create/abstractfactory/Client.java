package com.compare.create.abstractfactory;

public class Client {

	public static void main(String[] args) {
		HeroFactory adultFactory = new AdultHeroFactory();
		ISuperMan adultSuperMan = adultFactory.createSuperMan();
		ISpiderMan adultSpiderMan = adultFactory.createSpiderMan();
		adultSuperMan.specicalTalent();
		adultSpiderMan.launchSilk();
		System.out.println("--------------------------");
		HeroFactory childFactory = new ChildHeroFactory();
		ISuperMan childSuperMan = childFactory.createSuperMan();
		ISpiderMan childSpiderMan = childFactory.createSpiderMan();
		childSuperMan.specicalTalent();
		childSpiderMan.launchSilk();
	}
}
