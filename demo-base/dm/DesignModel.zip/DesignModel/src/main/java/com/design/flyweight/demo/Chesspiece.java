package com.design.flyweight.demo;

public interface Chesspiece {
	void put(int x , int y);//落子
}
