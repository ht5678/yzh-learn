package com.design.facade.demo;

public class Boss {

	public static void main(String[] args) {
		Secretry secretry = new Secretry();
		System.out.println("老板告诉秘书要去上海出耗材10天");
		secretry.trip("上海", 10);
		System.out.println("----------------------------------");
		System.out.println("老板告诉秘书邀请8个人吃饭");
		secretry.repast(8);
	}
	
}
