package com.design.bridge.demo;

public interface Color {

	public String getColor();
	
}
