package com.design.strategy.demo;

//具体折扣，没有折扣算法
public class NoDiscountStrategy extends DiscountStrategy{

	public NoDiscountStrategy(double price, int number) {
		super(price, number);
	}

	//实现策略方法，0折扣额
	@Override
	public double calculateDiscount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
