package com.mix.specification;

import java.util.ArrayList;

/**
 * 场景应用
 * @author byht
 *
 */
public class Client {

	public static void main(String[] args) {
		//初始化一个用户列表
		ArrayList<User> userList =new ArrayList<>();
		userList.add(new User("张三", 23));
		userList.add(new User("李四", 61));
		userList.add(new User("王五", 65));
		userList.add(new User("张丽", 35));
		userList.add(new User("李鹏", 72));
		userList.add(new User("王艳", 18));
		userList.add(new User("王小二", 14));
		userList.add(new User("李张", 32));
		//定义一个用户查询类
		IUserProvider userProvider = new UserProvider(userList);
		//打印姓"张"de yonghu 
		System.out.println("==========姓张的用户:");
		for(User u : userProvider.findUser(new UserByNameLike("张%"))){
			u.show();
		}
		//打印年龄大于60的用户
		System.out.println("==========打印年龄大于60的用户:");
		for(User u : userProvider.findUser(new UserByAgeThan(60))){
			u.show();
		}
		//打印名字中包含"张"并且年龄大于30的用户
		System.out.println("===========打印名字中包含'张'并且年龄大于30的用户:");
		IUserSpecification spec1 = new UserByNameLike("%张%");
		IUserSpecification spec2 = new UserByAgeThan(30);
		for(User u : userProvider.findUser(spec1.and(spec2))){
			u.show();
		}
		//打印年龄小于20的用户
		System.out.println("=============打印年龄小于20的用户:");
		IUserSpecification spec = new UserByAgeThan(20);
		for(User u : userProvider.findUser(spec.not())){
			u.show();
		}
		
	}
}
