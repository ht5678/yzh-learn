package com.design.prototype.demo;

import java.util.UUID;

public class ClientDemo {
	//发送账单的数量，这个值是从数据库中获得的
	private static int MAX_COUNT=6;
	
	public static void main(String[] args) {
		//模拟发送邮件 
		//定义一个邮件对象
		Mail mail = new Mail("某商场五一抽奖活动"
				,"五一抽奖活动通知，凡是在五一期间在本场购物满100元的客户都有获得抽奖机会");
		mail.setTail("解释权归某商场所有");
		for(int i = 0 ; i < MAX_COUNT ;i++){
			//克隆邮件
			Mail cloneMail = mail.clone();
			//以下是每逢邮件不同的地方
			String info = UUID.randomUUID().toString();
			cloneMail.setAppellation(info);
			cloneMail.setReceiver(info+"@163.com");
			//发送邮件
			sendMail(cloneMail);
		}
		
	}

	public static void sendMail(Mail cloneMail){
		System.out.println("收件人："+cloneMail.getReceiver()+"  ...邮件发送成功");
	}

}
