package com.design.interpreter;

public class NonterminalExpression extends AbstractExpression{

	//每个非终结表达式都会对其他表达式产生依赖
	public NonterminalExpression(AbstractExpression expression){
		
	}
	
	public Object interpreter(Context ctx){
		//进行文法处理
		return null;
	}

}
