package com.mix.specification;

/**
 * 年龄大于指定年龄的规格书
 * @author byht
 *
 */
public class UserByAgeThan extends CompositeSpecification{

	//基准年龄
	private int age;
	
	public UserByAgeThan(int age){
		this.age = age;
	}
	//实现校验方法
	@Override
	public boolean isSatisfiedBy(User user) {
		// TODO Auto-generated method stub
		return user.getAge()>this.age;
	}

}
