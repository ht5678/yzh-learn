package com.design.interpreter.demo;

public class Variable implements ArithmeticExpression {

	@Override
	public int interpret(Variables variables) {
		// TODO Auto-generated method stub
		return variables.get(this);
	}

}
