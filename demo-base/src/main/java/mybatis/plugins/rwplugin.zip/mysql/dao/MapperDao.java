package com.lenovo.ofp.order.common.mysql.dao;

/**
 * 
 * @author yuezh2
 * @date 2020/06/29 15:30
 *
 * @param <T>
 */
public interface MapperDao<T>{
//        extends
//        BaseMapper<T>,
//        ConditionMapper<T>,
//        IdsMapper<T>,
//        InsertListMapper<T> {
	
}