package com.lenovo.ofp.order.common.mysql.datasource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * 	动态数据源类持有者,线程安全
 * 	持有动态数据源的信息，以及修改清理数据源
 * 
 * @author yuezh2
 * @date 2020/03/19 16:14
 *
 */
public class DynamicDataSourceHolder {
	

	private static final Logger LOGGER = LoggerFactory.getLogger(DynamicDataSourceHolder.class);
	
    //线程安全
    private static ThreadLocal<String> contextHolder = new ThreadLocal<String>();
    public static final String DB_MASTER = "master";
    public static final String DB_SLAVE = "slave";

    /**
     * 0
     * 	获取线程的dbType
     *
     * @return
     */
    public static String getDbType() {
        String db = contextHolder.get();
        if (db == null)
            db = DB_MASTER;
        
        LOGGER.debug(String.format("user datasource : %s", db));
        return db;
    }

    /**
     * 设置线程的dbType
     *
     * @param datasource 数据源类型
     */
    public static void setDbType(String datasource) {
        contextHolder.set(datasource);
    }

    /**
     * 	清理连接类型
     */
    public static void clearDbType() {
        contextHolder.remove();
    }

    /**
     * 	判断是否是使用主库，提高部分使用
     * @return
     */
    public static boolean isMaster() {
        return DB_MASTER.equals(getDbType());
    }
}
