package com.lenovo.ofp.order.common.mysql.dao;

/**
 * 
 * @author yuezh2
 *
 */
public interface BaseDao {
	


}
