def receive():
    print("这是来自 100xxx 的信息");
