function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

var Pview = initPView();
var pImgPro = {};

function initPView() {
  $(".p-view").on("click", "img", function (e) {
    showPzqImgView(this);
  });
}

function showPzqImgView(imgPro) {
  if (imgPro.parentElement.tagName == "A") {
    return;
  }

  var winWidth = $(window).width();
  var winHeight = $(window).height();
  var imgWidth = imgPro.naturalWidth;
  var imgHeight = imgPro.naturalHeight;

  if (winWidth < imgWidth) {
    imgWidth = winWidth;
    imgHeight = imgHeight - parseInt((imgWidth - winWidth) * (imgWidth / imgHeight));
  }

  if (winHeight < imgHeight) {
    imgHeight = winHeight;
    imgWidth = imgWidth - parseInt((imgHeight - winHeight) * (imgHeight / imgWidth));
  }

  pImgPro.src = imgPro.src;
  pImgPro.rotate = 0;
  pImgPro.change = false;
  pImgPro.scale = 100;
  pImgPro.height = imgHeight;
  pImgPro.width = imgWidth;
  pImgPro.top = parseInt(winHeight / 2 - pImgPro.height / 2);
  pImgPro.left = parseInt(winWidth / 2 - pImgPro.width / 2);
  var pImgViewMaskWrapper = '<div id="p_img_mask_wrapper" style="overflow:auto;"><div id="p-view-close-container"><div id="p-view-close"></div></div>';
  var pImgContainer = '<div id="p_img_container" style="left:' + pImgPro.left + 'px; top: ' + pImgPro.top + 'px;">';
  var pImgEl = '<img id="p_img" src="' + pImgPro.src + '" style="width: ' + pImgPro.width + 'px;" />';
  var pScaleTip = '<div id="p_img_tip"></div>';
  var pImgOpts = '<div id="p_img_opts">' + '<span id="p_img_plus_btn" title="放大"></span>' + '<span id="p_img_minus_btn" title="缩小"></span>' + '<span id="p_img_rotate_btn" title="旋转"></span>' + '<span id="p_img_reset_btn" title="重置"></span>' + '</div>';
  var endTag = "</div>";
  $('#p_img_mask_wrapper').remove();
  var appendHtml = pImgViewMaskWrapper + pImgContainer + pImgEl + endTag + pScaleTip + pImgOpts + endTag;
  $('body').append(appendHtml);
  initPViewEvent();
}

function initPViewEvent() {
  $('#p_img_mask_wrapper').unbind("click").bind("click", function () {
    Common.stopPropagation(event);
    $('#p_img_mask_wrapper').remove();
    pImgPro = {};
  });
  $('#p_img_container').unbind("click").bind("click", function () {
    Common.stopPropagation(event);
  });
  $('#p_img_plus_btn').unbind("click").bind("click", function () {
    Common.stopPropagation(event);
    pImgPro.scale += 10;

    if (pImgPro.scale >= 260) {
      pImgPro.scale = 260;
      $('#p_img_tip').html('已经是最大比例' + pImgPro.scale + '%').finish().fadeIn().delay(1500).fadeOut();
    } else {
      var scale = pImgPro.scale / 100;
      $('#p_img_tip').html(pImgPro.scale + '%').finish().fadeIn().delay(1500).fadeOut();
      $('#p_img').width(pImgPro.width * scale);
    }

    if (!pImgPro.change) {
      pImgToCenter();
    }
  });
  $('#p_img_minus_btn').unbind("click").bind("click", function () {
    Common.stopPropagation(event);
    pImgPro.scale -= 10;

    if (pImgPro.scale <= 0) {
      pImgPro.scale = 10;
      $('#p_img_tip').html('已是最小比例' + pImgPro.scale + "%").finish().fadeIn().delay(1500).fadeOut();
    } else {
      var scale = pImgPro.scale / 100;
      $('#p_img_tip').html(pImgPro.scale + '%').finish().fadeIn().delay(1500).fadeOut();
      $('#p_img').width(pImgPro.width * scale);
    }

    if (!pImgPro.change) {
      pImgToCenter();
    }
  });
  $('#p_img_rotate_btn').unbind("click").bind("click", function () {
    Common.stopPropagation(event);
    pImgPro.rotate = pImgPro.rotate + 90;

    if (pImgPro.rotate > 360) {
      pImgPro.rotate = 90;
    }

    $('#p_img_tip').html('旋转' + pImgPro.rotate + "度").finish().fadeIn().delay(1500).fadeOut();
    $('#p_img').css('transform', 'rotate(' + pImgPro.rotate + 'deg)');
  });
  $('#p_img_reset_btn').unbind("click").bind("click", function (event) {
    Common.stopPropagation(event);
    $('#p_img_tip').html('重置').finish().fadeIn().delay(1500).fadeOut();
    $('#p_img').width(pImgPro.width);
    $('#p_img').css('transform', 'rotate(0deg)');
    pImgToCenter();
    pImgPro.scale = 100;
    pImgPro.change = false;
  });
  var $pImg = $('#p_img_container');
  $pImg.bind("mousedown", function (downEvent) {
    Common.stopPropagation(downEvent);

    if (downEvent.button == 0) {
      $('#p_img_opts').hide();
      var imgOffset = $pImg.offset();
      var offsetX = downEvent.pageX - imgOffset.left;
      var offsetY = downEvent.pageY - imgOffset.top;
      $pImg.unbind('mousemove').bind('mousemove', function (moveEvent) {
        pImgPro.change = true;
        $pImg.css('left', moveEvent.pageX - offsetX + 'px');
        $pImg.css('top', moveEvent.pageY - offsetY + 'px');
        return false;
      });
      $pImg.unbind('mouseup').bind('mouseup', function () {
        $pImg.unbind('mousemove');
        $('#p_img_opts').show();
        return;
      });
    }

    return false;
  });
}

function pImgToCenter() {
  var winWidth = $(window).width();
  var winHeight = $(window).height();
  var imgW = $('#p_img').width();
  var imgH = $('#p_img').height();
  $('#p_img_container').css({
    "left": winWidth / 2 - imgW / 2 + "px",
    "top": winHeight / 2 - imgH / 2
  });
}
/*
 * 替换html标签
 * */


var EscapeSequence = {
  // 正则去掉非法标签<html> <javascript> 多余换行及空格, 除<br>
  filterHtmlJsSpaceEnter: function filterHtmlJsSpaceEnter(str) {
    if (str && str.length > 0) {
      str = str.replace(/[\s| | ]*\r/gi, ' ');
      str = str.replace(/<(?!br([/]*)>)[^>]*>/gi, "");
    }

    return str;
  },
  // 用正则表达式实现html转码
  htmlEncodeByRegExp: function htmlEncodeByRegExp(str) {
    var s = "";
    if (str.length == 0) return "";
    s = str.replace(/&/g, "&amp;");
    s = s.replace(/</g, "&lt;");
    s = s.replace(/>/g, "&gt;");
    s = s.replace(/ /g, " ");
    s = s.replace(/\'/g, "&#39;");
    s = s.replace(/\"/g, "&quot;");
    return s;
  },
  // 用正则表达式实现html解码
  htmlDecodeByRegExp: function htmlDecodeByRegExp(str) {
    var s = "";
    if (str.length == 0) return "";
    s = str.replace(/&amp;/g, "&");
    s = s.replace(/&lt;/g, "<");
    s = s.replace(/&gt;/g, ">");
    s = s.replace(/&nbsp;/g, " ");
    s = s.replace(/&#39;/g, "\'");
    s = s.replace(/&quot;/g, "\"");
    return s;
  },
  //html转字符
  htmlTurnCharacter: function htmlTurnCharacter(str) {
    var s = "";
    if (str.length == 0) return "";
    var regex = /(.*?)<img.*?alt="(.*?)">/ig;
    s = str.replace(regex, "$1$2");
    return s;
  }
};

function edittable() {
  $('[contenteditable]').each(function () {
    try {
      document.execCommand("AutoUrlDetect", false, false);
    } catch (e) {}

    $(this).on('paste', function (e) {
      e.preventDefault();
      var text = null;

      if (window.clipboardData && clipboardData.setData) {
        text = window.clipboardData.getData('text');
      } else {
        text = (e.originalEvent || e).clipboardData.getData('text/plain');
      }

      if (!text) {
        return false;
      }

      if (document.body.createTextRange) {
        console.log('insert Text');

        if (document.selection) {
          textRange = document.selection.createRange();
        } else if (window.getSelection) {
          sel = window.getSelection();
          var range = sel.getRangeAt(0);
          var tempEl = document.createElement("span");
          tempEl.innerHTML = "&#FEFF;";
          range.deleteContents();
          range.insertNode(tempEl);
          textRange = document.body.createTextRange();
          textRange.moveToElementText(tempEl);
          tempEl.parentNode.removeChild(tempEl);
        }

        textRange.text = text;
        textRange.collapse(false);
        textRange.select();
      } else {
        // Chrome之类浏览器
        document.execCommand("insertText", false, text);
      }
    }); // 去除Crtl+b/Ctrl+i/Ctrl+u等快捷键

    $(this).on('keydown', function (e) {
      // e.metaKey for mac
      if (e.ctrlKey || e.metaKey) {
        switch (e.keyCode) {
          case 66: //ctrl+B or ctrl+b

          case 98:
          case 73: //ctrl+I or ctrl+i

          case 105:
          case 85: //ctrl+U or ctrl+u

          case 117:
            e.preventDefault();
            break;
        }
      }
    });
  });
}

var Config = {
  domain: 'lenovouat.com',
  ws: 'wss://lecs.lenovouat.com:443',
  poll: 'https://lecs.lenovouat.com',
  api: 'https://ocsapi.lenovouat.com'
};
var base = Config.api;
var basis = Config.poll;
var Api = {
  auth: base + "/cust/auth",
  opinion: base + "/opinion/rate",
  chatRecord: base + "/chat/before",
  hot: base + "/hot/question",
  uploadImage: base + "/upload/image",
  uploadImgb64: base + "/upload/imgb64",
  goodsDetail: base + "/goods/info",
  recommendList: base + "/recommend/list",
  orderList: base + "/order/list",
  logistics: base + "/order/logistics",
  redirect: base + "/cust/redirect",
  //种 cookie 接口
  qaChecked: basis + "/robot/qa/checked",
  welcome: basis + "/robot/self/welcome",
  esQ: basis + "/robot/self/esQ",
  robot: basis + "/robot/self/robot",
  serWelWord: basis + "/robot/external/welcome",
  robotChat: basis + "/robot/external/robot",
  //存储机器人的问答信息
  closeType: basis + "/robot/qa/close"
};
var Request = {
  get: function get(url, params, async, _success, _error) {
    params.t = new Date().getTime();
    $.ajax({
      type: "GET",
      url: url,
      data: params,
      dataType: 'json',
      async: async,
      xhrFields: {
        withCredentials: true
      },
      success: function success(res) {
        _success && _success instanceof Function && _success(res);
      },
      error: function error(res) {
        _error && _error instanceof Function && _error(res);
      }
    });
  },
  post: function post(url, params, async, _success2, _error2) {
    params.t = new Date().getTime();
    $.ajax({
      type: "POST",
      url: url,
      data: params,
      dataType: 'json',
      // xhrFields: { withCredentials: true },
      success: function success(res) {
        _success2 && _success2 instanceof Function && _success2(res);
      },
      error: function error(res) {
        _error2 && _error2 instanceof Function && _error2(res);
      }
    });
  },
  jsonp: function jsonp(url, params, async, _success3, _error3) {
    params.t = new Date().getTime();
    document.cookie = "accesstoken=" + sessionStorage.getItem("accesstoken");
    $.ajax({
      type: "POST",
      url: url,
      data: params,
      dataType: 'jsonp',
      async: async,
      jsonp: "callback",
      xhrFields: {
        withCredentials: true
      },
      success: function success(res) {
        _success3 && _success3 instanceof Function && _success3(res);
      },
      error: function error(res) {
        _error3 && _error3 instanceof Function && _error3(res);
      }
    });
  },
  uploadImg: function uploadImg(url, formdata, async, _success4, _error4) {
    $.ajax({
      url: url,
      data: formdata,
      dataType: 'json',
      type: "POST",
      async: async,
      processData: false,
      contentType: false,
      xhrFields: {
        withCredentials: true
      },
      // 添加cookie标识
      success: function success(res) {
        _success4 && _success4 instanceof Function && _success4();
      },
      error: function error(res) {
        _error4 && _error4 instanceof Function && _error4();
      }
    });
  }
};
var Constant = {
  build_success: "建立会话成功！",
  waitting_tip: "已进入服务队列，当前排队人数 {0}, 请您耐心等候...",
  service_info: "客服工号 {0}， 正在为您提供服务.",
  close_tip: "当前会话已结束，回复消息继续咨询.",
  robot_tip: "联想智能客服欢迎您!",
  assistant_tip: "联想客服助手欢迎您!"
};
var subId = 1000;
var Common = {
  getCookie: function getCookie(name) {
    var arr;
    var reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

    if (arr = document.cookie.match(reg)) {
      return unescape(arr[2]);
    } else {
      return "oc-" + ((1 + Math.random()) * 0x10000 | 0).toString(16).substring(1);
    }
  },
  getPid: function getPid() {
    return subId++ + "-" + fragment() + '-' + fragment() + '-' + fragment() + '-' + fragment() + '-' + fragment() + fragment() + fragment();
  },
  dateFormat: function dateFormat(obj) {
    var date;

    if (obj && obj instanceof Date) {
      date = obj;
    } else {
      date = new Date();
    }

    var y = date.getFullYear(),
        m = date.getMonth() + 1,
        d = date.getDate();
    return y + "-" + (m < 10 ? "0" + m : m) + "-" + (d < 10 ? "0" + d : d) + " " + date.toTimeString().substr(0, 8);
  },
  getUrlParams: function getUrlParams() {
    var urlSearch = decodeURI(location.search);

    if (urlSearch.indexOf("?") == 1) {
      return null;
    }

    urlSearch = urlSearch.substr(1);
    var urls = urlSearch.split("&");
    var params = {};
    var temp;

    for (var i = 0; i < urls.length; i++) {
      temp = urls[i].split("=");
      params[temp[0]] = temp[1];
    }

    return params;
  },
  isMobile: function isMobile() {
    var agent = navigator.userAgent;
    return !!agent.match(/AppleWebKit.*Mobile.*/) || !!agent.match(/AppleWebKit/) && agent.indexOf('QIHU') && agent.indexOf('QIHU') > -1 && agent.indexOf('Chrome') < 0;
  },
  uploadImg: function uploadImg(url, callback) {
    var fileForm = '<form id="submit_upload_img" method="post" action="' + url + '" enctype="multipart/form-data" target="iframe_upload_img" style="display: none">' + '<input type="file" id="input_upload_img" name="file" accept=".jpg,.gif,.jpeg,.png" /></form>';
    var iframe = '<iframe id="iframe_upload_img" name="iframe_upload_img" style="display: none"></iframe>';
    $('#iframe_upload_img').remove();
    $('#submit_upload_img').remove();
    $('body').append(iframe);
    $('body').append(fileForm);
    $('#input_upload_img').change(function () {
      $("#submit_upload_img").submit();
    });
    $("#iframe_upload_img").load(function (e) {
      var res = $("#iframe_upload_img")[0].contentWindow.document.querySelector('body').innerHTML;
      res = JSON.parse(res);
      callback && callback instanceof Function && callback(res);
    });
    $("#input_upload_img").click();
  },
  uploadImgB64: function uploadImgB64(url, imgB64, callback) {
    var fileForm = '<form id="submit_upload_img" method="post" action="' + url + '" enctype="multipart/form-data" target="iframe_upload_img" style="display: none">' + '<input id="input_upload_img" name="imgb64" value="' + imgB64 + '" accept=".jpg,.gif,.jpeg,.png" /></form>';
    var iframe = '<iframe id="iframe_upload_img" name="iframe_upload_img" style="display: none"></iframe>';
    $('#iframe_upload_img').remove();
    $('#submit_upload_img').remove();
    $('body').append(iframe);
    $('body').append(fileForm);
    $("#iframe_upload_img").load(function (e) {
      var res = $("#iframe_upload_img")[0].contentWindow.document.querySelector('body').innerHTML;
      res = JSON.parse(res);
      callback && callback instanceof Function && callback(res);
    });
    $("#submit_upload_img").submit();
  },
  createImgHtml: function createImgHtml(imgurl) {
    return '<img src="' + imgurl + '" style="max-width: 100%; max-height: 300px;" onload="conFitScroll()" />';
  },
  stopPropagation: function stopPropagation(event) {
    if (window.showModalDialog) {
      window.event.cancelBubble = true;
    } else {
      event.stopPropagation();
    }
  }
};

function fragment() {
  return Math.floor(65535 * (1 + Math.random())).toString(16).substring(1);
}

(function (root, factory) {
  (typeof exports === "undefined" ? "undefined" : _typeof(exports)) === 'object' && typeof module !== 'undefined' ? module.exports = factory() : typeof define === 'function' && define.amd ? define(factory) : root.iNotify = factory();
})(window, function () {
  var oldTitle = document.title;

  var iNotify = function iNotify(opts) {
    this.init(opts || {});
  };

  iNotify.prototype.init = function (opts) {
    this.open = false;
    this.effect = opts.effect || "flash";
    this.message = opts.message || "有新消息了!";
    this.title = document.title || this.message;
    this.interval = opts.interval || 500;
    this.onceTime = opts.onceTime || 2000;
    this.isActiveW = false; //当前窗口是不是激活状态
    //开始检测状态

    this.onMonitor();
  };

  iNotify.prototype.start = function () {
    var _this = this;

    _this.stop(); //falsh 消息闪动title


    if (_this.effect === "flash") {
      var isOld = false;
      return _this.flashInterval = setInterval(function () {
        isOld ? document.title = oldTitle : document.title = _this.message;
        isOld = !isOld;
      }, _this.interval);
    } //scroll 消息滚动title


    if (_this.effect === "scroll") {
      document.title = _this.message;
      return _this.scrollInterval = setInterval(function () {
        var text = document.title;
        document.title = text.substring(1, text.length) + text.substring(0, 1);
        text = document.title.substring(0, text.length);
      }, _this.interval);
    }
  };

  iNotify.prototype.stop = function () {
    var _this = this;

    _this.isActiveW = false;
    clearTimeout(_this.onceTimeout);

    if (_this.effect === "flash") {
      _this.flashInterval && clearInterval(_this.flashInterval);
      return document.title = oldTitle;
    }

    if (_this.effect === "scroll") {
      _this.scrollInterval && clearInterval(_this.scrollInterval);
      return document.title = oldTitle;
    }
  };

  iNotify.prototype.once = function () {
    var _this = this;

    _this.stop();

    if (_this.effect === "flash" || _this.effect === "scroll") {
      clearTimeout(_this.onceTimeout);

      _this.start();

      return _this.onceTimeout = setTimeout(function () {
        _this.stop();
      }, _this.onceTime);
    }
  };

  iNotify.prototype.onMonitor = function () {
    var _this = this;

    window.onfocus = function () {
      if (!_this.isActiveW) {
        _this.isActiveW = true;

        _this.stop();
      }
    };

    document.onclick = function () {
      if (!_this.isActiveW) {
        _this.isActiveW = true;

        _this.stop();
      }
    };
  };

  return iNotify;
});

var notify = new iNotify({
  effect: "scroll",
  message: "您有新消息..."
});
var ChatResolver = {
  type: {
    inMessage: "inMessage",
    outMessage: "outMessage",
    broadcast: "broadcast"
  },
  render: function render(type, message) {
    switch (type) {
      case this.type.inMessage:
        renderInMessage(message);
        break;

      case this.type.outMessage:
        renderOutMessage(message);
        break;

      case this.type.broadcast:
        renderBroadcast(message);
        break;
    }
  },
  robotRender: function robotRender(message) {
    robotAnswer(message, false);
  },
  robotRenderHistory: function robotRenderHistory(message) {
    var flag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    var robottype = arguments.length > 2 ? arguments[2] : undefined;
    var createtime = arguments.length > 3 ? arguments[3] : undefined;
    robotAnswer(message, flag, robottype, createtime);
  },
  renderHistory: function renderHistory(message) {
    renderHistoryRecord(message);
  },
  renderBroadcast: function renderBroadcast(message) {
    $("#chat_service_status_msg").text(message);
  },
  renderHtml: function renderHtml(html) {
    appendHtml(html);
  },
  toScroll: function toScroll() {
    fitScroll();
  }
};
var revocationMessage = "客服撤回一条消息";

function renderInMessage(message) {
  var messageType = message.type;

  switch (messageType) {
    case "BUILD_CHAT":
      customer.cid = message.cid;
      renderInMessage.buildChat(message);
      break;

    case "MESSAGE":
      renderInMessage.message(message);
      break;

    case "TRANSFER":
      renderInMessage.transfer(message);
      break;

    case "BROADCAST":
      renderInMessage.broadcast(message);
      break;

    case "CLOSE_CHAT":
      renderBroadcast(Constant.close_tip);
      break;

    case "REVOCATION":
      renderRevocation(message);
      break;

    case "EVALUATE":
      $("#option_box").show();
      break;

    case "ROBOT":
      renderInMessage.message(message);
      break;
  }

  if (notify.open && messageType !== 'PONG') {
    notify.start();
  }
} // 创建会话消息


renderInMessage.buildChat = function (message) {
  var bodyType = message.body.type;
  var appendInner;
  var content;

  switch (bodyType) {
    case "BUILDING_CHAT":
      message.body.content;
      break;

    case "WAITTING":
      renderBroadcast(Constant.waitting_tip.replace("{0}", message.body.content));
      break;

    case "SUCCESS":
      try {
        var buildChatInfo = JSON.parse(message.body.content);
        customer.tmb = buildChatInfo.tmb;
        customer.skn = buildChatInfo.skn;
      } catch (e) {
        console.log(e); // ignore
      }

      renderBroadcast(Constant.service_info.replace("{0}", message.from.uid));
      break;

    case "TEAM_GREET":
      content = replaceUrl(Emoji.face.toEmoji(message.body.content));
      appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.datetime + '</span><b>' + (customer.tmb || "") + '</b><b class="left-space">' + message.from.uid + '</b></div><div class="chat-body">' + content + '</div></div></div>';
      break;

    case 'WAITER_GREET':
      content = replaceUrl(Emoji.face.toEmoji(message.body.content));
      appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.datetime + '</span><b>' + (customer.tmb || "") + '</b><b class="left-space">' + message.from.uid + '</b></div><div class="chat-body">' + content + '</div></div></div>';
      break;

    case 'ROBOT':
      appendInner = '<div class="robot-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>智能客服</b></div><div class="chat-body">' + Emoji.face.toEmoji(message.body.content) + '</div></div></div>';
      break;
  }

  appendChatBox(message, appendInner);
}; // 会话消息


renderInMessage.message = function (message) {
  var content;
  var appendInner;
  var bodyType = message.type && message.type == "ROBOT" ? message.type : message.body.type;

  switch (bodyType) {
    case "TEXT":
      var _content = "";

      if (message.body.content.indexOf("[:") > -1) {
        content = EscapeSequence.filterHtmlJsSpaceEnter(message.body.content);
        _content = replaceUrl(Emoji.face.toEmoji(content));
      } else {
        _content = replaceUrl(message.body.content);
      }

      console.log(_content, 'content1');
      appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.datetime + '</span><b>' + (customer.tmb || "") + '</b><b class="left-space">' + message.from.uid + '</b></div><div class="chat-body text-img">' + _content + '</div></div></div>';
      break;

    case 'TIMEOUT_TIP':
      appendInner = '<div class="robot-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>智能客服</b></div><div class="chat-body">' + Emoji.face.toEmoji(message.body.content) + '</div></div></div>';
      break;

    case 'TIMEOUT_CLOSE':
      appendInner = '<div class="robot-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>智能客服</b></div><div class="chat-body">' + Emoji.face.toEmoji(message.body.content) + '</div></div></div>';
      renderBroadcast(Constant.close_tip);
      break;

    case 'IMAGE':
      appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.datetime + '</span><b>' + (customer.tmb || "") + '</b><b class="left-space">' + message.from.uid + '</b></div><div class="chat-body">' + Common.createImgHtml(message.body.content) + '</div></div></div>';
      break;

    case 'LOGISTICS':
      appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.datetime + '</span><b>' + (customer.tmb || "") + '</b><b class="left-space">' + message.from.uid + '</b></div><div class="chat-body">' + createLogistics(message.body.content) + '</div></div></div>';
      break;

    case 'GOODS':
      appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.datetime + '</span><b>' + (customer.tmb || "") + '</b><b class="left-space">' + message.from.uid + '</b></div><div class="chat-body">' + createGoods(message.body.content) + '</div></div></div>';
      break;

    case 'ORDER':
      appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.datetime + '</span><b>' + (customer.tmb || "") + '</b><b class="left-space">' + message.from.uid + '</b></div><div class="chat-body">' + createOrders(message.body.content) + '</div></div></div>';
      break;

    case 'TIP':
    case 'ROBOT':
      appendInner = '<div class="robot-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>智能客服</b></div><div class="chat-body">' + Emoji.face.toEmoji(message.content ? message.content : message.body.content) + '</div></div>';
      break;

    default:
      appendInner = '<div class="robot-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>智能客服</b></div><div class="chat-body">' + Emoji.face.toEmoji(message.body.content) + '</div></div></div>';
      renderBroadcast(Constant.close_tip);
  }

  appendChatBox(message, appendInner);
};

renderInMessage.transfer = function (message) {
  var appendInner;
  var bodyType = message.body.type;

  if (bodyType === 'SUCCESS') {
    renderBroadcast(Constant.service_info.replace("{0}", message.from.uid));
    appendInner = '<div class="robot-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>智能客服</b></div><div class="chat-body">已为您转接客服工号：' + message.from.uid + '， 请输入您要咨询的问题。</div></div></div>';

    try {
      var buildChatInfo = JSON.parse(message.body.content);
      customer.tmb = buildChatInfo.tmb;
      customer.skn = buildChatInfo.skn;
    } catch (e) {// ignore
    }
  }

  appendChatBox(message, appendInner);
};

renderInMessage.broadcast = function (message) {
  var bodyType = message.body.type;

  if (bodyType === 'WAITTING_NO') {
    renderBroadcast(Constant.waitting_tip.replace("{0}", message.body.content));
  }
};

function renderOutMessage(message) {
  var showContainer;

  switch (message.type) {
    case "TEXT":
      showContainer = '<div class="user-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>我</b></div><div class="chat-body">' + replaceUrl(Emoji.face.toEmoji(message.content)) + '</div></div></div>';
      break;

    case "IMAGE":
      showContainer = '<div class="user-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>我</b></div><div class="chat-body">' + Emoji.face.toEmoji(message.content) + '</div></div></div>';
      break;

    case "ORDER":
      showContainer = '<div class="user-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + Common.dateFormat() + '</span><b>我</b></div><div class="chat-body">' + createOrders(message.content) + '</div></div></div>';
      break;
  }

  appendChatBox(message, showContainer);
}

function renderBroadcast(message) {
  $("#chat_service_status_msg").text(message);
}

function renderRevocation(message) {
  var pid = message.pid;
  $('div[pid=' + pid + ']').html("<div class='revocation'>" + revocationMessage + "</div>");
}

function renderHistoryRecord(message) {
  if (message) {
    var content = resolverHtyMessage(message);
    var appendInner;

    switch (message.ownerType) {
      case '1':
        appendInner = '<div class="user-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.createTime + '</span><b>我</b></div><div class="chat-body">' + content + '</div></div></div>';
        break;

      case '2':
        appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.createTime + '</span><b>' + message.briefName + '</b><b class="left-space">' + message.waiterCode + '</b></div><div class="chat-body text-img">' + content + '</div></div></div>';
        break;

      case '4':
        appendInner = '<div class="user-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.createTime + '</span><b>我</b></div><div class="chat-body">' + content + '</div></div></div>';
        break;

      default:
        if (message.messageType == '5' || message.messageType == '9') {
          appendInner = '<div class="service-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.createTime + '</span><b>' + message.briefName + '</b><b class="left-space">' + message.waiterCode + '</b></div><div class="chat-body">' + content + '</div></div></div>';
        } else {
          appendInner = '<div class="robot-chat clearfix">' + '<div class="portrait icons"></div><div class="container">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + message.createTime + '</span><b>智能客服</b></div><div class="chat-body">' + content + '</div></div></div>';
        }

    }

    $("#msg_box").prepend(appendInner);
  }
}

function resolverHtyMessage(message) {
  var content;

  switch (message.messageType) {
    case '2':
      content = createHistoryImgHtml(message.messages);
      break;

    case '10':
      content = createGoods(message.messages);
      break;

    case '11':
      content = createOrders(message.messages);
      break;

    case '12':
      content = createLogistics(message.messages);
      break;

    case '13':
      if (message.robotMessageType == 2) {
        content = createOrders(message.messages);
      } else {
        content = createRobots(message.messages);
      }

      break;

    default:
      if (message.messages.indexOf("[:") > -1) {
        content = replaceUrl(Emoji.face.toEmoji(message.messages));
      } else {
        content1 = createText(message.messages);
        content = replaceUrl(content1);
      }

  }

  return content;
}

function createLogistics(message) {
  var o = JSON.parse(message);
  var html = '<div><div style="padding: 2px 0 8px 0; font-size: 13px;"><span>以下是最新的物流/状态信息：<span></div>';

  for (var i = 0; i < o.length; i++) {
    html += '<div><span> ' + o[i].lgtime + ' </span></div>' + '<div><span> ' + o[i].lgdesc + ' </span></div>';
  }

  html += '</div>';
  return html;
}

function createGoods(message) {
  var o = JSON.parse(message);
  var html;

  if (isMobile == 0) {
    html = '<a href="' + o.wapUrl + '" target="_blank">' + o.name + '</a>';
  } else {
    html = '<a href="' + o.pcUrl + '" target="_blank">' + o.name + '</a>';
  }

  return html;
}

function createOrders(message) {
  var o = JSON.parse(message);
  var html = "<div class=\"ordercard\">\n                      <ul class=\"sendPrdUl\">\n                          <li class=\"prdCodeLi\">\n                              <div>\n                                  <label style=\"padding-left: 4px;\">\u8BA2\u5355\u53F7:</label>\n                                  <span style=\"margin-left: -5px;\">".concat(o.orderCode, "</span><br>\n  \n                                  <label style=\"padding-left: 4px;\">\u4E0B\u5355\u65F6\u95F4:</label>\n                                  <span style=\"margin-left: -5px;\">").concat(o.orderTime, "</span>\n                                  <span style=\"float:right\">\n                                      <b>").concat(o.orderStatusInfo, "</b>\n                                  </span>\n                              </div>\n                          </li>\n                          <li class=\"prdLi\">\n                              <div class=\"img\">\n                                  <img src=\"").concat(o.prdInfo.prdImgUrl, "\" alt=\"\">\n                              </div>\n                              <div class=\"prdLiDiv\">\n                                  <a href=\"").concat(o.prdInfo.prdDetailUrl ? o.prdInfo.prdDetailUrl : '#', "\" title=\"").concat(o.prdInfo.prdName, "\" target=\"_blank\" class=\"prdNameP\">").concat(o.prdInfo.prdName, "</a>\n                                  <p style=\"color: #999;\">\n                                      <span>\u5546\u54C1\u7F16\u53F7\uFF1A</span>\n                                      <span style=\"margin-left: -0.5rem;\">").concat(o.prdInfo.prdCode, "</span>\n                                  </p>  \n                                  <p class=\"prdInfoP\">\n                                      <span>\u6570\u91CF:</span>\n                                      <span style=\"padding-right: 0.5rem;\">").concat(o.prdInfo.prdAcount, "</span>\n                                      <b>\uFFE5").concat(o.prdInfo.prdPrice, "</b>\n                                  </p>\n                              </div>\n                          </li>\n                          <li class=\"prdAmountLi\">\n                              <div style=\"position: relative\">\n                                  <span>\u5171</span>\n                                  <span style=\"margin-left: 4px;\">").concat(o.orderAcount, "</span>\n                                  <span style=\"padding-right: 8px; margin-left: 4px;\">\u4EF6</span>\n                                  <span>\u8BA2\u5355\u91D1\u989D\uFF1A</span>\n                                  <b style=\"color: #e2231a; margin-left: -12px;\">\uFFE5").concat(o.orderAmount, "</b>\n                              </div>\n                          </li>\n                      </ul>\n                  </div>").replace(/ *[\r|\n] */gm, '');
  return html;
}

function robotAnswer(message, before, type, createtime) {
  var div = document.createElement('div');
  var time = createtime ? createtime : Common.dateFormat();
  div.className = "robot-chat clearfix";
  var html = '<div class="portrait icons"></div><div class="container robotContainer">' + '<div class="arrow icons"></div><div class="chat-head ell"><span>' + time + '</span><b>智能客服</b></div><div class="chat-body">' + message + '</div>';
  div.innerHTML = html;
  var el = $(div);
  var Limited = 360;

  if (before) {
    $("#msg_box").prepend(el);
  } else {
    $("#msg_box").append(el);
    fitScroll();
  }

  var timer = setInterval(function () {
    if (el.find(".chat-body").height() > Limited || el.find(".chat-body").height() == Limited) {
      if (!el.find('.container .more').length) {
        el.children('.container').append('<button class="more">查看更多</button><button class="putItAway">收起</button>');
        fitScroll();
      } else {
        clearInterval(timer);
      }
    } // if(el.find(".chat-body").height() > 200 || el.find(".chat-body").height() == 200 ) {
    //     fitScroll();
    // }else{
    //     clearInterval(timer);
    // }
    // if(el.find(".chat-body").height() < 200) {
    //     fitScroll();
    // }else{
    //     clearInterval(timer);
    // }

  }, 300);
}

function createHistoryImgHtml(imgurl) {
  return '<img src="' + imgurl + '" style="max-width: 100%; max-height: 300px;" onload="conFitScroll()"/>';
}

function appendHtml(html) {
  $("#msg_box").append(html);
  fitScroll();
}

function appendChatBox(message, html) {
  if (html) {
    var pid = message.pid;

    if (pid) {
      html = '<div class="record" pid="' + pid + '" >' + html + '</div>';
    }

    $("#msg_box").append(html);
  }

  fitScroll();
}

function fitScroll() {
  var h = $("#msg_box").height() - $("#chatDiv").height();

  if (h > 0) {
    $("#chatDiv").scrollTop(h + 40);
  }
}

function replaceUrl(msg) {
  var reg = /((((http?|https?):(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/gi;
  var result = msg.replace(reg, function (item) {
    var content = item;

    if (item.length > 4 && item.substr(0, 4) !== 'http') {
      item = "//" + item;
    }

    return '<a class="custom-link" href="' + item + '" target="_blank">' + content + '</a>';
  });
  return result;
}

function replaceImgUrl(msg) {
  var arr = [];
  str = str.replace(/(http(s)?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w\-\.\/?%&=]*)?/gi, function (s) {
    arr.push(s);
    return "\x01";
  });
  str = str.replace(/(http(s)?:\/\/)?([\w-]+\.)+[\w-]+(\/[\w\-\.\/?%&=]*)?/g, function (s, a) {
    return '<a class="custom-link" href="' + s + '" target="_blank">' + s + '</a>';
  });
  str = str.replace(/\x01/g, function (s) {
    return arr.shift();
  });
}

function createRobots(msg) {
  return msg;
}

function createText(message) {
  return message;
}

var chatRecordMark = {
  first: true
};
var Service = {
  loadChatRecord: function loadChatRecord() {
    var params = {};

    if (chatRecordMark.id) {
      params.id = chatRecordMark.id;
    }

    if (chatRecordMark.more) {
      return;
    }

    Request.jsonp(Api.chatRecord, params, true, function (res) {
      if (res.rc == 0) {
        var records = res.data;
        var len = records.length;

        for (var i = 0; i < len; i++) {
          var record = records[i];

          if (record.ownerType === '5') {
            if (record.messages.indexOf('<bubble value="1">') > -1) {
              var bubbles = record.messages.match(/<\w+?><bubble value="1">.*?<\/bubble>.*?<\/\w+?>/ig);
              bubbles.reverse().forEach(function (item, idx) {
                ChatResolver.robotRenderHistory(item, true);
              });
            } else if (record.messages.indexOf("<a href='https://lecs.lenovo.com.cn/' target='_blank'>人工客服</a>") > -1) {
              var message = record.messages.replace("target='_blank'", "class='ContactArtificial'");
              message = message.replace("https://lecs.lenovo.com.cn/", "javascript:;");
              ChatResolver.robotRenderHistory(message, true);
            } else {
              ChatResolver.robotRenderHistory(record.messages, true, '', records[i].createTime);
            }
          } else {
            ChatResolver.renderHistory(records[i]);
          } // chatRecordMark.first = true;

        }

        if (chatRecordMark.first) {
          chatRecordMark.first = false;
          $('#load_chat_more').show();
          $('#history_up').show();
        }

        if (!chatRecordMark.id) {
          ChatResolver.toScroll();
        }

        if (len > 0) {
          chatRecordMark.id = records[len - 1].id;
        }

        if (len < 10) {
          chatRecordMark.more = true;
          $('.load-chat-more').html("没有更多");
        }
      }
    });
  }
};
/**
 * @author pengzq1
 * @since 2019.06.03
 * @version v1.0
 */

var HpClient = function HpClient(opts) {
  var customer = opts.customer;
  opts.active = false;
  connect();

  function connect() {
    var connectPacket = {
      type: 'AUTH',
      ts: 'POLLING',
      ttc: customer.ttc,
      skc: customer.skc,
      skn: customer.skn,
      gc: customer.gc,
      from: {
        idy: "CUSTOMER"
      },
      body: {
        type: 'LOGIN'
      }
    };
    doSend(connectPacket, function (res) {
      initEventHandler();
    });
  }

  function initEventHandler() {
    ChatResolver.render(ChatResolver.type.broadcast, Constant.build_success);
    poll();
    opts.active = true;
    $(".btn-toolbar .tool-btn-group").show();
    bindMessageElement();
  }

  function poll() {
    var pollPacket = {
      type: "POLL",
      ts: 'POLLING',
      ttc: customer.ttc,
      skc: customer.skc,
      skn: customer.skn,
      gc: customer.gc,
      to: {
        idy: "WAITER"
      },
      from: {
        uid: customer.cc,
        name: customer.cn,
        idy: "CUSTOMER"
      },
      body: {
        type: "TEXT"
      }
    };
    $.ajax({
      type: "GET",
      url: opts.url,
      data: {
        packet: JSON.stringify(pollPacket),
        t: new Date().getTime()
      },
      dataType: 'json',
      xhrFields: {
        withCredentials: true
      },
      success: function success(res) {
        if (res && res instanceof Array) {
          for (var i = 0; i < res.length; i++) {
            ChatResolver.render(ChatResolver.type.inMessage, res[i]);
          }
        }

        if (opts.active) {
          setTimeout(poll(), 1000);
        }
      },
      error: function error(res) {
        console.log("请求失败： " + res);
      }
    });
  }

  var bindMessageElement = function bindMessageElement() {
    $("#message_area").on("keydown", function (event) {
      if (!(event.ctrlKey || event.metaKey || event.altKey)) {
        $("#message_area").focus();
      }

      if (event.which === 13) {
        $("#send_msg_btn").trigger("click");
        event.preventDefault();
        return false;
      }
    });
    $("#send_msg_btn").on('click', function () {
      var message = $("#message_area").val();

      if (!message || RegExp("^[ ]+$").test(message)) {
        Pdialog.showDialog({
          content: "消息不能为空"
        });
        return false;
      }

      if (message && message.length > 300) {
        Pdialog.showDialog({
          content: "消息不能超过300字"
        });
        return false;
      }

      if (message && message.length <= 300) {
        $("#message_area").val("");
        message = EscapeSequence.filterHtmlJsSpaceEnter(message);

        if (isMobile === 1) {
          $("#message_area").focus();
        } else {
          $("#message_area").blur();
        }

        sendMessage(message, 'TEXT');
        ChatResolver.render(ChatResolver.type.outMessage, {
          content: message,
          type: 'TEXT'
        });
      }

      event.preventDefault();
      return false;
    });
  };

  function sendMessage(message, bodyType) {
    var sendPacket = {
      type: 'MESSAGE',
      ts: 'POLLING',
      ttc: customer.ttc,
      skc: customer.skc,
      skn: customer.skn,
      gc: customer.gc,
      to: {
        idy: 'WAITER'
      },
      from: {
        uid: customer.cc,
        name: customer.cn,
        idy: "CUSTOMER"
      },
      body: {
        type: bodyType,
        content: message
      }
    };
    doSend(sendPacket, function (res) {
      console.log("消息发送成功!" + JSON.stringify(sendPacket));
    });
  }

  function doSend(packet, succ, fail) {
    if (packet) {
      packet.pid = Common.getPid();
      $.ajax({
        type: "GET",
        url: opts.url,
        data: {
          packet: JSON.stringify(packet),
          t: new Date().getTime()
        },
        dataType: 'json',
        xhrFields: {
          withCredentials: true
        },
        success: function success(res) {
          succ(res);
        },
        error: function error(res) {
          fail && fail instanceof Function && fail(res);
          console.log("发送消息失败：{}", JSON.stringify(res));
        }
      });
    }
  }

  return {
    sendImg: function sendImg(img, message, type) {
      sendMessage(message, type);
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: img,
        type: 'IMAGE'
      });
    },
    sendMsg: function sendMsg(message, type) {
      sendMessage(message, type);
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: message,
        type: type
      });
    },
    close: function close() {
      opt.active = false;
      var closePacket = {
        type: 'CLOSE',
        ts: 'POLLING',
        ttc: customer.ttc,
        skc: customer.skc,
        skn: customer.skn,
        gc: customer.gc,
        to: {
          idy: 'WAITER'
        },
        from: {
          uid: customer.cc,
          name: customer.cn,
          idy: "CUSTOMER"
        }
      };
      doSend(closePacket, function (res) {
        console.log("关闭!");
      });
    }
  };
};
/**
 * @author pengzq1
 * @since 2019.06.03
 * @version v1.0
 */


var WsClient = function WsClient(opts) {
  var wsPING;
  var ws;
  var customer = opts.customer;
  var isError = false;
  var isClose = true;
  connect();
  bindInputMessageBox();

  function connect() {
    var connectPacket = {
      type: "AUTH",
      ts: "WEBSOCKET",
      from: {
        idy: "CUSTOMER"
      },
      body: {
        type: "LOGIN"
      }
    };
    var url = opts.url + "?packet=" + JSON.stringify(connectPacket) + "&t=" + new Date().getTime();
    ws = new WebSocket(url);
    wsEventHandler();
  }

  function wsEventHandler() {
    ws.onopen = function () {
      isError = false;
      ChatResolver.render(ChatResolver.type.broadcast, Constant.build_success);
      $(".btn-toolbar .tool-btn-group").show();
      clearInterval(wsPING);
      wsPING = setInterval(function () {
        var pingPacket = {
          type: 'PING',
          ts: 'WEBSOCKET',
          body: {
            type: 'TEXT',
            content: "PING"
          }
        };
        doSend(pingPacket);
      }, 30000);
    };

    ws.onmessage = function (data) {
      data = JSON.parse(data.data);

      if (data.type == 'RE_LOGIN') {
        isClose = true;
        clearInterval(wsPING);
        ChatResolver.renderBroadcast("已在其他打开咨询，当前会话被关闭");
        Pdialog.showAsk({
          content: "您已在其他页面发起咨询，当前咨询已失效",
          btnContent: "点击重新发起咨询"
        }, function () {
          window.location.href = location.href;
        }); // ws.close();
      } else {
        ChatResolver.render(ChatResolver.type.inMessage, data);
      }
    };

    ws.onerror = function (data) {
      isError = true;
      ChatResolver.render(ChatResolver.type.broadcast, "糟糕，网络错误，工程师正在维护中...");
    };

    ws.onclose = function () {
      if (isClose) {
        return;
      }

      if (!isError) {
        ChatResolver.render(ChatResolver.type.broadcast, "糟糕，网络连接断开");
      }

      reconnect();
    };
  }

  function bindInputMessageBox() {
    $("#message_area").off("keydown").on("keydown", function (event) {
      if (!(event.ctrlKey || event.metaKey || event.altKey)) {
        $("#message_area").focus();
      }

      if (event.keyCode === 13) {
        $("#send_msg_btn").trigger('click');
        $("#emoji_container").hide();
        event.preventDefault();
        return false;
      }
    });
    $("#send_msg_btn").off("click").on('click', function () {
      var message = $("#message_area").val();

      if (!message || RegExp("^[ ]+$").test(message)) {
        Pdialog.showDialog({
          content: "消息不能为空"
        });
        return false;
      }

      if (message && message.length > 300) {
        Pdialog.showDialog({
          content: "消息不能超过300字"
        });
        return false;
      }

      if (message && message.length <= 300) {
        $("#message_area").val("");
        message = EscapeSequence.filterHtmlJsSpaceEnter(message);

        if (isMobile === 1) {
          $("#message_area").focus();
        } else {
          $("#message_area").blur();
        }

        ChatResolver.render(ChatResolver.type.outMessage, {
          content: message,
          type: 'TEXT'
        });
        sendMessage(message, 'TEXT');
      }

      event.preventDefault();
      return false;
    });
  }

  function sendMessage(message, bodyType) {
    var sendPacket = {
      type: 'MESSAGE',
      ts: 'WEBSOCKET',
      from: {
        uid: customer.cc,
        name: customer.cn,
        idy: "CUSTOMER"
      },
      body: {
        type: bodyType,
        content: message
      }
    };
    doSend(sendPacket);
  }

  function doSend(packet) {
    if (packet) {
      if (ws.readyState === 1) {
        packet.pid = Common.getPid();
        packet.to = {
          idy: 'WAITER'
        };
        ws.send(JSON.stringify(packet));
      } else if (ws.readyState === 3) {
        reconnect();
      }
    }

    return false;
  }

  function reconnect() {
    if (ws.readyState === 3) {
      clearInterval(wsPING);
      setTimeout(connect, 5000);
      auth();
    }
  }

  return {
    sendImg: function sendImg(img, message, type) {
      sendMessage(message, type);
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: img,
        type: 'IMAGE'
      });
    },
    sendMsg: function sendMsg(message, type) {
      sendMessage(message, type);
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: message,
        type: type
      });
    },
    close: function close() {
      if (ws.readyState == 1) {
        ws.close();
      }
    }
  };
};

var face = {
  em: undefined,
  toEmoji: undefined,
  show: undefined,
  hide: undefined
};
var Emoji = {
  face: createEmoji()
};

function render_nav(obj, options) {
  $(obj).append('<div class="emoji-inner"><ul class="emoji-nav"></ul><div class="emoji-content"></div></div>');

  if (!options.showbar) {
    $(obj).addClass('no-bar');
    return;
  }

  ;

  var navs = _.reduce(options.category, function (items, item) {
    var citem = _.find(options.data, function (da) {
      return da.typ == item;
    });

    return items + '<li data-name="' + item + '">' + citem.nm + '</li>';
  }, '');

  $(obj).find('.emoji-nav').empty().append(navs);
}

; //渲染表情

function render_emoji(obj, options, typ) {
  var list = _.find(options.data, function (item) {
    return item.typ == typ;
  });

  if (!list) {
    list = options.data[0];
  }

  ;

  var imgs = _.reduce(list.items, function (items, item) {
    if (item) {
      return items + '<img title="' + item.name + '" src="' + options.path + item.src + '" data-name="' + item.name + '" data-src="' + options.path + item.src + '">';
    } else {
      return items;
    }
  }, '');

  $(obj).find('.emoji-content').empty().append(imgs);
  $(obj).find('.emoji-nav li[data-name=' + list.typ + ']').addClass('on').siblings().removeClass("on");
}

; //切换元素

function switchitem(obj, options) {
  $(obj).on(options.trigger, '.emoji-nav > li', function () {
    render_emoji(obj, options, $(this).attr('data-name'));
    return false;
  });
  $(obj).on('click', '.emoji-content > img', function () {
    options.insertAfter({
      name: $(this).attr('data-name'),
      src: $(this).attr('data-src')
    });
  });
}

;

function togglew(obj, option) {
  $(obj).on('click', '.emoji-tbtn', function () {
    $(obj).find('.emoji-inner').toggle();
    return false;
  });
  $(document).click(function () {
    $(obj).hide();
    $(obj).find('.emoji-inner').hide();
  });
}

; //jq插件

function initEmoji(opt) {
  var emojiContainer = $('#emoji_container');
  var options = $.extend({}, getData(), opt || {});

  face.hide = function () {
    emojiContainer.hide();
    emojiContainer.find('.emoji-inner').hide();
  };

  face.show = function () {
    emojiContainer.show();
    emojiContainer.find('.emoji-inner').show();
  };

  return emojiContainer.each(function () {
    if (!emojiContainer.find('.val').length > 0) {
      return false;
    }

    ; //初始化tab

    render_nav(emojiContainer, options); //初始化表情

    render_emoji(emojiContainer, options); //切换表情

    switchitem(emojiContainer, options); //点击显示表情

    togglew(emojiContainer, options);
  });
}

; // 插入、修改表情图片

function insertContent(myValue, t) {
  var messageArea = $('#message_area');
  var $t = messageArea[0];

  if (window.getSelection) {
    var startPos = $t.selectionStart;
    var endPos = $t.selectionEnd;
    var scrollTop = $t.scrollTop;
    $t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos, $t.value.length);
    messageArea.focus();
    $t.selectionStart = startPos + myValue.length;
    $t.selectionEnd = startPos + myValue.length;
    $t.scrollTop = scrollTop;

    if (arguments.length == 2) {
      $t.setSelectionRange(startPos - t, $t.selectionEnd + t);
      messageArea.focus();
    }
  } else if (document.selection) {
    messageArea.focus();
    var sel = document.selection.createRange();
    sel.text = myValue;
    messageArea.focus(); //moveStart

    sel.moveStart('character', -l);
    var wee = sel.text.length;

    if (arguments.length == 2) {
      var l = $t.value.length;
      sel.moveEnd("character", wee + t);
      t <= 0 ? sel.moveStart("character", wee - 2 * t - myValue.length) : sel.moveStart("character", wee - t - myValue.length);
      sel.select();
    }
  } else {
    messageArea.value += myValue;
    messageArea.focus();
  } // 显示发送按钮


  $("#input-add-field").hide();
  $("#send_msg_btn").show();
}

function createEmoji() {
  var opts = {
    insertAfter: function insertAfter(item) {
      // insertContent(document.getElementById('message_area'), item.src, '[:' + item.name + ':]')
      insertContent('[:' + item.name + ':]');
    },
    path: "images/"
  };
  initEmoji(opts);
  var arr = getEmoji();

  face.toEmoji = function (str) {
    var emojis = [];

    _.each(arr, function (ele) {
      if (ele !== null) {
        emojis.push(ele.name);
      }
    });

    var regex = new RegExp('\\[:(' + (emojis.length > 1 ? emojis.join("|") : emojis + "") + '):\\]', 'g');

    var emoji = function emoji(key) {
      key = key.replace("[:", "").replace(":]", "");

      var list = _.filter(arr, function (ele) {
        if (ele == null) {
          return false;
        }

        return ele.name == key;
      });

      return '<img name="[:' + key + ':]" src="' + opts.path + list[0].src + '" alt="' + key + '" style="width: 25px;height: 25px;cursor: pointer;vertical-align: middle;"/>';
    };

    return str.replace(regex, emoji);
  };

  return face;
}

function getEmoji(category) {
  var datas;

  if (category) {
    datas = this.data = _.filter(getData().data, function (ele) {
      return _.contains(category, ele.typ);
    });
  } else {
    datas = getData().data;
  }

  var i = 0,
      len = datas.length;
  var arr = [];

  for (; i < len; i++) {
    var item = datas[i].items,
        j = 0,
        len1 = item.length;

    for (; j < len1; j++) {
      arr.push(item[j]);
    }
  }

  return arr;
}

function getData() {
  return {
    data: [{
      "typ": "EmojiCategory-People",
      "nm": "人物",
      "items": [{
        "name": "大笑",
        "src": "unicode/1f604.png"
      }, {
        "name": "脸红",
        "src": "unicode/1f60a.png"
      }, {
        "name": "色",
        "src": "unicode/1f60d.png"
      }, {
        "name": "吻",
        "src": "unicode/1f618.png"
      }, {
        "name": "调皮",
        "src": "unicode/1f61b.png"
      }, {
        "name": "失望",
        "src": "unicode/1f61e.png"
      }, {
        "name": "笑哭",
        "src": "unicode/1f602.png"
      }, {
        "name": "流泪",
        "src": "unicode/1f62d.png"
      }, {
        "name": "冷汗",
        "src": "unicode/1f630.png"
      }, {
        "name": "傻笑",
        "src": "unicode/1f605.png"
      }, {
        "name": "流汗",
        "src": "unicode/1f613.png"
      }, {
        "name": "严肃的",
        "src": "unicode/1f628.png"
      }, {
        "name": "吃惊",
        "src": "unicode/1f631.png"
      }, {
        "name": "生气",
        "src": "unicode/1f620.png"
      }, {
        "name": "愤怒",
        "src": "unicode/1f621.png"
      }, {
        "name": "高兴",
        "src": "unicode/1f606.png"
      }, {
        "name": "可口",
        "src": "unicode/1f60b.png"
      }, {
        "name": "闭嘴",
        "src": "unicode/1f637.png"
      }, {
        "name": "酷",
        "src": "unicode/1f60e.png"
      }, {
        "name": "睡觉",
        "src": "unicode/1f634.png"
      }, {
        "name": "困惑",
        "src": "unicode/1f615.png"
      }, {
        "name": "天使",
        "src": "unicode/1f607.png"
      }, {
        "name": "坏笑",
        "src": "unicode/1f60f.png"
      }]
    }],
    path: 'images/',
    category: ['EmojiCategory-People'],
    showbar: true,
    trigger: 'click',
    insertAfter: function insertAfter() {}
  };
}

var Pdialog = {
  showDialog: function showDialog(options) {
    function doShowDialog() {
      options = $.extend({
        title: "提示",
        content: "提示框"
      }, options);
      var pDialogMaskWrapper = '<div id="p_dialog_mask_wrapper">';
      var pImgContainer = '<div id="p_dialog_container">';
      var pDialogHeader = '<div id="p_dialog_header"><div id="p_dialog_header_name">' + options.title + '</div><div id="p_dialog_close"></div></div>';
      var pDialogContent = '<div id="p_dialog_content">' + options.content + '</div>';
      var pImgOpts = '<div id="p_dialog_opts">' + '<span id="p_dialog_submit">关闭</span>' + '</div>';
      var endTag = "</div>";
      $('#p_dialog_mask_wrapper').remove();
      var appendHtml = pDialogMaskWrapper + pImgContainer + pDialogHeader + pDialogContent + pImgOpts + endTag;
      $('body').append(appendHtml);
      initEvent();
    }

    function initEvent() {
      $('#p_dialog_mask_wrapper').on('click', function () {
        $('#p_dialog_mask_wrapper').remove();
      });
      $('#p_dialog_close').on('click', function () {
        $('#p_dialog_mask_wrapper').remove();
      });
      $('#p_dialog_container').on('click', function (event) {
        Common.stopPropagation(event);
      });
      $('#p_dialog_submit').on('click', function () {
        $('#p_dialog_mask_wrapper').remove();
      });
    }

    doShowDialog();
  },
  showAsk: function showAsk(options, callback) {
    function doShowConfirm() {
      options = $.extend({
        title: "提示",
        content: "提示框",
        btnContent: "关闭"
      }, options);
      var pDialogMaskWrapper = '<div id="p_dialog_mask_wrapper">';
      var pImgContainer = '<div id="p_dialog_container">';
      var pDialogHeader = '<div id="p_dialog_header"><div id="p_dialog_header_name">' + options.title + '</div></div>';
      var pDialogContent = '<div id="p_dialog_content">' + options.content + '</div>';
      var pImgOpts = '<div id="p_dialog_opts">' + '<span id="p_dialog_submit">' + options.btnContent + '</span>' + '</div>';
      var endTag = "</div>";
      $('#p_dialog_mask_wrapper').remove();
      var appendHtml = pDialogMaskWrapper + pImgContainer + pDialogHeader + pDialogContent + pImgOpts + endTag;
      $('body').append(appendHtml);
      initEvent();
    }

    function initEvent() {
      $('#p_dialog_mask_wrapper').on('click', function () {
        return false;
      });
      $('#p_dialog_container').on('click', function (event) {
        Common.stopPropagation(event);
      });
      $('#p_dialog_submit').on('click', function () {
        $('#p_dialog_mask_wrapper').remove();
        callback && callback instanceof Function && callback();
      });
    }

    doShowConfirm();
  }
};
var Chat = {
  startChat: function startChat(robotData) {
    initComponent();
    initEvent(robotData);
  }
};
var imgb64;
var orderCode,
    arrOrder = [],
    pageNum = 1;

function initComponent() {
  initTab();
  initLoadHots();
  loadGoods();
  initToolsBar();
  initOrderList();
}

function initEvent(robotData) {
  $(window).resize(function () {
    initWindon();
  });

  window.onbeforeunload = function (e) {// io.close()
  };

  $('body').click(function (e) {
    var _target = $(e.target); //关闭表情框


    if (_target.closest("#emoji_container").length == 0) {
      $('#emoji_container').hide();
      Emoji.face.hide();
    }
  }); // 图片粘贴

  $("#message_area").unbind("paste").bind("paste", function (e) {
    pasteEvent(e);
  });
  $("#set-file").unbind("click").bind('click', function () {
    Common.uploadImg(Api.uploadImage, function (res) {
      if (res.rc == 0) {
        var img = Common.createImgHtml(res.imgurl, true);
        io.sendImg(img, res.imgurl, "IMAGE");
      } else {
        Pdialog.showDialog({
          content: res.rm
        });
      }
    });
    return false;
  });
  $('#send-imgb64').unbind('click').bind('click', function () {
    if (!imgb64) {
      $('.ay-mask').hide();
      Pdialog.showDialog({
        content: "未获取到图片信息，请重新操作"
      });
      return false;
    }

    Common.uploadImgB64(Api.uploadImgb64, imgb64, function (res) {
      if (res.rc == 0) {
        $('.ay-mask').hide();
        var img = Common.createImgHtml(res.imgurl, true);
        io.sendImg(img, res.imgurl, "IMAGE");
      } else {
        Pdialog.showDialog({
          content: res.rm
        });
      }
    });
    return true;
  });
  $('#send-imgb64-cancel').unbind('click').bind('click', function () {
    $('.ay-mask').hide();
    return true;
  }); //满意度评价---pc

  $("#set-evaluate").unbind('click').bind('click', function () {
    if (!customer.cid) {
      Pdialog.showDialog({
        content: "咨询后再评价的哦!"
      });
      return false;
    }

    if ($("#opinion_submit").data("isOpinion")) {
      Pdialog.showDialog({
        content: "您已经评论过了!"
      });
      return false;
    }

    var $opin = $("#option_box");

    if ($opin.is(":visible")) {
      $opin.hide();
      return false;
    }

    $opin.show();
    return false;
  });
  $("#option_box").delegate(".close-tool,.cancel", "click", function () {
    $("#option_box").hide();
    return false;
  }).delegate("input[name=evaluation]:radio", "change", function () {
    var opinion_value = $('input[name=evaluation]:radio:checked').val() || '5'; // 获取评价

    if (opinion_value == "1" || opinion_value == "2" || opinion_value == "3") {
      $("#suggest_box").css("visibility", "visible");
    } else {
      $("#suggest_box").css("visibility", "hidden");
    }
  }).delegate("#opinion_submit", "click", function () {
    if ($("#opinion_submit").data("isOpinion")) {
      Pdialog.showDialog({
        content: "您已经评论过了!"
      });
      return false;
    }

    var opin_type = $('input[name=evaluation]:radio:checked').val() || ''; // 获取评价

    var opin_content = $("#opinion_desp").val(); //获取建议

    if ((opin_type == "1" || opin_type == "2") && $.trim(opin_content).length < 10) {
      Pdialog.showDialog({
        content: "请填写您的建议且建议内容至少10个字!"
      });
      $("#opinion_desp").focus();
      return false;
    }

    if ($.trim(opin_content)) {
      opin_content = EscapeSequence.filterHtmlJsSpaceEnter(opin_content);
    }

    var params = {
      chatId: customer.cid,
      opinion: opin_type,
      suggest: opin_content
    };

    if (params.chatId && params.opinion && (params.opinion != '1' || params.opinion != '2')) {
      appraiseElement(Api.opinion, params);
    } else if (params.chatId && params.opinion && (params.opinion == '1' || params.opinion == '2') && params.suggest) {
      appraiseElement(Api.opinion, params);
    } else {
      Pdialog.showDialog({
        content: "请完善评论信息!"
      });
    }
  }); // 加载更多

  $('.loading').off("click").click(function (param) {
    initOrderList(1);
    orderData(arrOrder, arrOrder.length);
  }); // 发送链接

  $('body').off("click").on('click', 'ul li .send-order', function (e) {
    var index = $(this).parent().parent().parent().index();
    var prdindex = $(this).attr('data-index');
    var data = arrOrder[index];
    var prddata = arrOrder[index].prdInfoList[prdindex];
    var sendData = {
      "orderCode": data.orderId,
      "orderTime": data.orderTime,
      "orderAmount": data.orderAmount,
      "orderStatusInfo": data.orderStatusInfo,
      "prdInfo": {
        "prdImgUrl": prddata.prdImgUrl,
        "prdName": prddata.prdName,
        "prdAcount": prddata.prdAcount,
        "prdPrice": prddata.prdPrice,
        "prdCode": prddata.prdCode,
        "prdDetailUrl": prddata.prdDetailUrl
      },
      "orderAcount": data.prdInfoList.length
    }; //是否介入机器人

    if (robotData && robotData.isRobotWork === 1) {
      $('.question').hide();
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: JSON.stringify(sendData),
        type: 'ORDER'
      });
      var robotTips;

      if (robotData.authResult.rc === 0) {
        robotTips = "点击右侧订单信息查看物流，打开详细物流轨迹，或<div class='ContactArtificial' id='ContactArtificial'>联系人工客服</div>";
      } else if (robotData.authResult.rc === 2) {
        robotTips = "点击右侧订单信息查看物流，打开详细物流轨迹；当前时间人工客服不在线，人工客服工作时间：" + robotData.teamStartTime + "~" + robotData.teamEndTime;
        auth();
      }

      ChatResolver.robotRender(robotTips);
      robotService.getRobotChat(JSON.stringify(sendData), robotTips, "ORDER");
    } else {
      io.sendMsg(JSON.stringify(sendData), 'ORDER');
    }
  }); //机器转人工按钮

  $('body').on('click', '.ContactArtificial', function () {
    var text = $(this).text();

    if (robotData.authResult.rc === 0) {
      robotConnectStatus.isRobotWork = 0;
      buildChat(robotData.authResult.data);
      $('.question').hide();
      ChatResolver.robotRender(Constant.build_success);
      robotService.getRobotChat(text, Constant.build_success); // 关闭类型

      robotService.closeType();
    } else {
      ChatResolver.robotRender(robotData.authResult.data.offlineMsg);
      robotService.getRobotChat(text, robotData.authResult.data.offlineMsg);
      auth();
    }
  }); // 查看物流

  $('#order_ul').off("click").on('click', 'ul li.view', function (e) {
    var index = $(this).parents().index();
    var data = arrOrder[index];

    if (!$(this).hasClass('active')) {
      $(this).addClass('active').parents().siblings().children('.view').removeClass('active');
      $(this).siblings('.logisticsList').show().parents().siblings().children('.logisticsList').hide();
      initLogistics(data);
    } else {
      $(this).removeClass('active').siblings('.logisticsList').hide();
    }
  });
  $(document).on('click', '.container .more', function () {
    $(this).parent().addClass('showChat');
    $(this).siblings('.putItAway').show();
    $(this).hide();
  });
  $(document).on('click', '.container .putItAway', function () {
    $(this).parent().removeClass('showChat');
    $(this).siblings('.more').show();
    $(this).hide();
  });
}

function appraiseElement(opinion, params) {
  Request.jsonp(opinion, params, true, function (res) {
    if (res.rc == 0) {
      $("#opinion_desp").val("");
      $("div.choise-eva input").removeAttr("checked");
      $("#opinion_submit").data("isOpinion", true);
      Pdialog.showDialog({
        content: res.rm
      });
      $("#option_box").hide();
      return false;
    } else {
      Pdialog.showDialog({
        content: res.rm
      });
    }
  });
}

function initToolsBar() {
  $("#opinion_desp").val("");
  $('#set-face').click(function (e) {
    $('#emoji_container').show();
    Emoji.face.show();
    return false;
  });
  $(document).click(function () {
    $("#emoji_container").hide();
  });
} //剪切板粘贴图片


function pasteEvent(e) {
  var event = e.originalEvent; // 添加到事件对象中的访问系统剪贴板的接口

  var clipboardData = event.clipboardData,
      i = 0,
      items,
      item,
      types;

  if (clipboardData) {
    items = clipboardData.items;

    if (!items) {
      return;
    }

    item = items[0]; // 保存在剪贴板中的数据类型

    types = clipboardData.types || [];

    for (; i < types.length; i++) {
      if (types[i] === 'Files') {
        item = items[i];
        break;
      }
    } // 判断是否为图片数据


    if (item && item.kind === 'file' && item.type.match(/^image\//i)) {
      // 读取该图片
      imgReader(item);
    }
  }
}

function imgReader(item) {
  var file = item.getAsFile();
  var reader = new FileReader();

  reader.onload = function (e) {
    imgb64 = e.target.result;
    $("#showPic").html("");
    $("#showPic").append('<p><img id="pasteImg" src="' + e.target.result + '" class="sendImg"></p>');
    $('#pasteImg').attr("style", "max-width: 480px; max-height:200px");
    $('.ay-mask').show();
  };

  reader.readAsDataURL(file);
}

;

function initChat() {
  //确认 customer.real 是干啥的
  Service.loadChatRecord();

  if (customer && customer.real == 1) {
    $("#load_chat_more").unbind("click").bind("click", function () {
      Service.loadChatRecord();
    });
  } else {
    $('.load-chat-more').hide();
    $('.history-up').hide();
  }
} //Tab添加切换事件


function initTab() {
  $("#hot_tab").unbind("click").bind("click", function () {
    $("#hot_tab").siblings().removeClass("active").end().addClass("active");
    $("#hot_list").siblings().hide().end().show();
  });
  $("#goods_detail").unbind("click").bind("click", function () {
    $("#goods_detail").siblings().removeClass("active").end().addClass("active");
    $("#div_product_info").siblings().hide().end().show();
  });
  $("#my_orders").unbind("click").bind("click", function () {
    $("#my_orders").siblings().removeClass("active").end().addClass("active");
    $("#div_my_orders").siblings().hide().end().show();
  });
} // 加载热点问题


function initLoadHots() {
  var params = {};
  Request.jsonp(Api.hot, params, true, function (res) {
    if (res.rc == 0) {
      var tempDom = [];
      $("#hot_ul").val("");
      $.each(res.data, function (i, question) {
        tempDom.push('<li><h6><a href="javascript:;">' + (i + 1) + ". " + question.question + '</a></h6><div class="answer" style="display: none;"><i class="icons"></i><p style="font-size:12px;">' + question.answer + '</p></div></li>');
      });
      $("#hot_ul").append(tempDom.join("")); //初始化常见问题事件

      $("#hot_ul li h6").click(function () {
        var $self = $(this);
        var $content = $self.next();
        var $title = $self.find("a");
        var $parent = $self.parent();

        if ($content.is(":visible")) {
          $title.removeClass("active");
          $content.slideUp();
        } else {
          $title.addClass("active");
          $content.slideDown();
          $parent.siblings().find(".answer").slideUp();
          $parent.siblings().find("h6 a").removeClass("active");
        }

        return false;
      });
    } else {
      Pdialog.showDialog({
        content: res.rm
      });
    }
  });
}

function orderData(res, count) {
  var data = "";

  for (var i = 0; i < count; i++) {
    data += "<ul><li>\n            <div>\n                <p style=\"width: 85%; float: left;\"><label>\u8BA2\u5355\u53F7:</label><span title=\"".concat(res[i].orderId, "\">").concat(res[i].orderId, "</span></p>\n                <span style=\"float:right\"><b> ").concat(res[i].orderStatusInfo, " </b></span>\n            </div>\n            <label>\u4E0B\u5355\u65F6\u95F4:</label><span> ").concat(res[i].orderTime, " </span>\n        </li>").replace(/ *[\r|\n] */gm, '');

    for (var j = 0; j < res[i].prdInfoList.length; j++) {
      data += "<li class=\"prdInfoLi\">\n                        <div class=\"img\">\n                            <img src=\"".concat(res[i].prdInfoList[j].prdImgUrl, "\" alt=\" \"/>\n                        </div>\n                        <div class=\"orderInfo\">\n                            <a href=\"").concat(res[i].prdInfoList[j].prdDetailUrl ? res[i].prdInfoList[j].prdDetailUrl : '#', "\" target=\"_blank\">\n                                <p title=\"").concat(res[i].prdInfoList[j].prdName, "\" class=\"orderInfo_prdname\">").concat(res[i].prdInfoList[j].prdName, "</p>\n                            </a>\n                            <p style=\"color: #999;\">\n                                <span>\u5546\u54C1\u7F16\u53F7\uFF1A</span>\n                                <span style=\"margin-left: -0.5rem;\" title=\"").concat(res[i].prdInfoList[j].prdName, "\">").concat(res[i].prdInfoList[j].prdCode, " </span>\n                            </p> \n                            <p>\n                                <lable class=\"orderInfo_prdAcount\">\u6570\u91CF:</lable>\n                                <span class=\"orderInfo_prdAcount\" style=\"padding-right: 0.5rem;\">").concat(res[i].prdInfoList[j].prdAcount, "</span>\n                                <span class=\"orderInfo_prdPrice\"><b>\uFFE5").concat(res[i].prdInfoList[j].prdPrice, " </b></span>\n                            </p>\n                            <button class=\"send-order\" data-index=\"").concat(j, "\" >\u53D1\u9001</button>\n                        </div>\n                    </li>").replace(/ *[\r|\n] */gm, '');

      if (res[i].prdInfoList[j].additional) {
        for (var l = 0; l < res[i].prdInfoList[j].additional.length; l++) {
          data += "<li class=\"prdInfoLi\"s>\n                                <div class=\"img\">\n                                    <img src=\"".concat(res[i].prdInfoList[j].additional[l].prdImgUrl, "\" alt=\"\" />\n                                </div>\n                                <div class=\"orderInfo\">\n                                    <p title=\"").concat(res[i].prdInfoList[j].additional[l].prdName, "\"><b style=\"color:#e2231a;\">").concat(res[i].prdInfoList[j].additional[l].isGift === "1" ? "【赠品】" : res[i].prdInfoList[j].additional[l].isService === "0" ? "" : "【服务】", "</b>").concat(res[i].prdInfoList[j].additional[l].prdName, "</p>\n                                    <p style=\"color: #000\"><lable>\u6570\u91CF:</lable>\n                                        <span style=\"padding-right: 0.5rem;\">").concat(res[i].prdInfoList[j].additional[l].prdAcount, "</span>\n                                        <span style=\"display: ").concat(res[i].prdInfoList[j].additional[l].isGift === "1" ? "none" : "inline-block", ";\"><b>\uFFE5").concat(res[i].prdInfoList[j].additional[l].prdPrice, "</b></span>\n                                    </p>\n                                </div>\n                            </li>").replace(/ *[\r|\n] */gm, '');
        }
      }
    }

    data += "<li>\n            <div style=\"display: inline-block; line-height: 30px\">\n                <span>\u5171</span><span>".concat(res[i].prdInfoList.length, "</span><span style=\"padding-right:12px;\">\u4EF6</span>\n                <span>\u8BA2\u5355\u91D1\u989D\uFF1A</span><span style=\"color: #e2231a; margin-left: -8px\"><b>\uFFE5").concat(res[i].orderAmount, " </b></span>\n            </div>\n\n        </li>\n        <li class=\"view\" style=\"justify-content: space-between;\" \"data-index=\"").concat(i, "\"><button>\u67E5\u770B\u7269\u6D41</button>\n            <img src=\"./images/chat/arrow.png\">\n        </li>\n        <li style=\"display:none\" class=\"logisticsList\"></li></ul>").replace(/ *[\r|\n] */gm, '');
  }

  $('#order_ul').html(data);
} // 加载订单列表


function initOrderList(num) {
  var urlParams = Common.getUrlParams();
  var ttc = urlParams.ttc ? urlParams.ttc : 1;
  var params = {
    ttc: ttc,
    pageNum: pageNum,
    pageSize: 3
  };
  pageNum++;
  Request.jsonp(Api.orderList, params, true, function (res) {
    if (res.rc === 0) {
      if (res.data) {
        arrOrder = arrOrder.concat(res.data);
        orderData(arrOrder, arrOrder.length);
        $('#my_orders').show().addClass('active').siblings().removeClass('active');
        $('#div_my_orders').show().siblings().hide();
      } else {
        $('.loading').hide();
        $('.loading_end').show();
        setTimeout(function () {
          $('.loading_end').hide();
        }, 600);
      }
    } else {
      $('.myorder_nall').show(); // $('.loading').hide();

      num === 1 ? '' : $('#my_orders').hide();
    }
  });
}

function logisticsData(res, data) {
  var logData = "<div class=\"package-status\"><div class=\"status-box\">\n            <ul class=\"status-list\" id=\"status-list\">\n            <div style=\"display: list-item;     position: relative;top: 18px\"><div class=\"status-content-latest\">".concat(data.deliveryAddress.address, "</div></div>");

  for (var i = 0; i < res.data.logistics0.length; i++) {
    logData += "<li class=\"test ".concat(i === 0 && data.orderStatus === "9" ? "endact" : "", " ").concat(i === res.data.logistics0.length - 1 ? "firstact" : "", "\" style=\"display:block\">\n                    <div class=\"status-content-before\">").concat(res.data.logistics0[i].lgdesc, "</div>\n                    <div class=\"status-time-before\">").concat(res.data.logistics0[i].lgtime, "</div>\n                </li>");
  }

  logData += '</ul></div></div>';
  $('.logisticsList').html(logData);
}

function logisticsNull(res) {
  var logData = "<div class=\"package-status\"><div class=\"status-box\">\n        <ul><div style=\"display: list-item;\"><div class=\"status-content-null\">\u6682\u65E0\u7269\u6D41\u4FE1\u606F\uFF01</div></div></ul></div></div>".replace(/ *[\r|\n] */gm, '');
  $('.logisticsList').html(logData);
} // 加载物流


function initLogistics(data) {
  var urlParams = Common.getUrlParams();
  var ttc = urlParams.ttc ? urlParams.ttc : 1;
  var params = {
    ttc: ttc,
    orderCode: data.orderId,
    cn: cn
  };
  Request.jsonp(Api.logistics, params, true, function (res) {
    if (res.rc == 0) {
      logisticsData(res, data);
    } else {
      logisticsNull(res);
    } // that.addClass('active');
    // that.siblings('.logisticsList').show();

  });
}

function loadGoods() {
  var gc = Common.getUrlParams().gc;
  Request.jsonp(Api.goodsDetail, {
    gc: gc,
    plat: 1
  }, true, function (res) {
    if (res.rc === 0) {
      var goodsDetail;

      if (res.data) {
        goodsDetail = JSON.parse(res.data);
      }

      if (goodsDetail && goodsDetail.items && goodsDetail.items.length > 0) {
        var item = goodsDetail.items[0];

        if (item.path && item.path.charAt(0) === '/') {
          $('#goods_pic_url').attr('src', 'https://p1.lefile.cn' + item.path);
        } else {
          $('#goods_pic_url').attr('src', 'https://p1.lefile.cn/' + item.path);
        }

        if (Common.isMobile()) {
          $('#pro_url').attr('href', item.wapDetailUrl);
          $('#goods_url').attr('href', item.wapDetailUrl);
        } else {
          $('#goods_url').attr('href', item.pcDetailUrl);
          $('#pro_url').attr('href', item.pcDetailUrl);
        }

        $('#pro_name').html(item.name);
        $('#pro_brief').html(item.brief);
        setTimeout(function () {
          $('#goods_detail').show();

          if (!$('#order_ul').children().length) {
            $('#goods_detail').addClass('active').siblings().removeClass('active');
            $('#div_product_info').show().siblings().hide();
          }
        });
      }
    }
  });
}

var customer;
var io;
var isMobile = 1;
var ioType = window.WebSocket ? true : false;
var robotConnectStatus = null; //auth接口返回的数据

var cn = "";
$(function () {
  IFdLowerIE();
  initWindon();
  document.domain = Config.domain;
}); //是否是低版本浏览器 IE9及以下

function IFdLowerIE() {
  try {
    var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串

    var IFIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE浏览器

    if (IFIE) {
      //如果是IE浏览器 获取具体的版本
      var IE5 = IE55 = IE6 = IE7 = IE8 = IE9 = false;
      var CurIEVer = new RegExp("MSIE (\\d+\\.\\d+);");
      CurIEVer.test(userAgent);
      var IEVer = parseFloat(RegExp["$1"]);
      IE55 = IEVer == 5.5;
      IE6 = IEVer == 6.0;
      IE7 = IEVer == 7.0;
      IE8 = IEVer == 8.0;
      IE9 = IEVer == 9.0;

      if (IE55 || IE6 || IE7 || IE8 || IE9) {
        //如果是IE9及以下 就处理浏览器返回true 进行某些特殊处理
        isIE();
      } else {
        auth();
      }
    } else {
      auth();
    }

    return false;
  } catch (e) {
    console.log(e);
    return false;
  }
}

function initWindon() {
  var curHeight = $(window).height();

  if (curHeight > 510) {
    $("div.left-main").height(curHeight - 111);
    $("div.right-slider").height(curHeight - 75);
    $("div.right-slider .tab-body").height(curHeight - 110);
    $("div.show-chat").height(curHeight - 324);
  }
}

function isIE() {
  var content = "<div class=\"identification\">\n                    <p>\u4E3A\u4E86\u4EAB\u53D7\u66F4\u68D2\u7684\u8D2D\u7269\u4F53\u9A8C\uFF0C\u4FDD\u969C\u60A8\u7684\u8D2D\u7269\u5B89\u5168\uFF0C\u5EFA\u8BAE\u60A8\u4F7F\u7528IE10\u53CA\u4EE5\u4E0A\u7248\u672C\u7684\u6D4F\u89C8\u5668</p>\n                </div>";
  $('body').append(content);
}

function auth() {
  var urlParams = Common.getUrlParams();
  var ttc = urlParams.ttc ? urlParams.ttc : 1;
  var skc = urlParams.skc;
  var buc = urlParams.buc;
  var gc = urlParams.gc;
  var oc = urlParams.oc;
  var tag = urlParams.tag;
  var params = {
    ttc: ttc,
    skc: skc,
    buc: buc,
    gc: gc,
    oc: oc,
    tag: tag,
    device: isMobile,
    origin: 1,
    io: ioType ? "ws" : "poll"
  };
  Request.jsonp(Api.auth, params, false, function (res) {
    cn = res.data.cn ? res.data.cn : "";

    switch (res.rc) {
      // 成功
      case 0:
        customer = res.data;
        initChat();
        getChecked(res);

        if (res.skn && res.skn.indexOf('EFF') !== -1) {
          params.ttc = 3;
        }

        break;
      // 需要登录

      case 1:
        var encodeURISearch = encodeURIComponent(window.location.href); //编码地址

        res.data && res.data.loginUrl ? window.location.href = res.data.loginUrl + '&ru=' + encodeURISearch : Pdialog.showDialog({
          content: res.rm
        });
        break;
      // 非工作时间

      case 2:
        initChat();
        getChecked(res);
        break;
      // 无法正确路由到skc

      case 3:
        var host = window.location.host;
        window.location.href = '//' + host;
        break;

      case 5:
        $('.service-panel').hide();
        Pdialog.showDialog({
          content: "由于在咨询过程中，咨询内容包含不合法信息，已暂时限制咨询请求！"
        });
        break;

      default:
        $('.service-panel').hide();
        Pdialog.showDialog({
          content: "初始化信息失败，请重试！"
        });
        break;
    }
  }, function (res) {
    $('.service-panel').hide();
    Pdialog.showDialog({
      content: "初始化信息失败，请重试！"
    });
  });
}

function getChecked(all) {
  var params = {
    t: new Date().getTime()
  };
  var CookieBool = false;
  Request.jsonp(Api.qaChecked, params, false, function (res) {
    if (res.rc === 0) {
      //判断 已经登录过的(实名)情况下 是否接入过人工
      if (all.data.real === '1') {
        if (document.cookie.indexOf("OCIM-Skill-".concat(all.data.ttc, "-").concat(all.data.skc, "=")) > -1) CookieBool = true;
      } //自研助手


      if (res.data && res.data.isRobotWork === 1 && res.data.connectType === "1" && !CookieBool) {
        robotConnectStatus = {
          "isRobotWork": res.data.isRobotWork,
          "connectType": res.data.connectType,
          "teamStartTime": res.data.teamStartTime,
          "teamEndTime": res.data.teamEndTime,
          "authResult": all,
          "userIdentity": res.data.robotCode
        };
        assistantService.clickEventAssistant();
        Chat.startChat(robotConnectStatus);
        assistantService.getWelcome();
        $("#chat_service_status_msg").text(Constant.assistant_tip);
        $(".tool-btn-group").css('display', 'none'); //第三方服务机器人
      } else if (res.data && res.data.isRobotWork === 1 && res.data.connectType === "2" && !CookieBool) {
        robotConnectStatus = {
          "url": res.data.robotUrl,
          "sessionId": res.data.customerName + params.t,
          "userId": res.data.customerName,
          "isRobotWork": res.data.isRobotWork,
          "connectType": res.data.connectType,
          "teamStartTime": res.data.teamStartTime,
          "teamEndTime": res.data.teamEndTime,
          "authResult": all,
          "userIdentity": res.data.robotCode
        };
        robotService.clickEventRobot(robotConnectStatus);
        Chat.startChat(robotConnectStatus);
        robotService.getServiceWelcome(robotConnectStatus, all);
        $("#chat_service_status_msg").text(Constant.robot_tip);
        $(".tool-btn-group").css('display', 'none'); //直接 接入人工客服
      } else {
        if (all.rc === 0) {
          //工作时间
          robotConnectStatus = {
            isRobotWork: 0
          };
          Chat.startChat();
          buildChat(all.data);
        } else {
          //非工作时间
          $("#chat_service_status_msg").text(all.data.offlineMsg);
          Pdialog.showDialog({
            content: all.data.offlineMsg
          });
        }
      }
    }
  });
}

function getRedirect() {
  Request.jsonp(Api.redirect, '', true, function (res) {});
}

function buildChat(customer) {
  notify.open = true;

  if (!io) {
    //连接人工之前判断 在时间周期内是否接入过人工
    if (customer.real === "1") {
      try {
        getRedirect();
      } catch (e) {
        console.log(e);
      }
    }

    if (ioType) {
      io = WsClient({
        url: Config.ws + '/ws.io',
        customer: customer
      });
    } else {
      io = HpClient({
        url: Config.poll + '/poll.io',
        customer: customer
      });
    }
  }
}

var robotService = {
  str: "",
  arr: [],
  data: {},
  isclick: true,
  longGraphicUrl: "",
  askLogId: "",
  clickEventRobot: function clickEventRobot(data) {
    $("#chatDiv").off("click").on("click", ".recommendQuestion", function () {
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: $(this).html(),
        type: 'TEXT'
      }); // wap没有

      robotService.getServiceRobot($(this).html(), data);
    });
    $("#chatDiv").on("click", ".eva-btn-yes", function () {
      if (robotService.isclick) {
        robotService.getAnswerEvaluation(1, $(this).attr("data-askLogId"), data);
      }
    });
    $("#chatDiv").on("click", ".eva-btn-no", function () {
      if (robotService.isclick) {
        robotService.askLogId = $(this).attr("data-askLogId");
        robotService.getAnswerEvaluation(2, $(this).attr("data-askLogId"), data);
        $('.dialogRobot').show();
      }
    });
    $(".dialogRobot").off('click').on("click", ".reason", function () {
      if ($(this).hasClass("active")) {
        $(this).removeClass("active");
      } else {
        $(this).addClass("active");
      }
    });
    $(".dialogFooter").off('click').on("click", ".button", function () {
      var reasonlist = $('.reasonlist').find('.active');
      var string = '';
      var suggest = $("#textarea").val();

      if (suggest.length > 200) {
        alert('字数超过限制');
      } else {
        if (reasonlist.length > 0) {
          for (var i = 0; i < reasonlist.length; i++) {
            string += string == '' ? $(reasonlist[i]).html() : "～" + $(reasonlist[i]).html();
          }
        }

        robotService.getSubFeedacks(string, suggest, data); // robotService.getAnswerEvaluation(2,$(this).attr("data-askLogId"),data);

        $('.dialogRobot').hide();
        $('.reasonlist').find('.active').removeClass('active');
        $("#textarea").val("");
      }
    });
    $(".dialogRobot").on("click", ".dialogClose", function () {
      $('.dialogRobot').hide();
      $('.reasonlist').find('.active').removeClass('active');
      $("#textarea").val(""); //pc
    }); // $("#chatDiv").on('click','.container .more',function(){
    //     $(this).parent().addClass('showChat')
    //     $(this).siblings('.putItAway').show()
    //     $(this).hide()
    // })
    // $("#chatDiv").on('click','.container .putItAway',function(){
    //     $(this).parent().removeClass('showChat')
    //     $(this).siblings('.more').show()
    //     $(this).hide()
    // });
    // wap

    if (Common.isMobile()) {
      $("#chatDiv").on('click', '.mdfullclick', function () {
        // 点击长图文任意地方 , 弹出弹框
        $('.longfloat').append(robotService.longstr).show();
      });
      $('.longfloat').on('click', '.longimg', function () {
        // 点击叉号隐藏浮框
        $('.longfloat').html('<img src="./images/chatwap/error.png" class="longimg" alt="">').hide();
      });
    }

    $(document).off('click').on('click', '.chat-body .longtype', function () {
      if (robotService.longGraphicUrl != "") {
        robotService.getAnswerFile($("#message_area").val(), robotService.data, robotService.longGraphicUrl);
      }
    });
    $(document).off('click').on('click', '.goods-send-url', function () {
      var goodsUrl = $('.goods-send-url').attr("data-url");

      if (goodsUrl) {
        if (data && data.isRobotWork === 1) {
          ChatResolver.render(ChatResolver.type.outMessage, {
            content: goodsUrl,
            type: 'TEXT'
          });
          robotService.getServiceRobot(goodsUrl, data);
        }
      }
    });
  },
  getServiceWelcome: function getServiceWelcome(data, all) {
    var params = {
      "platform": "web",
      "terminal": "web",
      "sessionId": data.sessionId,
      "userId": data.userId
    };
    $.ajax({
      type: 'POST',
      url: data.url + 'welcome',
      dataType: 'json',
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "userIdentity": data.userIdentity
      },
      data: JSON.stringify(params),
      success: function success(res) {
        if (res) {
          ChatResolver.robotRender(res.data.welcome);
          robotService.getServiceSession(data, all);

          if (res.code === 2000 && res.data && res.data.welcome) {
            robotService.getSerWelWord(res.data.welcome);
          }

          robotService.data = data;
        }
      },
      error: function error(err) {
        console.log("欢迎语err", err);
      }
    });
  },
  getServiceSession: function getServiceSession(data, all) {
    var params = {
      "platform": "web",
      "terminal": "web",
      "sessionId": data.sessionId,
      "userId": data.userId,
      "address": "",
      "userInfo": {
        "name": "",
        "email": "",
        "avatar": "",
        "thumbAvatar": ""
      }
    };
    $.ajax({
      type: 'POST',
      url: data.url + 'session',
      dataType: 'json',
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "userIdentity": data.userIdentity
      },
      data: JSON.stringify(params),
      success: function success(res) {
        if (res) {
          $("#message_area").off("keydown").on("keydown", function (event) {
            if (event.key && event.key === "Enter") {
              $("#send_msg_btn").trigger('click');
              event.preventDefault();
              return false;
            }
          });
          $("#send_msg_btn").off("click").on('click', function () {
            var message = $("#message_area").val();

            if (!message || RegExp("^[ ]+$").test(message)) {
              Pdialog.showDialog({
                content: "消息不能为空"
              });
              return false;
            }

            if (message && message.length > 300) {
              Pdialog.showDialog({
                content: "消息不能超过300字"
              });
              return false;
            }

            if (message && message.length <= 300) {
              ChatResolver.render(ChatResolver.type.outMessage, {
                content: message,
                type: 'TEXT'
              });
              $("#message_area").val("");

              if (message.indexOf('人工') > -1 || message.indexOf('客服') > -1 || message.indexOf('人工客服') > -1) {
                if (all.rc === 0) {
                  robotConnectStatus.isRobotWork = 0;
                  buildChat(all.data); // wap

                  if (Common.isMobile()) {
                    $("#click-emoji").show();
                    $("#input-add-field").show();
                  }

                  ChatResolver.robotRender(Constant.build_success);
                  robotService.getRobotChat(message, Constant.build_success); // 关闭类型

                  robotService.closeType();
                } else {
                  ChatResolver.robotRender(all.data.offlineMsg);
                  robotService.getRobotChat(message, all.data.offlineMsg);
                  auth();
                }
              } else {
                robotService.getServiceRobot(message, data);
              }
            }

            return false;
          });
        }
      },
      error: function error(err) {
        console.log('服务机器人建立会话', err);
      }
    });
  },
  getServiceRobot: function getServiceRobot(msg, data, msgg) {
    // 每次发送消息的时候, 就将开关打开 , 让用户可以点击是或者否
    robotService.isclick = true;
    var params = {
      "platform": "web",
      "terminal": "web",
      "sessionId": data.sessionId,
      "userId": data.userId,
      "userQuestion": msgg ? msgg : msg,
      "ext": {}
    };
    $.ajax({
      type: 'POST',
      url: data.url + 'robotqa',
      dataType: 'json',
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "userIdentity": data.userIdentity
      },
      data: JSON.stringify(params),
      success: function success(res) {
        if (res.code === 2000) {
          var message;
          var lenovomallAnswer;
          $('.button').attr('data-askLogId', res.data.askLogId);

          switch (res.data.answerType) {
            //未理解
            case "0":
            case "5":
              message = "".concat(res.data.answer);
              break;
            //未匹配上标准问，给出建议问列表

            case "11":
              var recommendQuestion = res.data.relevantQuestion.name.map(function (item) {
                return "<a href=\"javascript:;\" class=\"recommendQuestion\">".concat(item, "</a><br/>");
              }).join("");
              message = "".concat(res.data.relevantQuestion.header, "<br/>").concat(recommendQuestion);
              break;
            //匹配上标准问

            case "1":
            case "2":
            case "3":
            case "12":
              if (res.data.messageType === "lenovomall") {
                var answerRobot = JSON.parse(res.data.answer);
                var itemsRobot;

                if (Common.isMobile()) {
                  // wap
                  itemsRobot = answerRobot.items.map(function (item) {
                    return "<a class=\"itemPcDetail\" href=\"".concat(item.pcDetailUrl, "\" target=\"_blank\" >\n                                            <dl>\n                                                <dt>\n                                                    <div class=\"itemPath\"><img src=\"http://p1.lefile.cn/").concat(item.path, "\"/></div>\n                                                </dt>\n                                                <dd>\n                                                    <div class=\"itemName\">").concat(item.name, "</div>\n                                                    <div class=\"itemRed\">\n                                                        <div class=\"itemPcPrice\">\xA5").concat(item.wapPrice, "<i  style=\"display:").concat(item.basePrice == item.wapPrice ? 'none' : 'inline-block', "; color:#979797;font-style:normal;margin-left:10px;text-decoration: line-through;\">\xA5").concat(item.basePrice, "</i></div>\n                                                        <div class=\"itemIsGift\" style=\"display: ").concat(item.activityStatus === "3" || item.isGift === "1" ? 'inline-block' : 'none', "\">\n                                                            ").concat(item.activityStatus === "3" ? "秒杀" : item.isGift === "1" ? "赠品" : item.pcCoupon === "1" && item.pcCouponMaxAmount ? item.pcCouponMaxAmount + "元" : "", "\n                                                        </div>\n                                                        <div class=\"itemPcCouponMaxAmount\" style=\"display: ").concat(item.activityStatus !== "3" && item.isGift !== "1" && item.pcCoupon === "1" && item.pcCouponMaxAmount ? 'inline-block' : 'none', "\">\u5238</div>\n                                                    <div>\n                                                </dd>\n                                            </dl>\n                                        </a>");
                  }).join("").replace(/ *[\r|\n] */gm, '');
                } else {
                  itemsRobot = answerRobot.items.map(function (item) {
                    return "<a class=\"itemPcDetail\" href=\"".concat(item.pcDetailUrl, "\" target=\"_blank\" >\n                                            <dl>\n                                                <dt><div class=\"itemPath\"><img src=\"http://p1.lefile.cn/").concat(item.path, "\"/></div></dt>\n                                                <dd>\n                                                    <div class=\"itemName\">").concat(item.name, "</div>\n                                                    <div class=\"itemRed\">\n                                                        <div class=\"itemPcPrice\">\xA5").concat(item.pcPrice, "<i style=\"visibility:").concat(item.basePrice == item.pcPrice ? 'hidden' : 'visible', ";color:#979797;font-style:normal;margin-left:10px;text-decoration: line-through;\">\xA5").concat(item.basePrice, "</i></div>\n                                                        \n                                                        <div class=\"itemIsGift\" style=\"visibility: ").concat(item.activityStatus === "3" || item.isGift === "1" ? 'visible' : 'hidden', "\">\n                                                            ").concat(item.activityStatus === "3" ? "秒杀" : item.isGift === "1" ? "赠品" : item.pcCoupon === "1" && item.pcCouponMaxAmount ? item.pcCouponMaxAmount + "元" : "", "\n                                                        </div>\n                                                        <div class=\"itemPcCouponMaxAmount\" style=\"visibility: ").concat(item.activityStatus !== "3" && item.isGift !== "1" && item.pcCoupon === "1" && item.pcCouponMaxAmount ? 'visible' : 'hidden', "\">\u5238</div>\n                                                    </div>\n                                                </dd>\n                                            </dl>\n                                        </a >");
                  }).join("").replace(/ *[\r|\n] */gm, '');
                }

                message = "<div>".concat(answerRobot.text, "</div><div class=\"itemRobot\">").concat(itemsRobot, "</div>");
                lenovomallAnswer = "<div>".concat(answerRobot.text, "</div><div class=\"itemRobot\">").concat(itemsRobot, "</div>");

                if (res.data.relevantQuestion) {
                  var _recommendQuestion = res.data.relevantQuestion.name.map(function (item) {
                    return "<a href=\"javascript:;\" class=\"recommendQuestion\">".concat(item, "</a ><br/>");
                  }).join("");

                  message += "".concat(res.data.relevantQuestion.header, "<br/>").concat(_recommendQuestion);
                }

                if (res.data.answerEvaluate) {
                  message += "</br><p style=\"border-bottom: 1px dotted lightgray;\"></p>".concat(res.data.answerEvaluate.header, "</br>\n                                                <div class=\"eva-btn-yes\" data-askLogId=").concat(res.data.askLogId, ">\n                                                    <div class=\"yes-img\"><img src=\"./images/yes-icon3x.png\"></div>&nbsp;\n                                                    <span class=\"yes-text\" style=\"color: red\">\u662F</span>\n                                                </div>\n                                                <div class=\"eva-btn-no\" data-askLogId=").concat(res.data.askLogId, ">\n                                                    <div class=\"no-img\"><img src=\"./images/no-icon3x.png\"></div>&nbsp;\n                                                    <span class=\"no-text\" style=\"color: gray\">\u5426</span>\n                                                </div>").replace(/ *[\r|\n] */gm, '');
                }
              } else if (res.data.messageType === "text") {
                //人工客服
                if (res.data.answer.indexOf("<a href='https://lecs.lenovo.com.cn/' target='_blank'>人工客服</a>") > -1) {
                  message = res.data.answer.replace("target='_blank'", "class='ContactArtificial'", "id='ContactArtificial'");
                  message = message.replace("https://lecs.lenovo.com.cn/", "javascript:;");
                } else {
                  message = res.data.answer;
                  message = message.replace(/href='#'/g, "href='javascript:;'");
                }

                if (res.data.relevantQuestion) {
                  var _recommendQuestion2 = res.data.relevantQuestion.name.map(function (item) {
                    return "<a href=\"javascript:;\" class=\"recommendQuestion\">".concat(item, "</a ><br/>");
                  }).join("");

                  message += "".concat(res.data.relevantQuestion.header, "<br/>").concat(_recommendQuestion2);
                }

                if (res.data.answerEvaluate) {
                  message += "</br><p style=\"border-bottom: 1px dotted lightgray;\"></p>".concat(res.data.answerEvaluate.header, "</br>\n                                                <div class=\"eva-btn-yes\" data-askLogId=").concat(res.data.askLogId, ">\n                                                    <div class=\"yes-img\"><img src=\"./images/yes-icon3x.png\"></div>&nbsp;\n                                                    <span class=\"yes-text\" style=\"color: red\">\u662F</span>\n                                                </div>\n                                                <div class=\"eva-btn-no\" data-askLogId=").concat(res.data.askLogId, ">\n                                                    <div class=\"no-img\"><img src=\"./images/no-icon3x.png\"></div>&nbsp;\n                                                    <span class=\"no-text\" style=\"color: gray\">\u5426</span>\n                                                </div>").replace(/ *[\r|\n] */gm, '');
                } // 多气泡的时候进来


                if (res.data.answer.indexOf('<bubble value="1">') > -1) {
                  var bubbles = res.data.answer.match(/<\w+?><bubble value="1">.*?<\/bubble>.*?<\/\w+?>/ig);
                  var htmlStr = "";
                  bubbles.forEach(function (item, idx) {
                    if (idx === bubbles.length - 1) {
                      item += "</br><p style=\"border-bottom: 1px dotted lightgray;\"></p>".concat(res.data.answerEvaluate.header, "\n                                            <div class=\"eva-btn-yes\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"yes-img\"><img src=\"./images/yes-icon3x.png\"></div>&nbsp;\n                                                <span class=\"yes-text\" style=\"color: red\">\u662F</span>\n                                            </div>\n                                            <div class=\"eva-btn-no\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"no-img\"><img src=\"./images/no-icon3x.png\"></div>&nbsp;\n                                                <span class=\"no-text\" style=\"color: gray\">\u5426</span>\n                                            </div>").replace(/ *[\r|\n] */gm, '');
                    }

                    htmlStr += item;
                    ChatResolver.robotRender(item);
                  });
                  robotService.getRobotChat(msg, htmlStr);
                  return false;
                } //长图文


                if (JSON.stringify(res.data.answer).indexOf("长图文") > -1) {
                  robotService.longGraphicUrl = JSON.stringify(res.data.answer).split("'")[1];
                  var answerEvaluate1 = res.data.answer.replace(robotService.longGraphicUrl, "javascript:;");
                  var answerEvaluate = answerEvaluate1.replace("target='_blank'", "class='longtype'");
                  message = "".concat(answerEvaluate);

                  if (res.data.relevantQuestion) {
                    var _recommendQuestion3 = res.data.relevantQuestion.name.map(function (item) {
                      return "<a href=\"javascript:;\" class=\"recommendQuestion\">".concat(item, "</a><br/>");
                    }).join("");

                    message += "<br/>".concat(res.data.relevantQuestion.header, "<br/>").concat(_recommendQuestion3);
                  }

                  message += "</br><p style=\"border-bottom: 1px dotted lightgray;\"></p>".concat(res.data.answerEvaluate.header, "</br>\n                                            <div class=\"eva-btn-yes\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"yes-img\"><img src=\"./images/yes-icon3x.png\"></div>&nbsp;\n                                                <span class=\"yes-text\" style=\"color: red\">\u662F</span>\n                                            </div>\n                                            <div class=\"eva-btn-no\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"no-img\"><img src=\"./images/no-icon3x.png\"></div>&nbsp;\n                                                <span class=\"no-text\" style=\"color: gray\">\u5426</span>\n                                            </div>").replace(/ *[\r|\n] */gm, '');
                } // 视频


                if (JSON.stringify(res.data.answer).indexOf("</video>") > -1) {
                  message = "".concat(res.data.answer);

                  if (res.data.relevantQuestion) {
                    var _recommendQuestion4 = res.data.relevantQuestion.name.map(function (item) {
                      return "<a href=\"javascript:;\" class=\"recommendQuestion\">".concat(item, "</a><br/>");
                    }).join("");

                    message += "<br/>".concat(res.data.relevantQuestion.header, "<br/>").concat(_recommendQuestion4);
                  }

                  message += "</br><p style=\"border-bottom: 1px dotted lightgray;\"></p>".concat(res.data.answerEvaluate.header, "\n                                            <div class=\"eva-btn-yes\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"yes-img\"><img src=\"./images/yes-icon3x.png\"></div>&nbsp;\n                                                <span class=\"yes-text\" style=\"color: red\">\u662F</span>\n                                            </div>\n                                            <div class=\"eva-btn-no\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"no-img\"><img src=\"./images/no-icon3x.png\"></div>&nbsp;\n                                                <span class=\"no-text\" style=\"color: gray\">\u5426</span>\n                                            </div>").replace(/ *[\r|\n] */gm, '');
                } // 售前咨询


                if (res.data.answerType == '12') {
                  message = res.data.answer; // message = message.replace(/sendQuestion/g,'robotService.sendQuestion');

                  message = message.replace(/href='#'/g, "href='javascript:;'"); // message = message.replace(/on/,"")
                } // 图片文案


                if (JSON.stringify(res.data.answer).indexOf("<img") > -1) {
                  if (res.data.question.indexOf('购买电脑包') > -1) {
                    message = "<div class=\"mdbuyimg\">".concat(res.data.answer, "</div>");
                  } else {
                    message = "".concat(res.data.answer);
                  }

                  if (res.data.relevantQuestion) {
                    var _recommendQuestion5 = res.data.relevantQuestion.name.map(function (item) {
                      return "<a href=\"javascript:;\" class=\"recommendQuestion\">".concat(item, "</a><br/>");
                    }).join("").replace(/ *[\r|\n] */gm, '');

                    message += "<br/>".concat(res.data.relevantQuestion.header, "<br/>").concat(_recommendQuestion5).replace(/ *[\r|\n] */gm, '');
                  }

                  message += "</br><p style=\"border-bottom: 1px dotted lightgray;\"></p></br></br>".concat(res.data.answerEvaluate.header, "</br>\n                                            <div class=\"eva-btn-yes\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"yes-img\"><img src=\"./images/yes-icon3x.png\"></div>&nbsp;\n                                                <span class=\"yes-text\" style=\"color: red\">\u662F</span>\n                                            </div>\n                                            <div class=\"eva-btn-no\" data-askLogId=").concat(res.data.askLogId, ">\n                                                <div class=\"no-img\"><img src=\"./images/no-icon3x.png\"></div>&nbsp;\n                                                <span class=\"no-text\" style=\"color: gray\">\u5426</span>\n                                            </div>").replace(/ *[\r|\n] */gm, '');
                }
              }

              break;

            default:
              break;
          }

          ChatResolver.robotRender(message); // robotService.getRobotChat(msg,message);

          if (res.data.answerType === "11") {
            robotService.getRobotChat(msg, message);
          } else {
            if (res.data.messageType === "lenovomall") {
              robotService.getRobotChat(msg, lenovomallAnswer);
            } else {
              robotService.getRobotChat(msg, res.data.answer);
            }
          }
        }
      },
      error: function error(err) {
        console.log("服务机器人会话失败:", err);
      }
    });
  },
  getAnswerEvaluation: function getAnswerEvaluation(evaluationState, askLogId, data) {
    var params = {
      evaluationState: evaluationState,
      id: askLogId
    };
    $.ajax({
      type: "POST",
      url: data.url + "answerEvaluation",
      dataType: 'json',
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "userIdentity": data.userIdentity
      },
      data: JSON.stringify(params),
      success: function success(res) {
        if (res.code === 2000) {
          var message = res.data.info;
          ChatResolver.robotRender(message);
        } else if (res.code === 4001) {} // 在这里请求结束 ,不让弹窗再次点击


        robotService.isclick = false;
      },
      err: function err(_err) {
        console.log("机器人评价：", _err);
        robotService.isclick = false;
      }
    });
  },
  //弹窗提交（否）
  getSubFeedacks: function getSubFeedacks(str, sug, data) {
    var params = {
      id: robotService.askLogId,
      suggest: sug,
      tag: str
    };
    $.ajax({
      type: "POST",
      url: data.url + "submitFeedbacks",
      dataType: 'json',
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "userIdentity": data.userIdentity
      },
      data: JSON.stringify(params),
      success: function success(res) {
        if (res.code === 2000) {
          alert('感谢您的评价');
        } else if (res.code === 4001) {// alert('您已经评价过了或者评价失败')
        } // 在这里请求结束 ,不让弹窗再次点击


        robotService.isclick = false;
      },
      err: function err(_err2) {
        console.log("提交评价失败：", _err2); // 在这里请求结束 ,不让弹窗再次点击

        robotService.isclick = false;
      }
    });
  },
  getSerWelWord: function getSerWelWord(data) {
    var params = {
      t: new Date().getTime(),
      welcomeWord: data
    };

    try {
      Request.jsonp(Api.serWelWord, params, true, function (res) {});
    } catch (error) {
      console.log(error);
    }
  },
  getAnswerFile: function getAnswerFile(msg, data, _url) {
    var params = {
      url: _url
    };
    $.ajax({
      type: "GET",
      url: data.url + "getAnswerFile?url=" + params.url,
      dataType: 'json',
      headers: {
        "Content-Type": "application/json",
        "userIdentity": data.userIdentity
      },
      success: function success(res) {
        var message;

        if (Common.isMobile()) {
          // wap
          message = '<div class="mdfullclick">' + res.data.content + '</div>';
          robotService.longstr = res.data.content;
        } else {
          message = '<a href="' + _url + '" target="_blank" style="">' + res.data.content + '</a>'; //pc
        }

        ChatResolver.robotRender(message);

        if (res && res.code === 2000) {
          robotService.getRobotChat(msg, message);
        }
      },
      err: function err(_err3) {
        console.log("长图文：", _err3);
      }
    });
  },
  getRobotChat: function getRobotChat(msg, message, type) {
    var params = {
      t: new Date().getTime(),
      question: msg,
      answer: message,
      type: type
    };

    try {
      Request.jsonp(Api.robotChat, params, true, function (res) {});
    } catch (error) {
      console.log(error);
    }
  },
  //关闭类型
  closeType: function closeType() {
    var params = {
      t: new Date().getTime()
    };

    try {
      Request.jsonp(Api.closeType, params, true, function (res) {});
    } catch (error) {
      console.log(error);
    }
  },
  sendQuestion: function sendQuestion(simple, name) {
    ChatResolver.render(ChatResolver.type.outMessage, {
      content: name,
      type: 'TEXT'
    });
    robotService.getServiceRobot(name, robotService.data, simple);
  }
};

window.sendQuestion = function (simple, name) {
  robotService.sendQuestion(simple, name);
};

var assistantService = {
  val: "",
  EsqData: [],
  clickEventAssistant: function clickEventAssistant() {
    $("#message_area").off("input onpropertychange").on("input onpropertychange", function (event) {
      if (robotConnectStatus.authResult.rc === 0 || robotConnectStatus.authResult.rc === 2) {
        if (robotConnectStatus.isRobotWork === 1 && robotConnectStatus.connectType === "1") {
          assistantService.getEsQ($("#message_area").val());
          $('.question').hide();
        }
      }
    });
    $('#message_area').off('keydown').on('keydown', function (event) {
      if (event.key && event.key === "Enter") {
        $("#send_msg_btn").trigger('click');
        event.preventDefault();
        return false;
      }
    });
    $("#send_msg_btn").off("click").on('click', function () {
      var message = $("#message_area").val();

      if (!message || RegExp("^[ ]+$").test(message)) {
        Pdialog.showDialog({
          content: "消息不能为空"
        });
        return false;
      }

      if (message && message.length > 300) {
        Pdialog.showDialog({
          content: "消息不能超过300字"
        });
        return false;
      }

      if (message && message.length <= 300) {
        ChatResolver.render(ChatResolver.type.outMessage, {
          content: message,
          type: 'TEXT'
        });

        if (message.indexOf('人工') > -1 || message.indexOf('客服') > -1 || message.indexOf('人工客服') > -1) {
          if (robotConnectStatus.authResult.rc === 0) {
            robotConnectStatus.isRobotWork = 0;
            buildChat(robotConnectStatus.authResult.data); // wap

            if (Common.isMobile()) {
              $("#click-emoji").show();
            }

            ChatResolver.robotRender(Constant.build_success);
            robotService.getRobotChat(message, Constant.build_success); // 关闭类型

            robotService.closeType();
          } else {
            ChatResolver.robotRender(robotConnectStatus.authResult.data.offlineMsg);
            robotService.getRobotChat(message, robotConnectStatus.authResult.data.offlineMsg);
            auth();
          }
        } else {
          assistantService.getQuestion(message);
        }

        message = $("#message_area").val("");
        $('.question').hide();
        return false;
      }

      event.preventDefault();
      return false;
    });
    $('.questionList').off("click").on('click', '.EsqDataLi', function () {
      var content = $(this).text();
      var code = $(this).attr('data');
      assistantService.getQuestion(content, code);
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: content,
        type: 'TEXT'
      });
      content = $("#message_area").val("");
      $('.question').hide();
    }); // $(document).on('click','.container .more',function(){
    //     $(this).parent().addClass('showChat')
    //     $(this).siblings('.putItAway').show()
    //     $(this).hide()
    // })
    // $(document).on('click','.container .putItAway',function(){
    //     $(this).parent().removeClass('showChat')
    //     $(this).siblings('.more').show()
    //     $(this).hide()
    // })

    $("#chatDiv").off("click").on("click", ".recommendQuestion", function () {
      ChatResolver.render(ChatResolver.type.outMessage, {
        content: $(this).html(),
        type: 'TEXT'
      });
      assistantService.getQuestion($(this).text(), $(this).attr('data'));
    });
    $(document).off('click').on('click', '.goods-send-url', function () {
      var goodsUrl = $('.goods-send-url').attr("data-url");

      if (goodsUrl) {
        if (robotConnectStatus && robotConnectStatus.isRobotWork === 1) {
          ChatResolver.render(ChatResolver.type.outMessage, {
            content: goodsUrl,
            type: 'TEXT'
          });
          assistantService.getQuestion(goodsUrl);
        }
      }
    });
  },
  getWelcome: function getWelcome() {
    var params = {
      t: new Date().getTime()
    };
    Request.jsonp(Api.welcome, params, true, function (res) {
      if (res.rc === 0) {
        ChatResolver.render(ChatResolver.type.inMessage, {
          content: res.data,
          type: 'ROBOT'
        });
      }
    });
  },
  getEsQ: function getEsQ(message) {
    var params = {
      content: message
    };
    Request.jsonp(Api.esQ, params, true, function (res) {
      if (res && res.data && res.data !== null && res.data !== []) {
        assistantService.EsqData = res.data;
        assistantService.getEsqData();
        $('.question').show();
      } else {
        $('.question').hide();
      }
    });
  },
  getQuestion: function getQuestion(question, questionId) {
    var params = {
      question: question,
      questionId: questionId ? questionId : ""
    };
    Request.jsonp(Api.robot, params, true, function (res) {
      if (res.rc === 0) {
        // assistantService.val = res.data
        // ChatResolver.render(ChatResolver.type.inMessage, { content: assistantService.val, type: 'ROBOT' });
        var message = res.data.answer;

        if (res.data.relevantQuestion != null) {
          var recommendQuestion = res.data.relevantQuestion.questions.map(function (item) {
            return "<a href=\"javascript:;\" class=\"recommendQuestion\" data=".concat(item.questionId, ">").concat(item.content, "</a ><br/>");
          }).join("");
          message += "<hr>".concat(res.data.relevantQuestion.header, "</br>") + recommendQuestion;
          ChatResolver.robotRender(message);
        } else {
          ChatResolver.robotRender(message);
        } // 存储自研助手的问答
        // robotService.getRobotChat(question,message);

      }
    });
  },
  getEsqData: function getEsqData() {
    var html = assistantService.EsqData.map(function (item, idx) {
      return "<a class=\"EsqDataA\" title=\"".concat(item.content.replace(/<(em)[^>]*?>/g, '').replace(/<\/(em)>/g, ''), "\">\n        <span>").concat(idx + 1, ".</span><li class=\"EsqDataLi\" data=").concat(item.code, ">").concat(item.content, "</li></a>");
    }).join('');
    $('.questionList').html(html);
  }
};